/* Lightweight DOM contract probe: exercises data-driven rendering and selection logic.
   This does NOT implement browser layout, accessibility APIs, focus trap, or native forms. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm');const P=path.resolve(__dirname,'..');
class Node {
 constructor(tag='#text',text=''){this.tagName=tag.toUpperCase();this.children=[];this.attrs={};this.listeners={};this._text=text;this.style={};this.dataset={};this.value='';this.disabled=false;this.checked=false;this.parentNode=null;this.classList={add(){},remove(){}};}
 append(...xs){for(let x of xs){if(typeof x==='string')x=new Node('#text',x);if(x){x.parentNode=this;this.children.push(x)}}}
 replaceChildren(...xs){this.children=[];this.append(...xs)}
 setAttribute(k,v){this.attrs[k]=String(v);if(k==='id')this.id=v;if(k==='value')this.value=String(v);if(k==='class')this.className=v;if(k==='selected')this.selected=true;if(k.startsWith('data-'))this.dataset[k.slice(5)]=v;}
 getAttribute(k){return this.attrs[k]??null} removeAttribute(k){delete this.attrs[k]}
 addEventListener(k,f){(this.listeners[k]??=[]).push(f)}
 fire(k,target=this){for(const f of this.listeners[k]??[])f({target,preventDefault(){}})}
 get textContent(){return this._text+this.children.map(x=>x.textContent).join('')}
 set textContent(v){this._text=String(v);this.children=[]}
 get innerText(){return this.textContent}
 get lastElementChild(){return this.children.at(-1)}
 get isConnected(){return true}
 get elements(){return Object.fromEntries(this.querySelectorAll('input,textarea,select').map(n=>[n.attrs.name,n]))}
 querySelectorAll(selector){const tags=selector.split(',');let result=[];for(const n of this.children){if(tags.some(t=>n.tagName.toLowerCase()===t||t.startsWith('#')&&n.id===t.slice(1)))result.push(n);result.push(...n.querySelectorAll(selector))}return result}
 querySelector(s){return this.querySelectorAll(s)[0]??null}
 focus(){document.activeElement=this}
 showModal(){this.open=true}
 close(){this.open=false}
 remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(x=>x!==this)}
 checkValidity(){return true}
}
const document={documentElement:new Node('html'),body:new Node('body'),activeElement:null,createElement:t=>new Node(t),createTextNode:t=>new Node('#text',String(t)),getElementById(id){if(this.body.id===id)return this.body;return this.body.querySelector('#'+id)}};
const app=new Node('div');app.id='app';document.body.append(app);
const window={history:{replaceState(){}},addEventListener(){}};const context={window,document,location:{hash:''},console,Set,Map};vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(P,'UI_Handoff/ui-preview/data.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(P,'UI_Handoff/ui-preview/policy.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(P,'UI_Handoff/ui-preview/comparison.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(P,'UI_Handoff/ui-preview/ads.js'),'utf8'),context);
vm.runInContext(fs.readFileSync(path.join(P,'UI_Handoff/ui-preview/app.js'),'utf8'),context);
function change(id,value){const n=document.getElementById(id);if(!n)throw Error('Missing control '+id);n.value=value;n.fire('change')}
let renders=0;for(const lang of ['am','en']){change('control-language',lang);for(const theme of ['light','dark']){change('control-theme',theme);for(const s of window.FELAGI.manifest.screens){change('control-screen',s.id);change('control-role',s.id.startsWith('A')?'mainAdmin':s.roles==='provider'?'provider':'requester');for(const state of s.states){change('control-state',state);const opts=document.getElementById('control-state').children.map(x=>x.value);if(opts.length!==new Set(opts).size)throw Error('Duplicate options '+s.id);const title=document.getElementById('screenTitle');if(!title||title.textContent!==window.FELAGI.locales[lang][s.title_key])throw Error('Title mismatch '+s.id);if(app.textContent.includes('undefined'))throw Error('Undefined copy '+s.id);renders++;}for(const state of s.runtime_states){change('control-runtime',state);renders++;}}}}
change('control-screen','S015');change('control-role','provider');change('control-state','provider-own-result');change('control-runtime','ready');
if(app.textContent.includes('O2')||app.textContent.includes('O3')||!app.textContent.includes('O1'))throw Error('Provider projection leak or missing own result');
change('control-screen','S004');change('control-role','requester');change('control-state','content');change('control-runtime','ready');
const sponsored=()=>app.querySelectorAll('article').filter(n=>n.getAttribute('data-component')==='FgSponsoredCard');
if(sponsored().length)throw Error('Ads not OFF by default');
let fixture=document.getElementById('adsFixture');fixture.checked=true;fixture.fire('change');
if(sponsored().length!==1)throw Error('Registered fictional browse slot not rendered');
change('control-runtime','offline');if(sponsored().length)throw Error('Ad leaked into recovery state');
change('control-screen','S015');change('control-state','completed');change('control-runtime','ready');if(sponsored().length)throw Error('Ad leaked into AI result');
change('control-screen','A023');change('control-role','mainAdmin');change('control-runtime','ready');
for(let i=0;i<7;i++){const b=app.querySelectorAll('button').find(n=>n.textContent===window.FELAGI.locales.en.continue&&!n.disabled);if(!b)throw Error('Missing campaign step continuation '+i);b.fire('click');}
if(!app.textContent.includes(window.FELAGI.locales.en.adValidation))throw Error('Wizard missing final validation');
const report={probe:'Lightweight DOM logic only, not a real browser',render_transitions: renders,screen_count:window.FELAGI.manifest.screens.length,locales:2,themes:2,status:'PASS',limitations:['No layout or native HTML validation','No screen-reader/focus-conformance claim','No Flutter/backend execution']};fs.writeFileSync(path.join(P,'Audit/preview-logic-results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
