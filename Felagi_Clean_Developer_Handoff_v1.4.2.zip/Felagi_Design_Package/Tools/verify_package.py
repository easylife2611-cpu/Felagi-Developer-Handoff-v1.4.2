"""Static reconciliation and contrast checks. Not a browser, Flutter compile or accessibility certificate."""
from pathlib import Path
import json,re,collections,subprocess,hashlib,zipfile,xml.etree.ElementTree as ET
from html.parser import HTMLParser
P=Path(__file__).resolve().parents[1]
def load(p):return json.loads((P/p).read_text())
checks=[]
def check(name,condition,detail=''):
 checks.append({'check':name,'status':'PASS' if condition else 'FAIL','detail':detail})
m=load('Design_Data/screen-manifest.json');screens=m['screens'];r=load('Design_System/tokens/token_registry.json');runtime=load('Design_System/tokens/design_tokens.json');states=load('Design_Data/states.json');fields=load('Design_Data/fields.json');routes=load('Design_Data/routes.json');actions=load('Design_Data/actions.json')
loc={l:{k:v for k,v in load('Localization/app_'+l+'.arb').items() if not k.startswith('@')} for l in ['am','en']}
check('46 screens:23 user and23 Admin',len(screens)==46 and sum(s['id'].startswith('S') for s in screens)==23 and sum(s['id'].startswith('A') for s in screens)==23)
for field in ['id','route_id','path']:check('Unique '+field,len({s[field] for s in screens})==46)
check('Canonical IDs match',all(s['id']==s['canonical_id'] for s in screens))
paths=[v for s in screens for v in [s['path']]+s['aliases']];check('Unique paths/aliases',len(paths)==len(set(paths)))
check('Mobile IDs preserved',{s['id'] for s in screens if s['id'].startswith('S')}=={'S%03d'%i for i in range(1,24)})
check('No premature Need ID in create preview',screens[5]['path']=='/needs/new/public-preview' and screens[5]['api']==[])
check('Route registry matches canonical paths',all(next(x for x in routes if x['id']==s['id'])['path']==s['path'] and next(x for x in routes if x['id']==s['id'])['aliases']==s['aliases'] for s in screens))
check('All navigation edges resolve',all(x in {s['id'] for s in screens} for s in screens for x in s['links']))
check('States unique per screen',all(len(s['states'])==len(set(s['states'])) for s in screens))
check('All states defined/localized',all(st in states and states[st]['label_key'] in loc['am'] and states[st]['description_key'] in loc['am'] for s in screens for st in s['states']+s['runtime_states']))
check('All fields defined/localized',all(f in fields and fields[f]['label_key'] in loc['am'] for s in screens for f in s['fields']))
check('Locale key parity',loc['am'].keys()==loc['en'].keys(),str(len(loc['am']))+' keys')
check('Locale values complete',all(isinstance(v,str) and v.strip() for l in loc.values() for v in l.values()))
check('All titles localized',all(s['title_key'] in loc['am'] for s in screens))
check('Admin23 detailed schemas',len(load('Design_Data/admin.json'))==23 and all(s.get('write_permission') and s.get('write_guard') for s in screens if s['id'].startswith('A')))
check('Admin columns localized',all(c in loc['am'] for a in load('Design_Data/admin.json').values() for c in a['columns']))
check('Full runtime registry retained',runtime['registry']==r)
flat=runtime['resolved'];check('Component refs resolve',all(v in flat for v in r['component'].values()))
check('Component values exact',all(flat['component.'+k]==flat[v] for k,v in r['component'].items()))
check('Dark color metadata correct',all(c['theme']=='dark' for c in r['color'] if c['semantic'].endswith('.dark')))
check('Full spacing incl64',flat['space.16']==64)
check('Telegram state sources reconciled','RETRY' in r['productStatus']['telegram'] and 'PAUSED' not in r['productStatus']['telegram'] and 'PAUSED' in r['productStatus']['telegramDestination'])
check('Preview manifest exact copy',load('UI_Handoff/ui-preview/screen-manifest.json')==m)
bundle=json.loads((P/'UI_Handoff/ui-preview/data.js').read_text().split('window.FELAGI = ',1)[1].rsplit(';',1)[0]);check('Preview data generated from current canonical files',bundle['manifest']==m and bundle['fields']==fields and bundle['states']==states and bundle['locales']==loc)
check('Flutter/JSON locale derivatives exact',all(load('UI_Handoff/locales/'+l+'.json')==loc[l] and {k:v for k,v in load('Design_System/flutter/lib/l10n/app_'+l+'.arb').items() if not k.startswith('@')}==loc[l] for l in loc))
check('All eleven original/extended overlays bound',len(actions)==11 and len({a['overlay'] for a in actions})==11 and all(a['key'] in loc['am'] and a['precondition'] and a['api'] for a in actions))
# Dynamic localized identifiers are covered by manifest/state/field/Admin key checks above.
jsfiles=list((P/'UI_Handoff/ui-preview').glob('*.js'))+list((P/'Design_System/preview').glob('*.js'))
for f in jsfiles:
 result=subprocess.run(['node','--check',str(f)],capture_output=True,text=True,timeout=15);check('JS syntax '+str(f.relative_to(P)),result.returncode==0,result.stderr.strip())
keys=set()
for f in jsfiles:
 if f.name=='data.js':continue
 keys.update(re.findall(r"(?:t|txt|button|announce)\('([A-Za-z][A-Za-z0-9]*)'",f.read_text()))
# txt's first argument is an HTML tag, filter those known tags.
keys-=set('p div h1 h2 h3 strong small legend th dt caption label summary'.split())
check('Literal UI key references resolve',not(keys-loc['am'].keys()),str(sorted(keys-loc['am'].keys())))
class HTMLAudit(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.assets=[];self.lang=False;self.missing_alt=0
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if 'id' in d:self.ids.append(d['id'])
  if tag=='html':self.lang=bool(d.get('lang'))
  if tag=='img' and 'alt' not in d:self.missing_alt+=1
  if tag in ['script','img','link'] and (d.get('src') or d.get('href')):self.assets.append(d.get('src') or d.get('href'))
for f in P.rglob('*.html'):
 a=HTMLAudit();a.feed(f.read_text());check('HTML structure/assets '+str(f.relative_to(P)),a.lang and not a.missing_alt and len(a.ids)==len(set(a.ids)) and all((f.parent/u).exists() for u in a.assets if not re.match(r'\w+:|#',u)))
for f in P.rglob('*.svg'):
 try:ET.parse(f);ok=True
 except ET.ParseError:ok=False
 check('SVG XML '+str(f.relative_to(P)),ok)
allcss='\n'.join(f.read_text() for f in (P/'UI_Handoff/ui-preview').glob('*.css'));defined=set(re.findall(r'(--[\w-]+)\s*:',allcss));used=set(re.findall(r'var\((--[\w-]+)',allcss));check('CSS custom properties resolve',not used-defined,str(sorted(used-defined)))
app=(P/'UI_Handoff/ui-preview/app.js').read_text();css=(P/'UI_Handoff/ui-preview/app.css').read_text();check('No divergent hardcoded preview hex colors',not re.search(r'#[0-9a-fA-F]{3,8}\b',css));check('Responsive application breakpoints',all('min-width:'+str(n)+'px' in css for n in [600,840,1200,1600]) and 'grid-template-columns:minmax(0,1fr)' in css)
check('Native interactive markup implementation',"el('input'" in app and "el('button'" in app and "el('dialog'" in app and "'aria-describedby'" in app and "'aria-live':'polite'" in app)
check('No duplicate default state injection',"['default',..." not in app)
check('Preferred Ethiopic font in CSS/Flutter','"Noto Sans Ethiopic",system-ui' in css and 'fontFamily: FgTokens.fontFamily' in (P/'Design_System/flutter/lib/src/theme.dart').read_text())
flutter='\n'.join(f.read_text() for f in (P/'Design_System/flutter/lib/src').glob('*.dart') if f.name not in ['registry.dart','strings.dart'])
check('Flutter explicit palette','ColorScheme.fromSeed' not in flutter and 'Colors.white' not in flutter)
check('Flutter prominent/theme/destructive/state fixes',all(x in flutter for x in ['FgTokens.controlProminent','cs.onSecondary','this.destructive = false','FgTelegramState.skipped','FgTelegramState.paused']))
token_dart=(P/'Design_System/flutter/lib/src/tokens.dart').read_text();decl=set(re.findall(r'static const (\w+)',token_dart));uses=set(re.findall(r'FgTokens\.(\w+)',flutter));check('Flutter aliases resolve',not uses-decl,str(sorted(uses-decl)))
check('Profile and report schema align DFM',fields['full_name']['max']==150 and fields['phone_number']['max']==30 and screens[20]['fields']==['entity_type','entity_id','reason_code','details'])
# Brand authority is the product-owner supplied official master in Brand/.
brand=load('Design_Data/brand-evidence.json');master=(P/brand['canonical_master']).read_bytes();master_sha=hashlib.sha256(master).hexdigest()
brand_ok=[]
for rel in ['Design_System/assets/brand/felagi-app-icon.png','Design_System/assets/brand/felagi-mark.png','UI_Handoff/assets/brand/felagi-app-icon.png','UI_Handoff/assets/brand/felagi-mark.png']:
 brand_ok.append(hashlib.sha256((P/rel).read_bytes()).hexdigest()==master_sha)
check('Official brand raster derivatives match product-owner master',all(brand_ok),str(len(brand_ok))+' exact raster derivatives')
colors={c['semantic']:c['raw'] for c in r['color']}
def luminance(h):
 c=[int(h.lstrip('#')[i:i+2],16)/255 for i in (0,2,4)];c=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in c];return sum(x*w for x,w in zip(c,[.2126,.7152,.0722]))
def ratio(a,b):x,y=sorted([luminance(a),luminance(b)]);return (y+.05)/(x+.05)
contrast=[]
for suffix in ['', '.dark']:
 surfaces=['color.surface.canvas','color.surface.card','color.surface.raised']
 for fg in ['color.text.primary','color.text.secondary','color.status.success','color.status.error','color.status.warning','color.status.info','color.brand.primary','color.border.default','color.border.focus','color.border.action']:
  for bg in surfaces:
   threshold=3 if '.border.' in fg else 4.5;v=ratio(colors[fg+suffix],colors[bg+suffix]);contrast.append(dict(foreground=fg+suffix,background=bg+suffix,ratio=round(v,4),threshold=threshold,status='PASS' if v>=threshold else 'FAIL'))
 for fg,bg in [('color.text.onAccent','color.brand.accent'),('color.text.onBrand','color.brand.primary'),('color.text.onError','color.status.error')]:
  v=ratio(colors[fg+suffix],colors[bg+suffix]);contrast.append(dict(foreground=fg+suffix,background=bg+suffix,ratio=round(v,4),threshold=4.5,status='PASS' if v>=4.5 else 'FAIL'))
check('66 specified contrast pairs',len(contrast)==66 and all(c['status']=='PASS' for c in contrast),str([c for c in contrast if c['status']=='FAIL']))
fixtures=load('Design_Data/fixtures.json');check('DFM exact comparison rubric',fixtures['comparison']['criteria']==['price','reliability','quality','delivery'] and fixtures['comparison']['weights']==[.25]*4 and sum(fixtures['comparison']['scores'])/4==fixtures['comparison']['overall'])
required=['Product_Design/Final_Master_Product_Design_Specification.md','Design_System/Final_Design_System_Foundation.md','Design_System/Final_Component_Library_Specification.md','Design_System/Final_Component_State_Matrix.md','Design_System/Final_Pattern_Library.md','Product_Design/Final_Information_Architecture.md','Product_Design/Final_Navigation_Route_Map.md','Product_Design/Final_Complete_Screen_Inventory.md','Product_Design/Final_Screen_by_Screen_Specifications.md','Product_Design/Final_User_Journey_Matrix.md','Product_Design/Final_Screen_Transition_Map.md','Product_Design/Final_Interaction_Contract.md','Product_Design/Final_Responsive_Matrix.md','Product_Design/Final_Accessibility_Matrix.md','Product_Design/Final_Runtime_State_Matrix.md','Product_Design/Final_Error_Recovery_Matrix.md','Admin/Final_Admin_Control_Center_Design.md','Developer_Handoff/Final_Developer_Handoff_Specification.md']
check('All core requested specifications exist',all((P/x).exists() and (P/x).stat().st_size>400 for x in required))
report={'scope':'Static source reconciliation only; not browser/device/compiler/live evidence','checks':checks,'contrast':contrast,'blocked':['Chromium unavailable; bounded installation returned corrupt download and timed out','Flutter SDK unavailable; compile/analyze/widget tests not run','TalkBack/VoiceOver, device font rendering, linguistic QA and live API/provider evidence external']}
(P/'Audit/verification-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':sum(c['status']=='PASS' for c in checks),'failed':[c for c in checks if c['status']=='FAIL'],'contrast_pairs':len(contrast)},indent=2))
raise SystemExit(1 if any(c['status']=='FAIL' for c in checks) else 0)
