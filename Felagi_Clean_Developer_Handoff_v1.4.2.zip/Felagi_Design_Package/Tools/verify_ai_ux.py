from pathlib import Path
import json
P=Path(__file__).resolve().parents[1]
def load(f):return json.loads((P/f).read_text())
checks=[]
def test(k,c):checks.append(dict(id=k,status='PASS' if c else 'FAIL'))
c=load('Design_Data/criteria-registry.json');m=load('Design_Data/screen-manifest.json')['screens'];cs=load('Design_Data/control-registry.json')['controls'];a=load('Design_Data/ai-requirement-coverage.json');ux=load('Design_Data/ux-quality.json');loc={l:load('Localization/app_'+l+'.arb') for l in ['am','en']}
test('51-directive-bindings',len(a)==51 and {x['requirement'] for x in a}=={'AI-'+str(i) for i in range(1,52)})
test('owner-and-screens',all((P/x['owner']).exists() and x['screen'] in {s['id'] for s in m} for x in a))
test('full-traceability-chain',all(all(x.get(k) for k in ['screen','component','state','api','data_object','permission','notification','telegram','audit','test']) for x in a))
test('four-equal-criteria',len(c['criteria'])==4 and all(x['weight']==.25 for x in c['criteria']))
test('v2-unknown-not-number',c['active_version']=='v2' and c['unknown_criterion_score'] is None)
test('legacy-preserved',c['legacy_version']=='v1' and 'immutable' in c['legacy_rendering'])
test('criterion-keys',all(x['label_key'] in loc[l] for x in c['criteria'] for l in loc))
test('46-screen-quality-bindings',{x['screen_id'] for x in ux['screens']}=={s['id'] for s in m})
test('16-quality-rules',all(len(x['quality_requirements'])==16 for x in ux['screens']))
test('required-draft-surfaces',{x['screen_id'] for x in ux['screens'] if x['durable_draft_required']}=={'S005','S011','S017','S021'})
test('no-new-comparison-screen',len(m)==46 and len(next(x for x in m if x['id']=='S015')['projections'])==2)
test('registered-ai-controls',all(any(x['control_id']==cid and x['screen_id']=='A006' for x in cs) for cid in ['aiCriteriaVersion','aiPromptVersion','aiMaxOffers','aiRetryLimit','aiDailyLimit']))
test('comparison-copy',all(k in loc[l] for l in loc for k in ['overallScore','evidenceCoverage','requirementMatch','strengths','weaknesses','missingInformation','riskNotes','comparisonVersion','closeResult','advisory']))
app=(P/'UI_Handoff/ui-preview/app.js').read_text();test('selected-offers-drive-preview',"offers:D.comparison.offers.filter(o=>comparisonSelected.has(o.offer_id))" in app)
test('scroll-restoration-source','viewScroll[current.id]' in app and 'window.scrollTo?.' in app)
test('no-double-primary-browse',"class:submitKey==='search'?'':'primary'" in app)
test('native-disclosure',"el('details'" in app and "txt('summary'" in app)
(P/'Audit/ai-ux-verification-results.json').write_text(json.dumps({'scope':'Source/contract verification, not visual/usability or live AI proof','checks':checks},indent=2)+'\n');print(json.dumps({'passed':sum(x['status']=='PASS' for x in checks),'failed':[x for x in checks if x['status']=='FAIL']}));raise SystemExit(any(x['status']=='FAIL' for x in checks))
