"""Cross-artifact contract checks. Does not claim runtime/provider/device verification."""
from pathlib import Path
import json,re,hashlib,subprocess
P=Path(__file__).resolve().parents[1]
def load(f):return json.loads((P/f).read_text())
results=[]
def test(id,condition,detail=''):results.append(dict(id=id,status='PASS' if condition else 'FAIL',detail=detail))
m=load('Design_Data/screen-manifest.json');ss=m['screens'];cr=load('Design_Data/control-registry.json');cs=cr['controls'];loc={l:load('Localization/app_'+l+'.arb') for l in ['am','en']};apis=load('Design_Data/api-mappings.json');routes=load('Design_Data/routes.json');trace=load('Design_Data/traceability.json');cov=load('Design_Data/admin-requirement-coverage.json')
for s in ss:
 route=next(x for x in routes if x['id']==s['id'])
 test('BIND-'+s['id'],s['id']==s['canonical_id']==s['preview_id'] and route['route_id']==s['route_id'] and route['path']==s['path'] and all(s['title_key'] in loc[l] for l in loc) and s['state_ids']==[s['id']+'.'+st for st in s['states']] and apis[s['api_mapping_id']]['references']==s['api'])
 test('TRACE-'+s['id'],any(x['screen']==s['id'] and x.get('journey') and x.get('component') and x.get('state') and x.get('api') and x.get('recovery') and x.get('test') for x in trace))
required=['control_id','canonical_name','category','description','control_type','default_value','current_value','allowed_values','unit','dependency','conflict_rule','risk_level','permission_required','reauth_required','confirmation_required','rollback_supported','safe_default','runtime_effect','verification_method','audit_required','localization_key','recovery','test_id']
for c in cs:
 test('CONTROL-'+c['control_id'],all(k in c for k in required) and c['audit_required'] and c['confirmation_required'] and c['screen_id'] in {s['id'] for s in ss} and all(c['localization_key'] in loc[l] and c['description'] in loc[l] for l in loc))
 test('RISK-'+c['control_id'],c['risk_level'] not in ['HIGH','CRITICAL'] or c['reauth_required'])
 test('SECRET-'+c['control_id'],c['category']!='secret' or (c['control_type']=='writeOnly' and c['current_value'] is None and not c['rollback_supported']))
test('CONTROL-UNIQUE',len(cs)==len({c['control_id'] for c in cs}))
test('FREE-DEFAULT',cr['production_defaults']=={'offerUnlock':False,'offerFee':0,'offerCurrency':'ETB','adsEnabled':False})
test('ADMIN-23',len(load('Design_Data/admin-screen-manifest.json')['screens'])==23)
test('DIRECTIVE-55',len(cov)==55 and len({x['requirement'] for x in cov})==55 and all((P/x['canonical_owner']).exists() for x in cov))
test('EDGE-CASES',all(k in load('Design_Data/edge-cases.json') for k in ['zero-offers','one-offer','fifty-offers','huge-price','no-budget','expired-deadline','missing-history','payment-pending','telegram-uncertain','offline-draft','permission-denied','amharic-stress']))
test('GLOSSARY',all(t['key'] in loc['am'] and loc['am'][t['key']]==t['am'] and loc['en'][t['key']]==t['en'] for t in load('Localization/glossary.json')['terms']))
r=load('Design_System/tokens/token_registry.json');flat=load('Design_System/tokens/design_tokens.json')['resolved'];dart=(P/'Design_System/flutter/lib/src/tokens.dart').read_text()
for alias,path in r['flutterAliases'].items():
 value=flat[path];value='Color(0xFF'+value[1:]+')' if path.startswith('color.') else json.dumps(value) if isinstance(value,str) else str(float(value))
 test('DART-'+alias,'static const '+alias+' = '+value+';' in dart)
generated=['Design_System/tokens/design_tokens.json','Design_System/Final_Token_Registry.md','Design_System/flutter/lib/src/tokens.dart','Design_System/flutter/lib/src/theme.dart','Design_System/flutter/lib/src/registry.dart','Design_System/flutter/lib/src/controls.dart','Design_System/flutter/lib/src/strings.dart','Design_System/flutter/lib/src/comparison.dart','Design_System/flutter/lib/src/advertising.dart','UI_Handoff/ui-preview/tokens.css','UI_Handoff/ui-preview/app.css','UI_Handoff/ui-preview/data.js','UI_Handoff/ui-preview/screen-manifest.json','Design_Data/routes.json','Design_Data/api-mappings.json','Design_Data/admin-screen-manifest.json']
before={f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in generated};run=subprocess.run(['python3',str(P/'Tools/generate_runtime.py')],capture_output=True,text=True,timeout=30)
after={f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in generated};test('REPRODUCIBLE',run.returncode==0 and before==after,str([f for f in before if before[f]!=after[f]]))
app=(P/'UI_Handoff/ui-preview/app.js').read_text();test('NO-TRANSLATION-FALLBACK',"throw Error('Missing translation" in app and "??D.locales.am" not in app)
test('NO-USER-RISK-OVERRIDE',"selectControl('risk'" not in app)
test('NO-FAKE-VERIFY',"adminStage='requires-verification'" in app and "adminStage='verified'" not in app)
test('NO-UNGUARDED-ADMIN-VALIDATION',"if(!adminSample)" in app)
report={'scope':'Source/schema/reference consistency only','checks':results,'generated_hashes':after};(P/'Audit/foundation-verification-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'passed':sum(x['status']=='PASS' for x in results),'failed':[x for x in results if x['status']=='FAIL']}));raise SystemExit(any(x['status']=='FAIL' for x in results))
