"""Generate full token/runtime, preview and Flutter registries from canonical data. No dependencies."""
from pathlib import Path
import json,re
P=Path(__file__).resolve().parents[1]
def load(p):return json.loads((P/p).read_text())
def write(p,s):(P/p).parent.mkdir(parents=True,exist_ok=True);(P/p).write_text(s)
def dump(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2)+'\n')
r=load('Design_System/tokens/token_registry.json')
flat={}
def flatten(v,path):
 if isinstance(v,dict):
  for k,x in v.items():flatten(x,path+'.'+k if path else k)
 else:flat[path]=v
for k,v in r.items():
 if k not in ['color','component','flutterAliases']:flatten(v,k)
for c in r['color']:flat[c['semantic']]=c['raw'];flat[c['primitive']]=c['raw']
for k,v in r['component'].items():
 if v not in flat:raise ValueError('Unresolved '+k+': '+v)
 flat['component.'+k]=flat[v]
dump('Design_System/tokens/design_tokens.json',{'generated_from':'token_registry.json','registry':r,'resolved':flat})
css=[]
for dark in [False,True]:
 vals={}
 for c in r['color']:
  n=c['semantic'];d=n.endswith('.dark')
  if not d:vals[n]=c['raw']
 for c in r['color']:
  if dark and c['semantic'].endswith('.dark'):vals[c['semantic'][:-5]]=c['raw']
 selector=':root' if not dark else ':root[data-theme="dark"]'
 css.append(selector+'{'+''.join('--'+n.replace('.','-')+':'+v+';' for n,v in vals.items())+'}')
css.append(':root{'+''.join('--'+k.replace('.','-')+':'+str(v)+('px' if isinstance(v,(int,float)) and not k.startswith(('opacity.','layer.')) and not k.endswith('.weight') else '')+';' for k,v in flat.items() if k.startswith(('space.','size.','radius.','layout.','layer.','opacity.','border.','text.')) and isinstance(v,(int,float)) and not isinstance(v,bool))+'}')
write('UI_Handoff/ui-preview/tokens.css','/* Generated. Do not hand edit. */\n'+'\n'.join(css))
bundle={k:load(v) for k,v in {'manifest':'Design_Data/screen-manifest.json','fields':'Design_Data/fields.json','states':'Design_Data/states.json','fixtures':'Design_Data/fixtures.json','admin':'Design_Data/admin.json','actions':'Design_Data/actions.json'}.items()}
bundle['controls']=load('Design_Data/control-registry.json')
bundle['edges']=load('Design_Data/edge-cases.json')
bundle['advertising']=load('Design_Data/advertising-contract.json')
bundle['placements']=load('Design_Data/placement-registry.json')
bundle['adFixture']=load('Design_Data/advertising-fixture.json')
bundle['comparison']=load('Design_Data/comparison-fixture.json')
bundle['criteria']=load('Design_Data/criteria-registry.json')
bundle['comparisonContract']=load('Design_Data/comparison-contract.json')
bundle['locales']={l:{k:v for k,v in load('Localization/app_'+l+'.arb').items() if not k.startswith('@')} for l in ['am','en']}
write('UI_Handoff/ui-preview/data.js','/* Generated from canonical registries and ARB. */\nwindow.FELAGI = '+json.dumps(bundle,ensure_ascii=False)+';\n')
dump('UI_Handoff/ui-preview/screen-manifest.json',bundle['manifest'])
# Complete exact token representation, in addition to ergonomic legacy aliases.
write('Design_System/flutter/lib/src/registry.dart',"// Generated; all token families, exact source values.\nimport 'dart:convert';\nfinal Map<String, dynamic> fgTokenRegistry = jsonDecode(r'''"+json.dumps({'registry':r,'resolved':flat},ensure_ascii=False)+"''') as Map<String, dynamic>;\nfinal List<dynamic> fgScreens = jsonDecode(r'''"+json.dumps(bundle['manifest']['screens'],ensure_ascii=False)+"''') as List<dynamic>;\n")
write('Design_System/flutter/lib/src/strings.dart',"// Generated from canonical ARB. All UI labels are caller-localized.\nimport 'dart:convert';\nfinal Map<String, dynamic> fgLocales = jsonDecode(r'''"+json.dumps(bundle['locales'],ensure_ascii=False)+"''') as Map<String, dynamic>;\nString fgText(String locale, String key) => (fgLocales[locale]?[key] ?? (throw StateError('Missing translation: $locale/$key'))) as String;\n")
for l in ['am','en']:
 shutil=None
 text=(P/('Localization/app_'+l+'.arb')).read_text();write('Design_System/flutter/lib/l10n/app_'+l+'.arb',text)
 dump('UI_Handoff/locales/'+l+'.json',bundle['locales'][l])
print('Generated',len(flat),'resolved token paths; full registry and',len(bundle['manifest']['screens']),'screens')

# Ergonomic Dart aliases, theme, CSS composition and documentation are generated in this same run.
lines=["// GENERATED from token_registry.json; do not edit.","import 'package:flutter/material.dart';","abstract final class FgTokens {"]
for alias,path in r['flutterAliases'].items():
 value=flat[path]
 encoded='Color(0xFF'+value.lstrip('#')+')' if path.startswith('color.') else json.dumps(value) if isinstance(value,str) else str(float(value))
 lines.append('  static const '+alias+' = '+encoded+';')
lines.append('}')
write('Design_System/flutter/lib/src/tokens.dart','\n'.join(lines)+'\n')
for source,target in [('theme.dart.in','Design_System/flutter/lib/src/theme.dart'),('app.css.in','UI_Handoff/ui-preview/app.css')]:
 template=(P/'Tools/templates'/source).read_text()
 text=re.sub(r'\{\{([^}]+)\}\}',lambda m:str(flat[m[1]]),template)
 write(target,'/* GENERATED: edit template or token source. */\n'+text)
write('Design_System/Final_Token_Registry.md','# Token Registry — generated reference\n\nCanonical owner: `tokens/token_registry.json`. Never edit generated files.\n\n| Token | Resolved value |\n|---|---|\n'+'\n'.join('| '+k+' | '+str(v).replace('|','/')+' |' for k,v in sorted(flat.items()) if not isinstance(v,(dict,list)))+'\n')
dump('Design_Data/admin-screen-manifest.json',{'generated_from':'screen-manifest.json','screens':[s for s in bundle['manifest']['screens'] if s['id'].startswith('A')]})
dump('Design_Data/api-mappings.json',{s['api_mapping_id']:{'screen_id':s['id'],'references':s['api'],'local_only':not s['api']} for s in bundle['manifest']['screens']})
write('Design_System/flutter/lib/src/controls.dart',"// Generated governed control definitions. Native UI consumers must enforce server capabilities.\nimport 'dart:convert';\nfinal Map<String,dynamic> fgControls=jsonDecode(r\"\"\""+json.dumps(bundle['controls'],ensure_ascii=False)+"\"\"\") as Map<String,dynamic>;\n")

dump('Design_Data/routes.json',[dict(id=s['id'],route_id=s['route_id'],path=s['path'],aliases=s['aliases'],guard=s['roles'],permissions=s.get('permissions',[]),api_mapping_id=s['api_mapping_id'],primary_state=s['states'][0],recovery=s.get('recovery','preserve draft; refresh authority; S021 support'),back='restore origin/filter/scroll; O11 dirty form',deep_link='authorize; no mutation replay') for s in bundle['manifest']['screens']])

dump('Design_Data/localization-keys.json',sorted(bundle['locales']['am']))

write('Design_System/flutter/lib/src/comparison.dart',"// Generated canonical comparison contract; no inference is performed here.\nimport 'dart:convert';\nfinal Map<String,dynamic> fgComparisonContract=jsonDecode(r\"\"\""+json.dumps(bundle['comparisonContract'],ensure_ascii=False)+"\"\"\") as Map<String,dynamic>;\nfinal Map<String,dynamic> fgCriteria=jsonDecode(r\"\"\""+json.dumps(bundle['criteria'],ensure_ascii=False)+"\"\"\") as Map<String,dynamic>;\n")

write("Design_System/flutter/lib/src/advertising.dart", "// Generated governed advertising contract. Production default OFF.\nimport 'dart:convert';\nfinal Map<String,dynamic> fgAdvertising=jsonDecode(r'''"+json.dumps({"contract":bundle["advertising"],"placements":bundle["placements"]},ensure_ascii=False)+"''') as Map<String,dynamic>;\n")
