from pathlib import Path
import json, hashlib, base64, re, sys
P=Path(__file__).resolve().parents[1]
checks=[]
def ok(name, cond, detail=''):
    checks.append({'check':name,'pass':bool(cond),'detail':detail})

def load(rel): return json.loads((P/rel).read_text(encoding='utf-8'))

def sha(b): return hashlib.sha256(b).hexdigest()

am=load('Localization/app_am.arb'); en=load('Localization/app_en.arb')
manifest=load('Design_Data/screen-manifest.json'); screens=manifest['screens']
placements=load('Design_Data/placement-registry.json')['placements']
ads=load('Design_Data/ads-requirement-coverage.json')
trace=load('Design_Data/traceability.json')
brand=load('Design_Data/brand-evidence.json')

ok('No obsolete canonical Offer term ጥቆማ in active Amharic locale', all('ጥቆማ' not in str(v) for k,v in am.items() if not k.startswith('@')))
for k in ['back','continue','save','confirm','close','retry','refresh','edit','send','stop','submit','unlock','boost','compare','cancel','clear','createNeed','markRead','cancelNeed','completeNeed','discard','stay']:
    v=am.get(k,'')
    forbidden=['ተመለስ','ቀጥል','አስቀምጥ','አረጋግጥ','ዝጋ','ሞክር','አድስ','አስተካክል','ላክ','አቁም','አስገባ','ክፈት','አሳድግ','አወዳድር','ተወው','አጽዳ','አቅርብ','አድርግ','ሰርዝ','አጠናቅቅ']
    ok('Respectful action voice '+k, not any(v==f or v.endswith(' '+f) for f in forbidden), v)

# Every screen primary action resolves to localization.
for s in screens:
    k=s.get('primary_action_key')
    if k:
        ok(f'{s["id"]} primary action key localized', k in am and k in en, k)
        if s['id'].startswith('A'):
            ok(f'{s["id"]} English action semantic match', en.get(k)==s.get('primary_action_en'), f'{en.get(k)!r} vs {s.get("primary_action_en")!r}')
            ok(f'{s["id"]} Amharic action semantic match', am.get(k)==s.get('primary_action_am'), f'{am.get(k)!r} vs {s.get("primary_action_am")!r}')

# Known screen invariants.
byid={s['id']:s for s in screens}
ok('S007 uses semantic action key', byid['S007'].get('primary_action_key')=='viewNeed')
ok('S016 primary action is viewComparison', byid['S016'].get('primary_action_key')=='viewComparison')
expected={'free','payment-required','pending','payment-verified','submission-recovery','submitted','refund-pending','failed','unknown'}
ok('S023 state-aware primary actions complete', set(byid['S023'].get('state_primary_actions',{}))==expected)
ok('A023 primary action createCampaign', byid['A023'].get('primary_action_key')=='createCampaign')
a23=byid['A023']
ok('A023 anatomy is advertising-specific', all(x.lower() in a23.get('anatomy','').lower() for x in ['campaign','advertiser','placement','report']))
ok('A023 typed data projections present', len(a23.get('data_contract',{}).get('fields',[]))>=8)

# Placement traceability.
ads_reqs={x['requirement'] for x in ads}; trace_reqs={x['requirement'] for x in trace}
ok('S008 sponsored placement has explicit trace', 'ADS-S008-PLACEMENT' in ads_reqs)
ok('All Ads coverage linked into master traceability', ads_reqs.issubset(trace_reqs), f'missing={sorted(ads_reqs-trace_reqs)}')
for p in placements:
    s=byid[p['screen_id']]
    ok('Placement '+p['placement_id']+' registered on '+p['screen_id'], p['placement_id'] in s.get('placement_ids',[]))

# Brand exactness: PNG app icon and mark are exact master; SVG wrappers must embed exact bytes.
master=(P/brand['canonical_master']).read_bytes(); master_sha=sha(master)
for rel in ['Design_System/assets/brand/felagi-app-icon.png','Design_System/assets/brand/felagi-mark.png','UI_Handoff/assets/brand/felagi-app-icon.png','UI_Handoff/assets/brand/felagi-mark.png']:
    ok('Exact official raster '+rel, sha((P/rel).read_bytes())==master_sha)
for rel in ['Design_System/assets/brand/felagi-app-icon.svg','Design_System/assets/brand/felagi-mark.svg','Design_System/assets/brand/felagi-lockup.svg','Design_System/assets/brand/felagi-mark-mono.svg','UI_Handoff/assets/brand/felagi-app-icon.svg','UI_Handoff/assets/brand/felagi-mark.svg','UI_Handoff/assets/brand/felagi-lockup.svg','UI_Handoff/assets/brand/felagi-mark-mono.svg']:
    txt=(P/rel).read_text(encoding='utf-8')
    m=re.search(r'base64,([^"\']+)',txt)
    good=False
    if m:
        try: good=sha(base64.b64decode(m.group(1)))==master_sha
        except Exception: good=False
    ok('Exact official artwork embedded '+rel, good)

# Active-doc metadata. Historical provenance intentionally excluded.
active=[]
for p in P.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in {'.md','.txt','.html'}: continue
    rel=p.relative_to(P).as_posix()
    if rel.startswith('Provenance/') or '/Prior_' in rel or rel.startswith('Audit/v1.2') or rel.startswith('Audit/v1.3_'): continue
    active.append((rel,p.read_text(encoding='utf-8',errors='ignore')))
stale=[]
for rel,txt in active:
    if any(x in txt for x in ['package 1.3.0','22 existing mobile screens','corrected22 mobile screens','corrected 22 mobile screens','18 Admin screen definitions','master-source attestation pending']): stale.append(rel)
ok('No stale active release metadata', not stale, ', '.join(stale))
ok('Canonical screen counts 23+23=46', manifest.get('mobile_screen_count')==23 and manifest.get('admin_screen_count')==23 and manifest.get('screen_count')==46)

out={'version':'1.4.2','passed':sum(c['pass'] for c in checks),'total':len(checks),'failed':[c for c in checks if not c['pass']],'checks':checks}
(P/'Audit/semantic-verification-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f"Semantic verification: {out['passed']}/{out['total']} passed")
for f in out['failed']: print('FAIL',f['check'],f['detail'])
sys.exit(0 if not out['failed'] else 1)
