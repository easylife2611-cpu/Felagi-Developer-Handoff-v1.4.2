"""Additional adversarial cross-artifact checks; no device/runtime certification."""
from pathlib import Path
import json,re
P=Path(__file__).resolve().parents[1]
def load(f):return json.loads((P/f).read_text())
checks=[]
def test(id,value):checks.append({'id':id,'status':'PASS' if value else 'FAIL'})
m=load('Design_Data/screen-manifest.json');ss=m['screens'];by={s['id']:s for s in ss};loc={l:load('Localization/app_'+l+'.arb') for l in ['am','en']};cs=load('Design_Data/control-registry.json')['controls'];trace=load('Design_Data/traceability.json');placements=load('Design_Data/placement-registry.json');ads=load('Design_Data/advertising-contract.json')
test('manifest-header-counts',m['screen_count']==len(ss) and m['mobile_screen_count']==23 and m['admin_screen_count']==23 and m['version']=='1.4.1')
test('deliverable-paths',all((P/p).is_file() for p in load('DELIVERABLE_INDEX.json').values()))
test('every-control-trace',all(any(x['requirement']=='CONTROL-'+c['control_id'] and x['screen']==c['screen_id'] for x in trace) for c in cs))
test('every-screen-primary-key',all(s['primary_action_key'] in loc[l] for s in ss for l in loc))
test('every-screen-contract',all(all(s.get(k) for k in ['purpose','entry_points','data_contract','interaction_contract','responsive_contract','accessibility_contract','acceptance_test_id','recovery']) for s in ss))
for prefix,count in [('complete',44),('ads',62)]:
 rows=load('Design_Data/'+prefix+'-requirement-coverage.json')
 test(prefix+'-unique-requirements',len(rows)==count and len({x['requirement'] for x in rows})==count)
 test(prefix+'-owners',all((P/x['canonical_owner']).exists() for x in rows))
 test(prefix+'-real-bindings',all(x['screen'] in by and x['route']==by[x['screen']]['path'] and x['api']==by[x['screen']]['api_mapping_id'] for x in rows))
 test(prefix+'-no-mapped-pass',all('NOT_EXECUTED' in x['evidence_status'] for x in rows))
test('placement-unique',len(placements['placements'])==len({x['placement_id'] for x in placements['placements']})==3)
test('slots-match-manifest',all(s['placement_ids']==[p['placement_id'] for p in placements['placements'] if p['screen_id']==s['id']] for s in ss))
test('sensitive-screens-no-ads',all(not by[s]['placement_ids'] for s in placements['prohibited_screens']))
test('ads-campaign-states-localized',all('adState'+''.join(x.title().split('_')) in loc[l] for x in ads['campaign_states']+ads['slot_states'] for l in loc))
test('ads-no-private-targeting',not set(ads['allowed_targeting'])&set(ads['forbidden_targeting']))
test('three-revenue-domains',all(s in (P/'Product_Design/Final_Master_Product_Design_Specification.md').read_text() for s in ['Need Boosting','Offer Submission Unlock','Sponsored Advertising']))
test('no-invented-production-success','Published≠Applied≠Verified' in (P/'System_Specification/Sponsored_Advertising_Contract.md').read_text() or 'publication and verification remain separate' in (P/'System_Specification/Sponsored_Advertising_Contract.md').read_text())
app=(P/'UI_Handoff/ui-preview/app.js').read_text()
test('ads-recovery-guard',"if(!adsPreview||!allowed()||runtime!=='ready'" in app)
test('admin-integer-canonical-bounds','c.allowed_values?.minimum' in app and 'c.allowed_values?.maximum' in app)
test('no-raw-preview-html',not re.search(r'\.innerHTML\s*=',app))
test('ads-unique-component',all(not any(c in ['FgSponsoredBanner','FgSponsoredCompact'] for c in s['components']) for s in ss))
test('flutter-sponsored-export',"export 'src/sponsored.dart';" in (P/'Design_System/flutter/lib/felagi_design_system.dart').read_text())
test('flutter-sponsored-theme-parity','FgTokens.sponsoredSurfaceDark' in (P/'Design_System/flutter/lib/src/sponsored.dart').read_text())
report={'scope':'Cross-artifact source checks only; manual/device/integration evidence separate','checks':checks};(P/'Audit/completion-verification-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':sum(x['status']=='PASS' for x in checks),'failed':[x for x in checks if x['status']=='FAIL']}));raise SystemExit(any(x['status']=='FAIL' for x in checks))
