# Main Admin Directive Coverage

DESIGNED ≠ IMPLEMENTED ≠ VERIFIED. This matrix locates every directive section; service/device execution remains external. Representative preview is not a full production Admin application.

| Requirement | Canonical placement | Design | Implementation/evidence |
|---|---|---|---|
| A CANONICAL MAIN ADMIN PURPOSE | Product_Design/Final_Master_Product_Design_Specification.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| B INSERT THIS INTO THE PRODUCT FOUNDATION | Product_Design/Final_Master_Product_Design_Specification.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| C ADD A CANONICAL ADMIN CONTROL LOOP | Product_Design/Final_Master_Product_Design_Specification.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| D CREATE THE COMPLETE ADMIN INFORMATION ARCHITECTURE | Design_Data/screen-manifest.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| E ADMIN HOME MUST BE OPERABLE AT A GLANCE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| F PHONE-SETTINGS STYLE FEATURE CONTROLS | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| G SIMPLE MODE + ADVANCED MODE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| H SEPARATE SETTINGS BY RESPONSIBILITY | Design_Data/control-registry.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| I ADD THE CONTROL REGISTRY TO THE FOUNDATION | Design_Data/control-registry.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| J DEPENDENCY-AWARE CONTROLS | Design_Data/control-registry.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| K IMPACT PREVIEW BEFORE HIGH-RISK CHANGES | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| L RISK CLASSIFICATION | Design_Data/control-registry.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| M ADD CHANGE SIMULATION | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| N MONETIZATION CENTER | System_Specification/Monetization_Payment_Specification.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| O SAFE MONETIZATION CHANGE HANDLING | System_Specification/Monetization_Payment_Specification.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| P PAYMENT CENTER MUST GUIDE, NOT DIRECTLY ALTER TRUTH | System_Specification/Monetization_Payment_Specification.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| Q HEALTH CENTER | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| R USER-IMPACT VIEW | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| S SAFE MODE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| T MAINTENANCE CENTER | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| U RECOVERY WIZARD | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| V “I WANT TO…” ADMIN SHORTCUTS | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| W ADMIN SEARCH | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| X CONTENT MANAGEMENT WITHOUT CODE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| Y LOCALIZATION OF ADMIN ITSELF | Localization/app_am.arb | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| Z SECURITY + SECRETS | System_Specification/Admin_Authorization_Contract.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AA PUBLISHED / APPLIED / VERIFIED STATE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AB AUTOMATIC POST-CHANGE VERIFICATION | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| AC CONFIGURATION DRIFT DETECTION | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| AD VERSION HISTORY + ROLLBACK | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AE CHANGE DIFF | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AF CHANGE FREEZE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AG SCHEDULED ADMIN CHANGES | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| AH SAFE PRESETS / OPERATION MODES | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AI BACKUPS + RECOVERY EVIDENCE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| AJ OPERATIONAL TIMELINE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AK “WHAT CHANGED?” VIEW | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| AL ROLE-SAFE DELEGATION | System_Specification/Admin_Authorization_Contract.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AM BULK ACTION SAFETY | System_Specification/Admin_Authorization_Contract.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AN ACCESSIBILITY OF ADMIN | Product_Design/Final_Accessibility_Matrix.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AO RESPONSIVE ADMIN DESIGN | Product_Design/Final_Responsive_Matrix.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AP CONTROL STATE MODEL | Design_Data/control-registry.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AQ ADMIN COMPONENT LIBRARY | Design_System/Final_Component_Library_Specification.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AR DESIGN TOKENS | Design_System/tokens/token_registry.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AS ADMIN ROUTE REGISTRY | Design_Data/screen-manifest.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AT ADMIN SCREEN MANIFEST | Design_Data/screen-manifest.json | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AU ADMIN INTERACTIVE REFERENCE | UI_Handoff/ui-preview/app.js | DESIGNED | PARTIAL_REFERENCE / REQUIRES EVIDENCE |
| AV ADMIN TRANSITION MAP | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AW DEVELOPER TRACEABILITY | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AX FINAL ADMIN ACCEPTANCE GATE | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AY REQUIRED PACKAGE PLACEMENT | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| AZ NO DUPLICATE OWNERSHIP | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| BA DO NOT OVER-BUILD | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| BB FINAL HANDOFF OUTPUT | Admin/Final_Admin_Control_Center_Design.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |
| BC FINAL LOCK STATEMENT | Product_Design/Final_Master_Product_Design_Specification.md | DESIGNED | SPECIFIED / REQUIRES EVIDENCE |

## Major control families

| Control | Screen | Class / risk | Permission | Dependency | Verification / rollback | Test |
|---|---|---|---|---|---|---|
| allowNeeds | A004 | feature / HIGH | admin.control.allowNeeds | whole-proposal validation | required / True | CTRL-allowNeeds |
| allowOffers | A004 | feature / HIGH | admin.control.allowOffers | whole-proposal validation | required / True | CTRL-allowOffers |
| messaging | A004 | feature / HIGH | admin.control.messaging | whole-proposal validation | required / True | CTRL-messaging |
| aiCompare | A004 | feature / HIGH | admin.control.aiCompare | validated provider configuration | required / True | CTRL-aiCompare |
| payments | A007 | feature / CRITICAL | admin.control.payments | whole-proposal validation | required / True | CTRL-payments |
| boost | A020 | feature / HIGH | admin.control.boost | payments=true | required / True | CTRL-boost |
| offerUnlock | A020 | business / HIGH | admin.control.offerUnlock | payments=true when offerUnlock=true and offerFee>0 | required / True | CTRL-offerUnlock |
| offerFee | A020 | business / HIGH | admin.control.offerFee | payments=true when offerUnlock=true and offerFee>0 | required / True | CTRL-offerFee |
| offerCurrency | A020 | business / HIGH | admin.control.offerCurrency | whole-proposal validation | required / True | CTRL-offerCurrency |
| boostPackages | A020 | business / HIGH | admin.control.boostPackages | whole-proposal validation | required / True | CTRL-boostPackages |
| telegram | A002 | feature / HIGH | admin.control.telegram | whole-proposal validation | required / True | CTRL-telegram |
| safeMode | A019 | operation / CRITICAL | admin.control.safeMode | whole-proposal validation | required / True | CTRL-safeMode |
| maintenance | A021 | operation / HIGH | admin.control.maintenance | whole-proposal validation | required / True | CTRL-maintenance |
| freeze | A017 | operation / CRITICAL | admin.control.freeze | whole-proposal validation | required / True | CTRL-freeze |
| maxOffers | A005 | configuration / MEDIUM | admin.control.maxOffers | whole-proposal validation | required / True | CTRL-maxOffers |
| aiModel | A006 | configuration / HIGH | admin.control.aiModel | whole-proposal validation | required / True | CTRL-aiModel |
| aiTimeout | A006 | configuration / MEDIUM | admin.control.aiTimeout | whole-proposal validation | required / True | CTRL-aiTimeout |
| retryLimit | A012 | configuration / MEDIUM | admin.control.retryLimit | whole-proposal validation | required / True | CTRL-retryLimit |
| rateLimit | A015 | configuration / HIGH | admin.control.rateLimit | whole-proposal validation | required / True | CTRL-rateLimit |
| queueConcurrency | A012 | configuration / MEDIUM | admin.control.queueConcurrency | whole-proposal validation | required / True | CTRL-queueConcurrency |
| welcomeText | A009 | content / LOW | admin.control.welcomeText | whole-proposal validation | required / True | CTRL-welcomeText |
| supportText | A009 | content / LOW | admin.control.supportText | whole-proposal validation | required / True | CTRL-supportText |
| maintenanceText | A021 | content / LOW | admin.control.maintenanceText | whole-proposal validation | required / True | CTRL-maintenanceText |
| helpText | A009 | content / LOW | admin.control.helpText | whole-proposal validation | required / True | CTRL-helpText |
| policyText | A009 | content / HIGH | admin.control.policyText | whole-proposal validation | required / True | CTRL-policyText |
| noticeText | A009 | content / LOW | admin.control.noticeText | whole-proposal validation | required / True | CTRL-noticeText |
| paymentSecret | A015 | secret / CRITICAL | admin.control.paymentSecret | whole-proposal validation | required / False | CTRL-paymentSecret |
| aiSecret | A015 | secret / CRITICAL | admin.control.aiSecret | whole-proposal validation | required / False | CTRL-aiSecret |
| telegramSecret | A015 | secret / CRITICAL | admin.control.telegramSecret | whole-proposal validation | required / False | CTRL-telegramSecret |
| reconcilePayment | A007 | operation / HIGH | admin.control.reconcilePayment | whole-proposal validation | required / False | CTRL-reconcilePayment |
| retryJob | A012 | operation / MEDIUM | admin.control.retryJob | whole-proposal validation | required / False | CTRL-retryJob |
| checkIntegrity | A014 | operation / MEDIUM | admin.control.checkIntegrity | whole-proposal validation | required / False | CTRL-checkIntegrity |
| refreshCache | A021 | operation / MEDIUM | admin.control.refreshCache | whole-proposal validation | required / False | CTRL-refreshCache |
| verifyBackup | A013 | operation / HIGH | admin.control.verifyBackup | whole-proposal validation | required / False | CTRL-verifyBackup |
| restoreBackup | A018 | operation / CRITICAL | admin.control.restoreBackup | whole-proposal validation | required / False | CTRL-restoreBackup |
| suspendUser | A008 | operation / HIGH | admin.control.suspendUser | whole-proposal validation | required / False | CTRL-suspendUser |
| reviewReport | A022 | operation / MEDIUM | admin.control.reviewReport | whole-proposal validation | required / False | CTRL-reviewReport |
| notificationRetry | A010 | operation / MEDIUM | admin.control.notificationRetry | whole-proposal validation | required / False | CTRL-notificationRetry |
| fileQuarantine | A011 | operation / HIGH | admin.control.fileQuarantine | whole-proposal validation | required / False | CTRL-fileQuarantine |
| telegramDestination | A002 | configuration / HIGH | admin.control.telegramDestination | whole-proposal validation | required / True | CTRL-telegramDestination |
| diagnose | A018 | operation / LOW | admin.control.diagnose | whole-proposal validation | required / False | CTRL-diagnose |
