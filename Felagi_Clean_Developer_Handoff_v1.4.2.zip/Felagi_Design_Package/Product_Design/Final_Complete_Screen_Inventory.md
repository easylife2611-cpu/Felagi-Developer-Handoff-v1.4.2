# Complete Screen Inventory — 1.4

46 canonical screens:23 user,23 Admin. Generated route/state/API bindings use this same manifest.

| ID | Name | Path | Primary action | Ads |
|---|---|---|---|---|
| S001 | Welcome | /welcome | signIn | NO_ADS |
| S002 | Telegram sign-in | /auth/telegram | signIn | NO_ADS |
| S003 | Profile | /profile | save | NO_ADS |
| S004 | Browse Needs | /browse | createNeed | AD_BROWSE_INLINE_01, AD_SEARCH_RESULTS_INLINE_01 |
| S005 | Create/Edit Need | /needs/new | continue | NO_ADS |
| S006 | Public-post preview | /needs/new/public-preview | continue | NO_ADS |
| S007 | Need-created confirmation | /needs/:id/created | screenS010 | NO_ADS |
| S008 | Need details | /needs/:id | completeNeed | AD_NEED_DETAIL_BOTTOM_01 |
| S009 | My Needs | /my/needs | view | NO_ADS |
| S010 | Received Offers | /needs/:id/offers | compare | NO_ADS |
| S011 | Submit/Edit Offer | /needs/:id/offers/new | submit | NO_ADS |
| S012 | Offer details | /offers/:id | accept | NO_ADS |
| S013 | My Offers | /my/offers | view | NO_ADS |
| S014 | Compare confirmation | /needs/:id/compare | evaluateOffers | NO_ADS |
| S015 | AI comparison result | /comparisons/:id | reviewOffer | NO_ADS |
| S016 | Comparison history/export | /needs/:id/comparisons | compareAgain | NO_ADS |
| S017 | Messages | /offers/:id/messages | send | NO_ADS |
| S018 | Notifications | /notifications | view | NO_ADS |
| S019 | Boost/Payments | /needs/:id/boost | checkout | NO_ADS |
| S020 | Rating | /needs/:id/rating | save | NO_ADS |
| S021 | Report/Support | /support/report | save | NO_ADS |
| S022 | Telegram status/stop | /needs/:id/publications | stop | NO_ADS |
| S023 | Offer Submission Unlock | /needs/:id/offers/unlock | submit | NO_ADS |
| A001 | Dashboard | /admin/dashboard | viewEvidence | NO_ADS |
| A002 | Telegram Distribution | /admin/telegram | viewEvidence | NO_ADS |
| A003 | Health | /admin/health | viewEvidence | NO_ADS |
| A004 | Features | /admin/features | publish | NO_ADS |
| A005 | Marketplace | /admin/marketplace | viewEvidence | NO_ADS |
| A006 | AI | /admin/ai | publish | NO_ADS |
| A007 | Payments | /admin/payments | viewEvidence | NO_ADS |
| A008 | Users | /admin/users | viewEvidence | NO_ADS |
| A009 | Content | /admin/content | publish | NO_ADS |
| A010 | Notifications | /admin/notifications | viewEvidence | NO_ADS |
| A011 | Files | /admin/files | viewEvidence | NO_ADS |
| A012 | Jobs | /admin/jobs | viewEvidence | NO_ADS |
| A013 | Backups | /admin/backups | viewEvidence | NO_ADS |
| A014 | Integrity | /admin/integrity | viewEvidence | NO_ADS |
| A015 | Security | /admin/security | viewEvidence | NO_ADS |
| A016 | Audit | /admin/audit | viewEvidence | NO_ADS |
| A017 | Settings | /admin/settings | publish | NO_ADS |
| A018 | Recovery | /admin/recovery | viewEvidence | NO_ADS |
| A019 | Safe Mode | /admin/safe-mode | publish | NO_ADS |
| A020 | Monetization | /admin/monetization | publish | NO_ADS |
| A021 | Maintenance | /admin/maintenance | publish | NO_ADS |
| A022 | Reports | /admin/reports | viewEvidence | NO_ADS |
| A023 | Sponsored Ads | /admin/monetization/sponsored-ads | publish | NO_ADS |
