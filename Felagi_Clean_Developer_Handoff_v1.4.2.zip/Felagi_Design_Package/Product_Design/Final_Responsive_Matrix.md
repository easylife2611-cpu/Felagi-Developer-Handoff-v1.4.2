# Final Responsive Matrix

One logical content model, actual application reflow rather than shrinking phone frames. CSS viewport px maps to logical dp for design references; native Flutter uses logical pixels. No orientation lock.

| Range | Navigation | Content | Action and overflow |
|---|---|---|---|
| <360 | Five labelled mobile destinations at bottom in flow | 1 column,16 gutter | Full-width actions, minimum48 targets, wrap labels; no document x-scroll |
| 360–599 | Same bottom navigation | 1 column,16 gutter | Create after filters, primary actions in normal flow; composer above keyboard |
| 600–839 | 88dp labelled rail | 2 data-card columns,24 gutter | Header-right Create; form max720; no tiny text scaling |
| 840–1199 | Rail | 3 browse columns; detail2:1; tables with card fallback;24 gutter | Forms remain max720, reading760; tables only when accessible content fits |
| 1200–1599 | 256dp labelled sidebar | 32 gutter; Admin list/detail3:2; bounded content | Consequence dialog max560; no actions hidden at viewport edge |
| ≥1600 | Sidebar | Center max1280; same columns | No optional pane; preserve reading limits |

At 200% text and 400% browser zoom, reflow using the resulting logical viewport. Tables become labelled record cards below840; comparison shows criterion/weight/score/evidence in reading order. Long IDs/URLs wrap and use directional isolation. Horizontal scrolling is limited to inherently two-dimensional data with a card/text alternative. Avoid fixed heights around copy. Device safe areas add to padding; keyboard resizes content and keeps focused field/send reachable.

| Screens | Template-specific adaptation |
|---|---|
| S001/S002 | Center max440, full lockup scales without distortion, buttons wrap |
| S003/S005/S011/S020/S021 | Single form column at all widths, max720; helper/error expands; field min56 |
| S004/S009/S013 | Cards1/2/3; five nav destinations retained; filter controls wrap |
| S006/S007 | Public copy remains exact; max760 reading; consent/actions not separated by clipping |
| S008/S012 | Detail single column below840, 2:1 summary/actions above; logical DOM order unchanged |
| S010 | Cards below840, accessible table/list above; compare primary remains visible in flow |
| S014/S015 | Criteria stack/cards below840, matrix above; same weights/data/projection |
| S016/S022 | Labelled record cards below840, header-associated table above |
| S017 | Thread+composer single column, keyboard-aware; no inverted reading order |
| S018 | Notification cards, read label and time wrap; no color-only unread marker |
| S019 | Package/payment cards stack; amount/currency visible together; handoff return preserves pending |
| A001–A022 | Labelled mobile navigation list plus screen selector; bounded table/card; detail inline below1200, pane above |

Verification widths: 320,359,360,599,600,839,840,1199,1200,1599,1600. Test both locales/themes, portrait/landscape and long-string fixtures. Actual renderer/device results are recorded separately from specification completeness.


## Added surfaces S023 and A019–A022
At320–599: single column, wrapped quote/diff, full-width controls, inline detail and cards; all primary and recovery actions in document flow. At600–839: rail, single-column form. At840–1199: evidence table with caption and detail below; payment form max720. At1200–1599: sidebar, detail panel when space permits. At1600+: centered1280 content. Native dialog max560 and viewport padding; internal scroll preserves visible actions without fixed text heights. 200% text scaling, long Ethiopic strings, mixed-direction identifiers and huge ETB values must wrap without horizontal page scrolling. Grid minmax(0,1fr); amount bdi; no truncated critical warning. Test same edge fixtures at every width and both themes/locales; static rules do not constitute render proof.


## Comparison/continuity refinement1.4
S014 single-column summary/selection mobile, wide rubric plus selection desktop. S015 cards and expandable criteria mobile; semantic matrix plus text/cards desktop. Bottom Review/Choose action may stick only when viewport permits; at200% text or keyboard/short viewport revert in-flow. S016 history table becomes labelled cards. No layout jump from scores, skeletons or expanded detail. Restore route scroll after data geometry and focus restoration; cached content is timestamped. Test320/360/600/840/1200/1600 widths,200% text and longest Amharic content in both themes. Real-device evidence remains pending.


## Per-screen acceptance bindings1.4
### S001
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S001; execution status REQUIRES_EVIDENCE.

### S002
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S002; execution status REQUIRES_EVIDENCE.

### S003
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S003; execution status REQUIRES_EVIDENCE.

### S004
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: AD_BROWSE_INLINE_01, AD_SEARCH_RESULTS_INLINE_01. Test SCREEN-S004; execution status REQUIRES_EVIDENCE.

### S005
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S005; execution status REQUIRES_EVIDENCE.

### S006
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S006; execution status REQUIRES_EVIDENCE.

### S007
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S007; execution status REQUIRES_EVIDENCE.

### S008
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: AD_NEED_DETAIL_BOTTOM_01. Test SCREEN-S008; execution status REQUIRES_EVIDENCE.

### S009
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S009; execution status REQUIRES_EVIDENCE.

### S010
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S010; execution status REQUIRES_EVIDENCE.

### S011
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S011; execution status REQUIRES_EVIDENCE.

### S012
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S012; execution status REQUIRES_EVIDENCE.

### S013
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S013; execution status REQUIRES_EVIDENCE.

### S014
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S014; execution status REQUIRES_EVIDENCE.

### S015
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S015; execution status REQUIRES_EVIDENCE.

### S016
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S016; execution status REQUIRES_EVIDENCE.

### S017
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S017; execution status REQUIRES_EVIDENCE.

### S018
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S018; execution status REQUIRES_EVIDENCE.

### S019
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S019; execution status REQUIRES_EVIDENCE.

### S020
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S020; execution status REQUIRES_EVIDENCE.

### S021
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S021; execution status REQUIRES_EVIDENCE.

### S022
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S022; execution status REQUIRES_EVIDENCE.

### S023
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-S023; execution status REQUIRES_EVIDENCE.

### A001
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A001; execution status REQUIRES_EVIDENCE.

### A002
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A002; execution status REQUIRES_EVIDENCE.

### A003
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A003; execution status REQUIRES_EVIDENCE.

### A004
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A004; execution status REQUIRES_EVIDENCE.

### A005
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A005; execution status REQUIRES_EVIDENCE.

### A006
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A006; execution status REQUIRES_EVIDENCE.

### A007
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A007; execution status REQUIRES_EVIDENCE.

### A008
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A008; execution status REQUIRES_EVIDENCE.

### A009
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A009; execution status REQUIRES_EVIDENCE.

### A010
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A010; execution status REQUIRES_EVIDENCE.

### A011
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A011; execution status REQUIRES_EVIDENCE.

### A012
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A012; execution status REQUIRES_EVIDENCE.

### A013
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A013; execution status REQUIRES_EVIDENCE.

### A014
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A014; execution status REQUIRES_EVIDENCE.

### A015
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A015; execution status REQUIRES_EVIDENCE.

### A016
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A016; execution status REQUIRES_EVIDENCE.

### A017
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A017; execution status REQUIRES_EVIDENCE.

### A018
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A018; execution status REQUIRES_EVIDENCE.

### A019
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A019; execution status REQUIRES_EVIDENCE.

### A020
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A020; execution status REQUIRES_EVIDENCE.

### A021
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A021; execution status REQUIRES_EVIDENCE.

### A022
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A022; execution status REQUIRES_EVIDENCE.

### A023
320–599:one-column, full-width bounded form, wrapping title/actions;600–839:rail and two-column cards only where appropriate;840–1199:three-column browse and responsive detail/table;1200+:sidebar with max content width. At200% text/400% zoom reflow; keyboard/short viewport disables sticky action; preserve source order and safe area. Test long Amharic/mixed text, huge ETB,0/1/50 Offers and offline/error. No clipping essential copy. Placement: NO_ADS. Test SCREEN-A023; execution status REQUIRES_EVIDENCE.
