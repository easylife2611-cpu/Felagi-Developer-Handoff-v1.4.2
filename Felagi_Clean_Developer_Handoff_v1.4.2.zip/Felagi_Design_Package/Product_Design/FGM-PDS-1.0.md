# ፈላጊ — የሙሉ ምርት ንድፍ ውል

**መለያ፦ FGM-PDS-1.0 | የምርት ሥልጣን፦ DFM-FDS-1.4 | የእይታ መሠረት፦ FGM-DS-1.0 | ሁኔታ፦ የንድፍ ውል ተጠናቋል፤ የምርት ማስረጃ ይፈልጋል**

> ይህ ሰነድ የፈላጊን የተቆለፈ ማንነት፣ የፍላጎት-ቀዳሚ ሂደትና የB ሎጎ መሠረትን ይጠብቃል። የንግድ ሕጎችን አይቀይርም። ናሙና መኖሩ ተተግብሯል ማለት አይደለም።

## 0. የሥልጣን ቅደም ተከተልና ሕጎች

- DFM-FDS-1.4 የምርት፣ የፈቃድ፣ የAPIና የሁኔታ ሕጎችን ይወስናል። FGM-PDS-1.0 የማያ ገጽና የተግባር ውል ነው። FGM-DS-1.0 የእይታ መሠረት ነው።
- የቶከን ምንጭ `Design_System/tokens/token_registry.json` ነው፤ `design_tokens.json` ለFlutter የተዘጋጀ ማዛመድ ነው። በfeature code ውስጥ arbitrary የቀለም/spacing እሴት አይፈጠርም።
- UNKNOWN ≠ ZERO፤ PARTIAL ≠ COMPLETE፤ STALE ≠ FALSE፤ CONFLICTING ≠ ERROR። ያልተመዘገበ ነገር አውቆ እንደጎደለ አይቆጠርም።
- የውጭ መሣሪያ እንደ deliverable፣ dependency ወይም future step አይጠቀምም። የቀድሞው ፓኬጅ ውስጥ የነበሩት ተያያዥ ፋይሎች በዚህ ስሪት ተወግደዋል።

## 1. የመጀመሪያ ኦዲት

ሁኔታዎች፦ MET / PARTIAL / GAP / UNKNOWN / N/A / REQUIRES EVIDENCE. UNKNOWN በተመረመረው ፋይል ማስረጃ አልታየም ማለት ነው፤ ንድፉ እንደሌለ አያረጋግጥም።

| # | መስፈርት | የመጀመሪያ ሁኔታ | የታየ ማስረጃ |
|---|---|---|---|
| 1 | Design foundations | PARTIAL | ቀለም/ፊደል/spacing ነበሩ፤ grid, layer, shadow, density አልተሟሉም። |
| 2 | Token architecture | PARTIAL | ጠፍጣፋ JSON ነበር፤ raw→primitive→semantic→component አልነበረም። |
| 3 | Component library | PARTIAL | Flutter starter/catalog ነበሩ፤ props/behavior/keyboard/a11y አልተሟሉም። |
| 4 | Component states | PARTIAL | የጋራ preview state selector ነበር፤ ለcomponent ተግባራዊ ሁኔታዎች አልተወሰኑም። |
| 5 | IA/routes | PARTIAL | አምስት የታች አሰሳዎች ነበሩ፤ deep link/back/access አልተገለጸም። |
| 6 | User journeys | PARTIAL | ዋና ምርት ሂደት በDFM አለ፤ cancel/retry/resume/session failure አልተያያዘም። |
| 7 | Screen inventory | MET | 22 ማያዎችና 6 overlays በmanifest ነበሩ፤ canonical S-ID ግን አልነበረም። |
| 8 | Screen visual detail | GAP | ትንሽ ካርድ ማሳያ ነበር፤ መጠን/ቦታ/sticky/scroll አልተወሰነም። |
| 9 | Interaction contract | GAP | trigger→precondition→result→failure→recovery ውል አልነበረም። |
| 10 | Runtime states | PARTIAL | loading/empty/error ነበሩ፤ unknown/partial/stale/conflict/degraded አልተለዩም። |
| 11 | Responsive rules | PARTIAL | CSS መላመድ ነበር፤ breakpoint/reflow ሕግ አልነበረም። |
| 12 | Accessibility | PARTIAL | WCAG ግብ ነበር፤ ክፍል/ሙከራ ማትሪክስ አልነበረም። |
| 13 | Localization | PARTIAL | አማርኛ ቀዳሚ ነው፤ የቃላት፣ ቀን፣ ገንዘብና መስመር ሕጎች አልተሟሉም። |
| 14 | Data/trust UX | PARTIAL | AI መስፈርቶች በDFM አሉ፤ source/freshness/unknown ማሳያ አልተወሰነም። |
| 15 | Privacy/consent | PARTIAL | Telegram preview/stop አለ፤ projection/revoke/session UX አልተሟላም። |
| 16 | Failure/recovery | PARTIAL | offline/error ተጠቅሰዋል፤ timeout/partial/upload/payment/AI recovery አልተሟላም። |
| 17 | Transition map | GAP | ዋና ሽግግሮች በroute አልተያያዙም። |
| 18 | Developer traceability | PARTIAL | API mapping አለ፤ requirement→screen→state→recovery→test አልነበረም። |
| 19 | Second-pass audit | GAP | የማስረጃ ያለው የድጋሚ ግምገማ አልነበረም። |
| 20 | Deliverables | GAP | የቀድሞው ጥቅል የውጭ የንድፍ መሣሪያ ስም የያዙ መመሪያዎችን አካትቶ ነበር፤ ከመሣሪያ-ገለልተኛ ማስረከቢያ መመሪያ ጋር ይጋጫል። |

**የኦዲት ምንጭ፦** DFM-FDS-1.4፣ FGM-DS-1.0፣ FGM-UI-HO-1.0፣ `design_tokens.json`፣ `screen-manifest.json`፣ HTML preview፣ Flutter starterና የጥቅሉ ፋይሎች። የመሣሪያ/production test ማስረጃ በመጀመሪያ ፓኬጅ አልነበረም።

## 2. የተቆለፈ የእይታ መሠረት

### 2.1 የብራንድ
Logo B መሠረት ነው። ሙሉ ሎጎ በWelcome/auth/brand surface ላይ፤ mark-only በBrowse አሞሌና app icon ላይ፤ ውስጣዊ ገጽ ላይ መመለሻ+ርዕስ ብቻ፤ bottom navigation ላይ logo አይደገምም። የይፋዊ ቴሌግራም ጽሑፍ የተጠቃሚ ፎቶ/ስልክ/መለያ አያካትትም። ሎጎን አታራዝሙ፣ ቀለም/ጥላ አትቀይሩ። SVG/PNG assets፦ mark, Amharic lockup, dark lockup, mono mark, app icon, transparent 512px mark PNG, 512px app-icon PNG።

### 2.2 Foundations
- ቀለም፦ primary navy `#003366`; orange `#FF9933`; light canvas `#F4F6F8`; surface `#FFFFFF`; text `#192431`/`#586675`; decorative divider `#D8E0E7`, essential control border `#738496`; success `#176B35`; error `#B42335`; warning `#8A4B00`; info `#155EEF`. Dark counterparts በtoken registry ውስጥ።
- ፊደል፦ Noto Sans Ethiopic፣ የመሣሪያ የEthiopic sans-serif fallback። Display 32/40-700; page 24/32-700; section 18/26-600; body 16/24-400; secondary 14/20-400; short label 12/16-500.
- spacing፦ 0,4,8,12,16,24,32,40,48,64dp; mobile gutter 16, tablet 24, desktop 32.
- control 48dp; prominent/input 56dp; minimum touch target 48×48dp; icon 16/20/24/32dp.
- radius 8/12/16/24/999dp; border 1dp; focus ring 2dp; shadows none / `0 1px 3px rgba(16,32,48,.08)` / `0 8px 24px rgba(16,32,48,.12)`.
- opacity disabled .48, scrim .40, decoration .08; motion 120/200/280ms; respect reduced-motion OS setting.
- z-layer: base 0, sticky 10, menu 20, scrim 30, sheet 40, toast 50, system 60.
- one primary action per screen; state always text+icon+color, never color alone; orange is action accent, never error or long-text background; no white body text on orange.

### 2.3 Responsive layout
| Width | Rule |
|---|---|
| `<360dp` | 1 column, full-width primary action, 16dp gutter. |
| `360–599dp` | mobile, 1 column, bottom nav, sticky CTA above keyboard/safe area. |
| `600–839dp` | tablet, 2 card columns, 24dp gutter. |
| `840–1199dp` | laptop, nav rail, 2–3 columns, form max 720dp. |
| `1200–1599dp` | desktop, sidebar/content, 3 columns or accessible table. |
| `≥1600dp` | max content 1280dp, no additional context pane; keep reading width bounded. |

## 3. Token architecture

Value path: `raw → primitive → semantic → component → rendered`. `Design_System/tokens/token_registry.json` is canonical and records value/purpose/allowed/prohibited/theme; `design_tokens.json` is runtime mapping. Component code consumes semantic/component names; no inline arbitrary colors or spacing. If a new value is needed, justify it, add it to registry, update Flutter/preview and tests together.

| Raw value → primitive | Semantic | Component token | Prohibited use |
|---|---|---|---|
| `#003366` → `color.primitive.brand.navy.900` | `color.brand.primary` | `navigation.selected`, `button.secondary.border` | small text before contrast pass |
| `#FF9933` → `color.primitive.brand.orange.500` | `color.brand.accent` | `button.primary.background`, `badge.boost.background` | white text, error, full page canvas |
| `#192431` → `color.primitive.neutral.ink` | `color.text.primary` | `button.primary.foreground`, `card.title` | dark canvas without test |
| `#F4F6F8` → `color.primitive.neutral.paper` | `color.surface.canvas` | `screen.background` | flattening card hierarchy |
| `#FFFFFF` → `color.primitive.neutral.white` | `color.surface.card` | `card.background`, `input.background` | merging surfaces unintentionally |
| `#586675` → `color.primitive.neutral.muted` | `color.text.secondary` | `helper`, `meta` | critical small text before contrast test |
| `#738496` → `color.primitive.neutral.line` | `color.border.default` | `card.border`, `input.border` | text color |
| `16dp` → `space.4` | `layout.pageGutter.mobile` | `screen.horizontalPadding` | feature-specific ad hoc margin |
| `48dp` → `size.controlStandard` | `size.minimumTouchTarget` | `button.height`, `nav.target` | touch target below 48dp |
| `16dp radius` → `radius.card` | `shape.container` | `need.card.radius` | inconsistent card corners |
| `200ms` → `motion.duration.standard` | `motion.transition.normal` | `sheet.enter.duration` | ignoring reduced-motion |

Token families: `color.*`, `text.*`, `surface.*`, `border.*`, `space.*`, `size.*`, `radius.*`, `shadow.*`, `opacity.*`, `motion.*`, `breakpoint.*`, `layer.*`, `density.*`, `icon.*`, `layout.*`. Product status semantics include Need, Offer, Comparison, Payment, Boost, Telegram states, each with color+icon+Amharic label. Component tokens resolve to semantic tokens, not raw values.

## 4. Component library & states

Hierarchy: `Primitive → Component → Composite → Pattern → Template → Screen`.

| Component | Anatomy/size/props/variants | Behavior/responsive/accessibility |
|---|---|---|
| `FgButton` | label, optional icon; 48dp standard, 56dp primary; primary/secondary/tertiary/destructive | full width on crowded mobile; Enter/Space; loading prevents duplicate; states default/hover/focus/pressed/disabled/loading/success/error. |
| `FgTextLink` | label/destination/external marker | wraps; 48dp target; link semantics/focus. |
| `FgIconButton` | 48×48 box, 20–24 icon, required accessible name | tooltip desktop; focus/pressed/disabled/loading. |
| `FgTextField` | visible label, ≥56dp field, helper/error, required/read-only | placeholder never replaces label; validation linked; focus/read-only/disabled/error. |
| `FgSearchField` | search icon, query, clear, hint | debounced query, cancel stale request; loading/zero result semantics. |
| `FgSelect` | label/value/disclosure/options | mobile sheet, wide popover; arrows/type-ahead/Esc; empty/loading/error/selected. |
| `FgCheckbox` | 20dp mark, labelled ≥48dp row | Space toggles; selected/disabled/error. |
| `FgRadioGroup` | labelled options/value | arrows move, Space selects; group/error semantics. |
| `FgSwitch` | label + 40×24 visual; ≥48dp row | reversible preference only; switch state announced. |
| `FgChip` | text/optional count/remove | scrollable group, selected state announced. |
| `FgBadge` | label+optional icon+semantic tone | status text is mandatory; never color only. |
| `FgNeedCard` | title/category/status/budget/location/age/offer count/boost | 1/2/3 columns across widths; public projection only. |
| `FgOfferCard` | provider projection/price/proposal/delivery/status | selection explicit; no hidden ranking. |
| `FgComparisonCriterion` | criterion/weight/score/evidence/coverage/missing | mobile card; desktop matrix plus text alternative; UNKNOWN explicit. |
| `FgFilterBar` | query/chips/result count/reset | mobile opens sheet; filters removable and announced. |
| `FgTabs` | labels/selected marker | tab semantics/arrows; scroll if needed. |
| `FgNavigation` | 5 labelled items/unread count | bottom mobile, rail wide; create action is separate. |
| `FgListTable` | headers/rows/sort/loading/end | tables convert to cards narrow; header associations. |
| `FgPagination` | previous/current/next/load more | only server-supported count; announce new result range. |
| `FgDialog/Sheet` | title/summary/actions; 24dp sheet top radius | mobile bottom sheet, wide dialog; focus trap/return/Escape/back safe. |
| `FgMenu/Popover` | trigger/options | clamp viewport; keyboard arrows/Esc; return focus. |
| `FgTooltip` | concise help | not sole label; hover/focus desktop, tap mobile. |
| `FgAlert/Banner` | icon/title/body/action/dismiss | inline/top; appropriate live announcement. |
| `FgToast` | brief message/optional undo | safe area, 5s; persistent failure also inline. |
| `FgProgress/Skeleton` | labelled progress/content-shaped placeholders | preserve layout; no fake percentage; reduced motion. |
| `FgEmptyState` | illustration/title/reason/next action | distinguish empty from zero-result/unknown. |
| `FgErrorState` | human message/ref/retry/back | no stack trace; preserve data. |
| `FgAttachmentPicker` | add/list/type/size/progress/remove/retry | per-file states; only server-approved types. |
| `FgPublicPostPreview` | exact public text/destinations/consent | unchecked consent; stale preview must be reviewed again. |
| `FgTelegramDeliveryStatus` | destination/status/time/safe detail/stop | uncertain prominent; no blind retry or fake reach. |
| `FgPaymentStatus` | amount/currency/masked reference/state/next step | only server verifies payment. |
| `FgMessageComposer` | labelled multiline/limit/send | keyboard aware; failed outgoing stays marked unsent. |
| `FgRatingControl` | five labelled choices/optional text | accessible radio group and verbal scale. |

Universal state vocabulary: `Default / Hover / Focus / Pressed / Active / Selected / Disabled / Loading / Success / Warning / Error / Read-only / Empty / Permission Restricted`. Apply only when meaningful; otherwise record N/A. All controls have visible focus, accessible names, disabled reason, loading feedback and failure recovery. Form label is visible; helper/error is programmatically linked; long text wraps; only controls get fixed height.

Patterns: secure sign-in; search/browse; Need creation; Offer submission; requester decision; snapshot comparison; verified payment/boost; participant conversation; authorized public distribution; recovery. A pattern may not introduce an unapproved business rule.

## 5. IA, routes, navigation, journeys

Navigation: **ፍላጎቶች / የእኔ ፍላጎቶች / የእኔ አቅርቦቶች / ማሳወቂያዎች / መገለጫ**. Create Need is a separate primary action. Need → offers/compare/boost/publication; Offer → participant messages; notification → reauthorized deep link; completed relation → rating.

Routes: `/welcome`, `/auth/telegram`, `/profile/setup`, `/browse`, `/my/needs`, `/my/offers`, `/needs/new`, `/needs/:id`, `/needs/:id/edit`, `/needs/:id/offers`, `/needs/:id/offers/new`, `/offers/:id`, `/offers/:id/messages`, `/needs/:id/compare`, `/comparisons/:id`, `/needs/:id/comparisons`, `/notifications`, `/needs/:id/boost`, `/needs/:id/rating`, `/needs/:id/publications`, `/support/report`. Protected routes reauthorize at every entry. Forbidden and not-found do not leak private record existence. Back restores origin/filter/scroll. Dirty form asks save/discard/stay. After session expiry reauthenticate, reauthorize, never replay payment/accept/post automatically.

| Journey | Happy path | Cancel/failure/retry/resume |
|---|---|---|
| J01 Sign in | S001→S002→Telegram→S003 if needed→S004 | denial/expiry retry; interruption restores auth context only. |
| J02 Discover | S004 search/filter→S008 | zero results offer clearing filters; stale data labelled; timeout retains query. |
| J03 Post Need | S004→S005→files→S006→consent→S007 | stale preview→S005; offline draft; Need success and Telegram status separate. |
| J04 Submit Offer | S008→S011→S012/S013 | duplicate/deadline/conflict retains draft; server status required. |
| J05 Decide Offer | S009/S010→S012→O01/O02 | cancel returns; conflict refresh/reconfirm; owner alone decides. |
| J06 Compare | S010→S014→snapshot→S015→requester decision | none→S010; over cap→O06; AI failure retries same snapshot, never fabricates score. |
| J07 Message | S012→S017→send | offline draft; sent/unsent/unknown distinguished; reconcile before retry. |
| J08 Notification | S018→read→authorized target | read failure rollback; invalid target safe route. |
| J09 Boost | S008→S019→provider→pending→verified | app return not proof; timeout pending/reconcile; mismatch review. |
| J10 Rate | completed→S020→submit | duplicate says already rated; offline draft only. |
| J11 Telegram | S005→S006→S007→S022 | stop→O05; posted copy may remain; uncertain reconciled first. |
| J12 Report | source→S021→reference | offline draft; rate limit shows wait; error retains fields. |
| J13 Session expiry | protected route→reauth→original route | reauthorize; no automatic destructive/payment replay. |

## 6. Canonical screen inventory and visual specification

S001–S022 map in order to manifest UI-01–UI-22. Sizes are dp. Shared: app bar 56–64; gutters 16/24/32; standard control≥48; field≥56; sticky CTA above keyboard/safe-area.

| ID | Route / purpose / role | Top-to-bottom layout, data, permissions, main actions, states, responsive and recovery |
|---|---|---|
| S001 (UI-01) Welcome `/welcome` | Public entry. Full lockup centered; short purpose; primary sign-in; language option. Authenticated return→S004. States default/auth error/offline. Content max 440dp; logo read once; S002. |
| S002 (UI-02) Telegram sign-in `/auth/telegram` | Anonymous. Back/title; explanation/privacy; Telegram action; help. OIDC start/callback/exchange; no phone/OTP. States starting/awaiting/denied/expired/error/offline; focus order; retry fresh; S001/S003. |
| S003 (UI-03) Profile setup `/profile/setup` | Own account only. Title; visible fields; optional photo; fixed save. GET me/PATCH profile. States loading/prefilled/validation/saving/saved/conflict/offline; form max720; linked errors; S002/S004. |
| S004 (UI-04) Browse `/browse` | AppBar 64 with mark; search 48; category chips; filter/sort; need feed; separate create action; 5-item nav. GET categories/needs; public projection. States loading/skeleton/list/empty/zero/partial/stale/error/offline. Mobile1/tablet2/laptop3 card columns; S005/S008/S009/S013/S018. |
| S005 (UI-05) Create/edit Need `/needs/new`, `/needs/:id/edit` | Header; title/category/description/budget/currency/location/deadline; multi-file attachments; public intent; save draft/continue. POST/PUT Need + attachment API; authenticated requester; edit only owner OPEN. Draft/validation/upload/saving/conflict/offline; form max720; retain input; S004/S006/S007. |
| S006 (UI-06) Public preview `/needs/new/public-preview` | Back/title; privacy note; exact outgoing post; destination policy; unchecked consent; confirm/edit. Uses the locked local public projection before creation; server validates the same fields at commit; stale needs renewed review. Ready/ack/stale/restricted/error/offline; exact copy screen-reader readable; S005/S007/S022. |
| S007 (UI-07) Created `/needs/:id/created` | Success/reference; Need state; separate Telegram status; detail CTA and browse secondary. POST response + publication status; creation ≠ successful post. Confirmed/queued/partial/unknown/error; S008/S009/S022. |
| S008 (UI-08) Need detail `/needs/:id` | Back/title; status/category/title/description/budget/location/deadline/files; role-specific action group. GET Need; public vs owner projection. Provider offer CTA; owner offers/compare/edit/cancel/boost/publication. Loading/public/owner/empty/terminal/partial/stale/forbidden/offline; desktop split view; S004/S005/S010/S011/S014/S019/S022. |
| S009 (UI-09) My Needs `/my/needs` | Title/create; status filters; sort; cards with status/count/boost/date; pagination. GET my needs, self only. Loading/list/empty/zero/partial/stale/error/offline; mobile1/tablet2; filters accessible; S005/S008/S010. |
| S010 (UI-10) Received offers `/needs/:id/offers` | Need summary; eligible count/cap; sort; Offer cards; compare CTA. GET offers, owner only; no hidden ranking. Loading/empty/over-cap/terminal/partial/forbidden/stale/offline; desktop accessible table fallback; S008/S012/S014. |
| S011 (UI-11) Submit/edit Offer `/needs/:id/offers/new` | Need context/deadline; price/currency; proposal; delivery/availability; attachments; submit. Provider not owner; Need OPEN before deadline. Draft/validation/upload/saving/success/duplicate/deadline/conflict/offline; max720; S008/S012/S013. |
| S012 (UI-12) Offer detail `/offers/:id` | Status; Need context; permitted provider fields; price/proposal/delivery/files; message; owner decision actions when pending. GET Offer. Pending/accepted/rejected/withdrawn/terminal/denied/offline; destructive confirmation; S008/S010/S013/S017/S020. |
| S013 (UI-13) My Offers `/my/offers` | Status filters; Need/amount/state/date cards. GET my offers, self only. Loading/list/empty/zero/terminal/error/offline; preserve filter; S008/S011/S012. |
| S014 (UI-14) Compare confirm `/needs/:id/compare` | Need context; eligible count; four equal criteria; snapshot info; explicit selection above cap; advisory notice; start. Owner only. Ready/none/over-cap/quota/processing/conflict/offline; announce count; S010/S015/S016. |
| S015 (UI-15) Comparison `/comparisons/:id` | Version/state; AI advice notice; each offer score+coverage; criteria/evidence/missing/risk; requester next action. GET results, owner full/provider restricted. Queued/processing/completed/failed/partial/offline cache/denied; cards mobile, matrix desktop with text alternative; S012/S014/S016. |
| S016 (UI-16) History/export `/needs/:id/comparisons` | Version list newest first, time/count/rules; export controls for saved version. Role projection. Loading/empty/ready/processing/failed/expired/offline; export doesn't rerun AI; S008/S014/S015. |
| S017 (UI-17) Messages `/offers/:id/messages` | Offer context; chronological messages/time; multiline composer and send above keyboard. Participants only. Loading/empty/sending/sent/failed/rate-limit/offline draft/denied/session expired; announce politely; S012/S018/S021. |
| S018 (UI-18) Notifications `/notifications` | unread count; supported filters; date groups; type/title/summary/time/read. Recipient only; item marks read then reauthorizes deep link. Loading/empty/list/marking/error/offline/partial; read state not color-only; S004/S008/S010/S015/S019/S022. |
| S019 (UI-19) Boost/payment `/needs/:id/boost` | Need context; package/duration/price/currency; payment handoff; pending state. Owner only; server confirms payment. Loading/packages/checkout/pending/confirmed/failed/review/timeout/offline; no local success; S008/S009/S018. |
| S020 (UI-20) Rating `/needs/:id/rating` | completed relationship; labelled 1–5 radio; optional comment; submit. Completed participants only. Eligible/validation/submitting/submitted/already/not completed/denied/offline draft; verbal scale; S008/S012. |
| S021 (UI-21) Report/support `/support/report` | Reason; accessible related record reference; details/privacy note; submit/reference. Authenticated; POST report. Form/validation/submitting/submitted/rate limit/error/offline draft/denied; errors linked; S008/S012/S017/S018. |
| S022 (UI-22) Telegram status `/needs/:id/publications` | Need context; authorized destination rows/status/time; stop/remove action and already-posted limits. Owner only. queued/sending/posted/retry/uncertain/failed/skipped/removal-pending/removed/paused/offline/denied; mobile cards/desktop table; never claim unsupported removal; S006/S007/S008/S018. |

Overlays O01 accept Offer, O02 reject Offer, O03 cancel Need, O04 complete Need, O05 stop public distribution, O06 explicit over-cap selection. Each has labelled consequence, cancel, duplicate-submit prevention, focus trap/return. Esc/back closes before mutation; after mutation starts, state is reconciled.

## 7. የእርምጃ ኮንትራት

| Trigger | Preconditions | Behavior/result | Failure/recovery |
|---|---|---|---|
| Primary CTA/Enter | enabled, valid form, idempotency for mutation | disable duplicate, named loader, server response then route | 422 inline; 401 reauth without replay; 409 refresh/reconfirm; timeout reconcile first; preserve values. |
| Search/filter | current query/filter | cancel obsolete request, update count/list | timeout retains query and labels stale; zero result offers clear filters. |
| Publish Need | valid, auth, attachments ready, fresh unchecked→checked consent | create Need; publication state is separate | lookup by reference before resubmit; partial failure distinct. |
| Submit Offer | eligible provider; Need OPEN; before deadline | server saves PENDING | duplicate/deadline/conflict message, draft retained. |
| Accept/reject | owner, pending Offer | O01/O02 with consequences, submit once | cancel returns; conflict reloads; no false state. |
| Compare | owner, eligible set/quota/cap | show criteria then freeze snapshot | none→S010; failed AI retries same snapshot only. |
| Message send | participant, valid text | mark sending then authoritative sent | offline draft; sent/unsent/unknown distinct; reconcile before retry. |
| Payment | owner, active package | exact amount/currency then provider handoff | app return is not proof; pending/reconcile; mismatch review. |
| Stop public post | owner, publication exists | O05 describes scope/limits then server stop | per-destination response; no claim stopped/removed without evidence. |
| Back on dirty form | unsaved changes | save/discard/stay | draft retained if interrupted; no silent loss. |
| Dialog/menu | opened from clear trigger | focus containment; Esc/back if safe; restore focus | prevent unsafe dismissal during irreversible action. |
| OS permission | feature requires it | explain first; request minimum scope | denial keeps unrelated functions available. |

Keyboard: Tab/Shift+Tab visual order; Enter activates; Space toggles; arrows for radios/tabs/menu; Esc closes safe overlays; platform back shares same stack. No action without defined behavior.

## 8. Runtime states and failure recovery

| State | Meaning | Recovery |
|---|---|---|
| Initial / Loading / Skeleton | not requested/request active | preserve layout; no fake progress. |
| Empty | server list is truly empty | explain and offer next step. |
| Zero Result | active filters returned none | clear/tune filters; not “no data.” |
| Partial | only part returned | label missing part, retry that part. |
| Success/Warning | confirmed / proceed with known caveat | show source/status and consequence. |
| Validation Error | invalid field/business rule | field-linked fix; preserve input. |
| Error | failed operation | plain Amharic, request ID when available, retry/back/support. |
| Offline | no network | stale cache labelled; mutation stays draft. |
| Timeout | server outcome unknown | reconcile by idempotency/reference before retry. |
| Rate Limited | server asks to wait | server cooldown and draft preservation. |
| Stale | past freshness threshold | timestamp + refresh; don't present as current. |
| Unknown | no known value | never show as 0/false. |
| Conflicting | sources disagree | show source/time, don't silently choose. |
| Unauthorized/Forbidden | no session/no permission | reauth/recheck; no private data leak. |
| Read-only | view allowed, write not | explain record state and permitted route. |
| Archived/Deleted | terminal/unavailable | safe return; no edit. |
| Degraded/Maintenance | dependency limited | show affected capability; retain safe read-only content. |
| Permission Denied | OS/user withheld access | graceful fallback or settings path. |

HTTP mapping: 401 reauth; 403 safe denial; 404 safe unavailable; 409 refresh/reconfirm; 422 field errors; 429 wait per server; 5xx bounded retry. Upload errors per file. AI failure returns no fabricated score. Payment mismatch remains review-required. Telegram timeout is UNCERTAIN; reconcile before retry.

## 9. ሽግግር ካርታ

```text
S001 --[Sign in]→ S002 --[auth success]→ S003? --[profile ready]→ S004
S002 --[denied/expired]→ S002.ERROR --[retry]→ S002
S004 --[Need card]→ S008 --[provider offer]→ S011 --[saved]→ S012 → S017
S004 --[Create]→ S005 → S006 --[consent]→ S007 → S008 → S022
S006 --[Edit/stale]→ S005; S006 --[Cancel]→ S005
S009 → S008 → S010 → S014 → S015 → S012 (requester decision)
S014 --[no eligible offer]→ S010; S014 --[above cap]→ O06 → S014
S014 --[AI failure]→ same snapshot retry → S015
S015 --[History/export]→ S016 → saved version → S015
S018 --[authorized notification]→ appropriate S008/S012/S015/S019/S022
S008 --[Boost]→ S019 --[provider return]→ pending --[server confirms]→ S008
S008 --[complete]→ O04 --[confirm]→ S020; O04 --[cancel]→ S008
S022 --[stop]→ O05 --[confirm]→ paused/removal-pending; O05 --[cancel]→ S022
S021 --[submit]→ confirmation --[done]→ originating route
Protected route --[401]→ reauth → reauthorize original; never replay sensitive mutation
Dirty form --[back]→ save/discard/stay; preserve draft
```

## 10. Accessibility, localization, data trust, privacy

### 10.1 Accessibility (WCAG 2.2 AA target; proof required)
- Keyboard/focus order, visible 2dp focus, Escape/back, modal focus trap/return.
- TalkBack/VoiceOver names/roles/states; polite status announcements; no repeated announcements.
- Contrast 4.5:1 normal text, 3:1 large/essential graphics; color never sole signal.
- 200% text, 320dp reflow, 48×48 targets, no clipped actions or Amharic glyphs.
- Reduced motion, keyboard/safe area, associated labels/errors, table headers and chart text alternatives.

### 10.2 Amharic-first localization
`am` default, `en` included at launch. All UI strings localized (not inline). Amharic is LTR; mixed numeric/API fragments use directional isolation. Preserve route/draft on language switch. Dates use user timezone and locale; APIs retain UTC/offset timestamps. Money shows server currency/precision, initially ETB. Use locale plural rules. Amharic wrapping is tested, never truncate essential instruction.
Approved terms: Felagi=ፈላጊ; Need=ፍላጎት; Requester=ፈላጊው/የፍላጎቱ ባለቤት; Provider=አቅራቢ; Offer=አቅርቦት; Comparison=ንጽጽር; Boost=ማስታወቂያን ማጉላት; Profile=መገለጫ; Notifications=ማሳወቂያዎች; Retry=እንደገና መሞከር; Unknown=ያልታወቀ; Partial=ከፊል; Conflicting=የሚጋጭ.

### 10.3 Data/trust presentation
Every KPI identifies measure/unit/time/source. AI shows criteria/version/weights/evidence/coverage/missing facts; no auto-winner claim. Price and payment state remain separate. Telegram POSTED means accepted by Telegram, not viewed/read/reached. Tables switch to cards narrow; sort and row relationships are announced. No fake precision or invented imagery/badges.

### 10.4 Privacy/security UX
Public projection only contains approved public fields; excludes phone, private profile, private message, Offer/payment data. Preview exact outgoing content; consent unchecked. Stop halts eligible queued sends; removal reported only if evidenced; already-posted copies may remain. Sensitive actions (accept/reject/cancel/complete/payment/public post/stop) show consequence and require confirmation; session expiry requires reauth and never auto-replays. Errors exclude tokens/provider secrets/stack traces. Offline drafts need secure storage, expiry, and deletion evidence.

## 11. Performance/failure UX

| Event | UI behavior | Data safeguard |
|---|---|---|
| Slow first load | shape-matching skeleton | not interpreted as empty. |
| Offline | persistent notice + cache timestamp | mutation remains draft, not submitted. |
| API timeout | retry/reconcile, request reference | no blind duplicate. |
| Partial endpoint failure | identify failed section | never say all succeeded. |
| Upload failure | status/retry per file | successful files not resubmitted. |
| Background job | queued/processing state | no fake percent. |
| Session expiry | auth recovery | preserve draft; do not replay action. |
| Maintenance | say which actions unavailable | keep unaffected read-only data if safe. |

## 12. Developer traceability contract

`PRODUCT RULE → JOURNEY → SCREEN → COMPONENT → TOKEN → STATE → INTERACTION → PERMISSION → DATA/API → RESULT/ERROR → RECOVERY → TEST EVIDENCE`.

| Rule | Screens/journey | UI contract | Permission/API | Acceptance check |
|---|---|---|---|---|
| Requester decides; AI cannot accept | J06, S012/S014/S015, O01/O02 | advisory note, decision confirmation | owner-only accept/reject | no AI accept action; provider can't decide. |
| Immutable comparison snapshot | S014–S016 | version, stale disclosure, saved results | comparison snapshot API | later Offer edit does not change old view. |
| Equal criteria/event | S014/S015/S018 | identical criteria and version | role-specific results/notifications | same four criteria; provider sees allowed own data. |
| Authorized Telegram broadcast/stop | J03/J11; S005–S007/S022/O05 | exact preview, unchecked consent, status | destination allowlist/public projection/stop | private field absent; uncertain not blindly retried. |
| Payment verifies boost | J09/S019 | pending vs confirmed clearly distinct | signed callback/reconciliation | app return alone cannot activate. |
| Offline draft != submitted | S003/S005/S011/S017/S021 | offline + draft badge | local draft only before server ack | no success state offline. |
| Authorization fresh | deep links | safe denied state/cache clear | Laravel checks each action | revoke permission mid-session; no private details. |

## 13. Superseding evidence-based acceptance

The original self-audit overclaimed MET. It is preserved in the original input ZIP and prior independent audit. The authoritative current statuses are in `../Audit/Final_Gap_Audit.md` and `../Audit/Final_Acceptance_Report.md`. Document presence does not prove executable conformance. The final master specification and machine registries listed below reconcile this retained product narrative.

## 14. የመቀበያ ሕግ

- Product baseline and FGM-DS-1.0 remain unchanged; this spec fills implementation detail.
- A visual or business change needs an ID, reason, affected screen/component/token/state, permission/API impact, accessibility and regression test.
- **No screen without purpose. No component without applicable states. No action without behavior. No data without semantics. No error without recovery. No layout without responsive rules. No interaction without accessibility. No sensitive action without security rules. No claim without evidence. No unresolved design ambiguity hidden in implementation.**
- **NO EXTERNAL DESIGN TOOL REQUIRED. NO DESIGN DECISION LEFT TO GUESSWORK.**

## 15. Remediation revision 1.1 authority

`Final_Master_Product_Design_Specification.md` and the canonical registries resolve IDs, states and layout. All S001–S022 IDs and established capabilities are retained. S003 supports `/profile` and `/profile/setup`; S005 supports new and edit modes; S011 supports create and edit modes. Canonical machine routes include every supported path. The route registry wins over descriptive shorthand in this narrative. Admin A001–A022 is included under the same product/security authority. See each final matrix for exact acceptance conditions.

Create Need is an in-flow full-width prominent button immediately after Browse search/filter controls on compact/mobile; at ≥600dp it sits right-aligned in the content header. It is never a floating button. At ≥1600dp, use centered max-1280dp content with no additional context pane. English is required launch scope alongside default Amharic. Tablet uses a rail from 600dp; desktop uses a labelled sidebar from 1200dp. Sticky primary actions cannot obscure content; each layout reserves their height and safe area.
