# Final Screen Transition Map

Navigation edges below are candidates gated by current role/state. Form success requires server acknowledgement in production. Preview uses explicit sample transitions only.

| Origin | Destinations | Gate / back behavior |
|---|---|---|
| S001 | S002 | public; restore origin/filter/scroll; dirty forms O11 |
| S002 | S003 | public; restore origin/filter/scroll; dirty forms O11 |
| S003 | S004 | self; restore origin/filter/scroll; dirty forms O11 |
| S004 | S005, S008, S009, S013, S018 | public; restore origin/filter/scroll; dirty forms O11 |
| S005 | S006 | requester; restore origin/filter/scroll; dirty forms O11 |
| S006 | S005, S007 | requester; restore origin/filter/scroll; dirty forms O11 |
| S007 | S008, S022 | requester; restore origin/filter/scroll; dirty forms O11 |
| S008 | S010, S011, S005, S014, S016, S019, S022, S020, S021 | public-or-owner; restore origin/filter/scroll; dirty forms O11 |
| S009 | S005, S008 | self; restore origin/filter/scroll; dirty forms O11 |
| S010 | S012, S014 | requester; restore origin/filter/scroll; dirty forms O11 |
| S011 | S012, S013 | provider; restore origin/filter/scroll; dirty forms O11 |
| S012 | S017, S020, S021 | participant; restore origin/filter/scroll; dirty forms O11 |
| S013 | S012 | self; restore origin/filter/scroll; dirty forms O11 |
| S014 | S015, S016 | requester; restore origin/filter/scroll; dirty forms O11 |
| S015 | S012, S016 | participant; restore origin/filter/scroll; dirty forms O11 |
| S016 | S015 | participant; restore origin/filter/scroll; dirty forms O11 |
| S017 | S012, S021 | participant; restore origin/filter/scroll; dirty forms O11 |
| S018 | S008, S012, S015, S019, S022 | self; restore origin/filter/scroll; dirty forms O11 |
| S019 | S008 | requester; restore origin/filter/scroll; dirty forms O11 |
| S020 | S008 | completed-participant; restore origin/filter/scroll; dirty forms O11 |
| S021 | S004 | authenticated; restore origin/filter/scroll; dirty forms O11 |
| S022 | S008 | requester; restore origin/filter/scroll; dirty forms O11 |
| A001 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A002 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A003 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A004 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A005 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A006 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A007 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A008 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A009 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A010 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A011 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A012 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A013 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A014 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A015 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A016 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A017 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |
| A018 | A001, A016, A017 | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause; restore origin/filter/scroll; dirty forms O11 |

## Mutation and overlay transitions

| Origin | Overlay | Success | Failure |
|---|---|---|---|
| S012 | O01 | IN_PROGRESS Need and ACCEPTED Offer; other pending Offers rejected | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| S012 | O02 | REJECTED Offer | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| S008 | O03 | CANCELLED Need | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| S008 | O04 | COMPLETED Need; rating eligible | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| S022 | O05 | Queued sends stopped; removal queued; no guaranteed deletion | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| S014 | O06 | Immutable snapshot, included IDs and excluded count | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| S012 | O07 | WITHDRAWN | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| S019 | O08 | PENDING payment and checkout instruction | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| A017 | O09 | Published new immutable version and audit ID | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| A017 | O10 | New version referencing prior value | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |
| S005 | O11 | Encrypted production draft; session-memory preview | 401 reauth without replay; 409 refresh/reconfirm; 422 field errors; timeout reconcile by idempotency key |

S005 → S006 is local validation only. S006 confirmation dispatches create/update exactly once; only acknowledgement enters S007 for creation or S008 for edit. S007 has an allocated Need ID. Back from S006 retains draft but clears consent after material edits. Payment provider return remains S019 pending. Admin publish transitions to server-confirmed published, then health verification; failure/unknown is not publish success.


## Added transitions
S011 valid draft → authoritative policy → free: S012 / paid: S023 pending → server verification → submitted S012; interrupted → S023 resume; ineligible → S023 refund pending→S021 case. Back retains draft.
A001→A003 incident→A018 diagnostics→approved action→verification→A016 audit. A004/A020/A017 edit→draft→validate→impact→publish→applying→applied→verify→history. Any edit resets validation; stale version returns to diff. Restore creates new draft. A019 Safe Mode and A021 maintenance use the same lifecycle with critical/high guards.


## Comparison transitions1.4
S014 ambiguous interpretation→confirm or S005 edit; no eligible→safe return; start→S015 processing→completed or failed. Failed retry pins same snapshot. Completed→S012 review or S017 message; provider→own S015 projection. S018 and Telegram links resolve same comparison/version after authentication. S016→old read-only S015 or new S014. Back restores origin/filter/selection/scroll; no mutation replay.


## Integrated 1.4 contract
J-ADS: A020 → A023 sponsor → creative → destination → placement → schedule → targeting/frequency → preview → publish → applied → requires-evidence/verified probe; pause/rollback returns audited new version. Browser Back on dirty wizard uses Save/Discard/Stay.
