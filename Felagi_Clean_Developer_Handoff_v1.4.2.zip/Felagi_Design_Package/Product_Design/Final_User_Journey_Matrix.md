# Final User-Journey Matrix

| Journey | Happy path | Cancel/failure/retry/resume |
|---|---|---|
| J01 Sign in | S001→S002→Telegram→S003 if needed→S004 | denial/expiry retry; interruption restores auth context only. |
| J02 Discover | S004 search/filter→S008 | zero results offer clearing filters; stale data labelled; timeout retains query. |
| J03 Post Need | S004→S005→files→S006→consent→S007 | stale preview→S005; offline draft; Need success and Telegram status separate. |
| J04 Submit Offer | S008→S011→S012/S013 | duplicate/deadline/conflict retains draft; server status required. |
| J05 Decide Offer | S009/S010→S012→O01/O02 | cancel returns; conflict refresh/reconfirm; owner alone decides. |
| J06 Compare | S010→S014→snapshot→S015→requester decision | none→S010; over cap→O06; AI failure retries same snapshot, never fabricates score. |
| J07 Message | S012→S017→send | offline draft; sent/unsent/unknown distinguished; reconcile before retry. |
| J08 Notification | S018→read→authorized target | read failure rollback; invalid target safe route. |
| J09 Boost | S008→S019→provider→pending→verified | app return not proof; timeout pending/reconcile; mismatch review. |
| J10 Rate | completed→S020→submit | duplicate says already rated; offline draft only. |
| J11 Telegram | S005→S006→S007→S022 | stop→O05; posted copy may remain; uncertain reconciled first. |
| J12 Report | source→S021→reference | offline draft; rate limit shows wait; error retains fields. |
| J13 Session expiry | protected route→reauth→original route | reauthorize; no automatic destructive/payment replay. |


| J14 Admin settings | A017 draft → validate → impact → O09 → publish → health; O10 rollback | 409 shows current vs draft; reauth never replays; publish is server/audit confirmed. |
| J15 Admin incident | A001 → affected A002/A007/A012 → scoped review → A018 | uncertain sends/payment mismatch require evidence; unaffected reads remain; never direct status setter. |
| J16 Admin evidence | A003/A011/A013/A014/A015/A016 | failed check is UNKNOWN; show timestamp; no automatic destructive recovery. |


## Added governed journeys
| Journey | Screens | Preconditions | Completion proof | Recovery |
|---|---|---|---|---|
| J-UNLOCK | S011→S023→S012 | Provider, open Need, saved valid draft | Server Offer ID | Same submission receipt, no recharge |
| J-ADMIN-CHANGE | A001→area→A016 | Scoped control permission | Verified version evidence | A018 or new rollback version |
| J-ADMIN-RECOVERY | A003→A018→A016 | Measured incident + approved action | Probe evidence | Requires verification if absent |
| J-ADMIN-RESTORE | A017 history→draft→verify | Current-version diff | New immutable version | Old history never edited |


## J-AI-REPORT / J-AI-OWN-RESULT
Requester S008→S014 requirements/eligibility→immutable comparison→S015 complete professional report→S012 review/choose→existing acceptance. Provider S018 or authorized Telegram link→authenticated S015 own feedback only. Requester S016→stored version/export; Compare Again creates new version. Delivery failure preserves report and retries channel. New evidence creates new version.


## Integrated 1.4 contract
J-ADS: Main Admin manages a contextual campaign through A020/A023, views A016 audit, uses A018 recovery. Normal: validated campaign published and verified before delivery. Failure: invalid creative/destination/permission/cap retains draft and serves no ad. User discovery stays S004→S008→S011 independently of ad service.
