# Final Information Architecture

**Revision:** FGM-PDS-1.3 / package 1.4.1. **Baseline lock:** Felagi demand-first marketplace; Amharic first with English launch support; product-owner supplied official logo master (canonical source included); navy/orange foundation; requester decision authority. DFM-FDS-1.4 business/security rules remain authoritative, with the explicit presentation integration decisions below. Design completeness is separate from production acceptance.

## Mobile
Public entry: Welcome → Telegram sign-in. Authenticated self: Profile, My Needs, My Offers, Notifications. Public discovery: Browse → Need detail. Requester management branches from an owned Need into edit, offers, compare, history/export, boost, publication and completion. Provider management branches from its own Offer into edit, withdrawal and messages. Rating requires a completed awarded relationship. Reports preserve their originating resource. No privileged control appears in ordinary mobile navigation.

## Admin
A distinct `/admin/*` workspace has 18 labelled destinations, never appended to the five mobile tabs. It uses browser session + CSRF and explicit role/permission checks. Main Admin, Admin and Moderator do not impersonate requesters/providers. Admin search is filtered before counts are returned. On mobile the Admin navigation becomes an in-flow list; the labelled screen selector also offers direct access. Read-only evidence is distinct from a mutable setting.

## Ownership and disclosure
Need owns Offers/comparison/publication/boost links; Offer owns participant messages; comparison owns immutable export; account owns self profile/notifications. Admin owns guarded settings and operational recovery, not business decisions. Fields must be redacted server-side. Missing records and denied private resources use the same safe unavailable presentation.


## Locked operational IA

- A001 Dashboard — /admin/dashboard
- A002 Telegram Distribution — /admin/telegram
- A003 Health — /admin/health
- A004 Features — /admin/features
- A005 Marketplace — /admin/marketplace
- A006 AI — /admin/ai
- A007 Payments — /admin/payments
- A008 Users — /admin/users
- A009 Content — /admin/content
- A010 Notifications — /admin/notifications
- A011 Files — /admin/files
- A012 Jobs — /admin/jobs
- A013 Backups — /admin/backups
- A014 Integrity — /admin/integrity
- A015 Security — /admin/security
- A016 Audit — /admin/audit
- A017 Settings — /admin/settings
- A018 Recovery — /admin/recovery
- A019 Safe Mode — /admin/safe-mode
- A020 Monetization — /admin/monetization
- A021 Maintenance — /admin/maintenance
- A022 Reports — /admin/reports

S023 belongs to provider submission, not a sixth navigation tab. Main Admin appears as a separate authorized product projection.


## Integrated 1.4 contract
Monetization A020 → Sponsored Ads A023. Discovery remains S004 (browse/search modes), detail S008. There is no separate Home screen, ad marketplace or advertiser portal.
