# Felagi — Final Master Product Design Specification

**Revision:** FGM-PDS-1.3 / package 1.4.1. **Baseline lock:** Felagi demand-first marketplace; Amharic first with English launch support; product-owner supplied official logo master (canonical source included); navy/orange foundation; requester decision authority. DFM-FDS-1.4 business/security rules remain authoritative, with the explicit presentation integration decisions below. Design completeness is separate from production acceptance.

## Product and scope
A person publishes a Need; other active users offer solutions; the requester may compare immutable snapshots using the four equally weighted DFM criteria and makes the final decision. Messaging belongs to Offer participants. Payment verifies Need visibility or fixed Offer submission access, never purchase of a winning score. Authorized Telegram distribution uses only the public projection; POSTED does not prove human viewing.

This package specifies 23 user screens, 23 Admin screens and 11 named interaction overlays (the original O01–O06 retained; O07–O11 complete existing withdraw/payment/settings/dirty-form interactions). It does not add onboarding or phone OTP, merge requester/provider projections, or invent automatic acceptance. The complete retained PDS narrative is `FGM-PDS-1.0.md`, amended for audited issues. This master and canonical registries resolve its shorthand.

## Authority and source ownership
1. `System_Specification/DFM-FDS-1.4.md`: business invariants, permissions, API and evidence truth.
2. `System_Specification/Design_Integration_Contract.md`: concrete presentation/backend handoff additions; no weakening of DFM invariants.
3. This master plus the named final design matrices: complete interface contracts.
4. `Design_Data/screen-manifest.json`: sole screen IDs, paths, aliases, roles, fields, layouts, business states and applicable runtime conditions.
5. `Design_System/tokens/token_registry.json`: sole token authority. Complete generated resolved mapping, CSS and Dart registry derive from it.
6. `Localization/app_am.arb` and `app_en.arb`: complete owned static keyspace for delivered preview and starter; dynamic records remain server data.

Generated copies are not alternative authorities. `Tools/generate_runtime.py` reproduces token mapping, preview data and Flutter registry/locales. `Tools/verify_package.py` fails when generated values, routes, states, labels or references drift. Prior audit records in `Audit/Prior_*` are historical evidence, not active implementation instructions.

## Decisions now fixed
- S006 new flow: `/needs/new/public-preview`, transient local draft. Existing-record edits may use `/needs/:id/public-preview`. No server Need ID is assumed before creation. Server validates the same allowlisted projection during create/update; final public link is clearly marked as inserted after ID allocation. An unreviewed material field or destination-policy change invalidates consent.
- S003 `/profile` is the canonical tab; `/profile/setup` is first-login mode. Both use the same self-only component and validation. S005 and S011 have explicit edit aliases.
- Five mobile navigation destinations remain; Create Need is separate and in flow after filters below 600dp, header-right at ≥600dp. No floating action. At ≥1600dp center 1280dp content; no optional context pane.
- Tablet/laptop rail begins at 600dp, full labelled sidebar at 1200dp. Forms max720dp, reading max760dp. See responsive matrix for every screen.
- English is launch-required. Every static visible string in the new preview comes from ARB, including Admin, errors and state descriptions. Document/record identifiers, currency codes and fixture numerals are data, not translatable copy.
- PAUSED describes destination/scheduling policy, not a new `telegram_publications.state`. RETRY is a publication state. UI composes these sources; no backend enum is silently expanded.
- Runtime condition and business/view state are separate dimensions. Loading/unknown/partial never imply empty or success.

## Deliverables and use order
Read this master → Information Architecture → Navigation/Route Map → Complete Screen Inventory and Screen-by-Screen Specifications → Journey/Transition/Interaction matrices → Design System/Component/Pattern/State libraries → Responsive/Accessibility/Localization/Runtime/Error matrices → Admin Control Center → Developer Handoff → Gap Audit and Acceptance Report.

Open `UI_Handoff/ui-preview/index.html` directly, or serve the package locally. The preview is a functional design fixture: native inputs, validation, navigation, state selection, confirmation and role-dependent affordances. It does not call live APIs or claim server outcomes. All 46 screens are selectable; no screen must be inferred from an unrelated mobile mockup. `Design_System/preview/component_catalog.html` uses the same generated tokens.

## Complete design versus complete application
This is a corrected design package with a starter implementation, not a production backend or a complete Flutter application. The starter implements documented shared components, theme, complete registry access and a runnable inspection example. Product screens are implemented from these contracts by application developers. No included code sample overrides the specification. Device glyphs, compiled Flutter behavior, authenticated APIs and live provider outcomes require separate recorded evidence.


## Locked product control model — revision 1.3
Felagi is a Need-First Marketplace: **Post Need → Receive Offers → Compare Fairly → Choose → Complete → Review**.
“Tell Felagi what you need → receive competing offers → compare with evidence → choose for yourself.” AI remains advisory; requester decides. Revenue never buys ranking or acceptance. No percentage commission.

Requester, Provider and Main Admin are product projections. Main Admin controls authorized policy through governed application controls; it has no unrestricted database/source editor. Ordinary administration requires no SQL, terminal, raw JSON, environment editing or deployment-file editing. Simple mode is default; Advanced exposes typed integration controls only.

Canonical loop: See → Understand → Search/choose intent → Change → Save draft → Validate → Simulate impact → Preview → Confirm/approve → Publish → Apply → Verify → Monitor → Rollback/recover → Audit. Draft ≠ Published ≠ Applied ≠ Verified.

### Canonical responsibility ownership
| Responsibility | Sole owner | Consumers |
|---|---|---|
| Business behavior / product identity | This master; Monetization and Payment Specification owns its payment subsection | DFM, screens, tests |
| Payment truth and fee recovery | System_Specification/Monetization_Payment_Specification.md | API, Admin, mobile, preview |
| Authorized control schema/defaults | Design_Data/control-registry.json | Admin, backend adapter, tests |
| Admin interaction/governance | Admin/Final_Admin_Control_Center_Design.md | screen contracts, patterns |
| Authorization | System_Specification/Admin_Authorization_Contract.md plus retained DFM security invariants | UI/server |
| Screens, routes, state bindings | Design_Data/screen-manifest.json | generated route/API/Admin indexes, preview, Flutter |
| Visual tokens | Design_System/tokens/token_registry.json | generated CSS/Dart/docs |
| Copy | Localization/app_am.arb and app_en.arb | generated runtime assets; glossary constrains concepts |

These locked user changes supersede the retained DFM statement that Offer submission is always free. Other DFM business/security rules remain. Existing source narratives are retained for detail, with registry bindings taking precedence over historical shorthand.

**FELAGI MAIN ADMIN CONTROL ARCHITECTURE — LOCKED FOUNDATION**

The Main Admin Control Center is a core Felagi product foundation, not a secondary developer utility. It provides a governed no-code operational layer through which an authorized non-technical owner can safely control ordinary product configuration, monetization, feature availability, content, maintenance, health, recovery and operational policy. Its simple user experience must never bypass backend authorization, dependency validation, payment verification, security, audit, versioning, recovery or runtime verification. Future refinements may extend and harden this foundation but must not replace, weaken or silently bypass it without explicit product approval.


## Core product intelligence — locked1.4
Felagi is a demand-first marketplace where a requester posts a Need, eligible providers submit competing Offers, and Felagi AI evaluates those Offers against the requester’s stated Need requirements using the same versioned criteria and evidence rules. Felagi produces a professional documented comparison for the requester and privacy-safe role-appropriate feedback for participating providers, with synchronized comparison-result notification through Felagi and authorized Telegram channels. The requester remains the final decision-maker.

One snapshot → same evaluation rules → one version → requester full result/provider own feedback → same comparison-ready event → in-app and authorized Telegram delivery → human decision. Equal event does not mean identical private content or identical transport arrival time. This capability is evidence-grounded, versioned, explainable, consistent, privacy-safe and auditable; it is not merely ranking.

Canonical AI rules are owned by System_Specification/AI_Evaluation_Contract.md; machine criteria by Design_Data/criteria-registry.json; projection/event schema by Design_Data/comparison-contract.json. S014/S015/S016 are reused; no parallel result store or duplicate screen is introduced. UX quality is governed by the existing interaction, pattern, responsive and accessibility owners, with the screen-quality registry providing their testable bindings.

**FELAGI AI OFFER EVALUATION & EQUAL RESULT DELIVERY — LOCKED CORE CAPABILITY**

A requester posts a Need and eligible providers submit competing Offers. When the requester triggers AI Compare, Felagi freezes one versioned Need/Offer comparison snapshot and evaluates every included Offer under the same canonical criteria, weighting, evidence, prompt/model and scoring contract. Each Offer receives an evidence-grounded 1–10 evaluation with requirement match, criterion-level reasoning, strengths, weaknesses, missing/unknown information, risks and evidence coverage. The requester receives the complete authorized professional comparison, while participating providers receive privacy-safe feedback about their own result through Felagi and authorized Telegram delivery from the same canonical comparison-completion event. Historical comparison versions are immutable. AI advises; the requester alone makes the final choice.


## Locked advertising integration 1.4
Canonical revenue: Need Boosting; Offer Submission Unlock; Sponsored Advertising. No percentage commission. Sponsored placement is labelled, default OFF, separately governed and excluded from organic ranking and AI scoring. Domain owner: `System_Specification/Sponsored_Advertising_Contract.md`; only S004/S008 registered slots, A023 under A020 Monetization. The full package has46 screens:23 user and23 Admin,55 governed controls. UX quality remains clarity + speed + continuity + trust + comfort + subtle delight; no new ornamental effects are required. All historical product/audit findings remain preserved.
