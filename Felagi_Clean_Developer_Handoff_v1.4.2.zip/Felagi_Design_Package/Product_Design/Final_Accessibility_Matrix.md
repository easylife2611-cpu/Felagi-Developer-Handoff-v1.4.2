# Final Accessibility Matrix

Target: applicable WCAG 2.2 AA outcomes plus native TalkBack/VoiceOver. Specification closure is not a conformance certificate. Owner: frontend/accessibility QA; production signoff requires execution evidence.

| Area / screens | Required implementation | Acceptance procedure | Evidence status |
|---|---|---|---|
| All text / themes | Measured semantic pairs;4.5 normal,3 large; no essential text on decorative border colors | Compute pairs, then inspect rendered overlays, alpha and font size | Token evidence attached; render external |
| All controls | Essential boundary3:1 where needed;48×48 minimum practical target; no focus clipped | Keyboard Tab/Shift+Tab, magnified view, touch target inspection | Static design/code specified; device external |
| Keyboard | Native button/link/input; logical order; Enter/Space native; no keyboard trap outside modal | Complete J01–J16 without pointer | External |
| Dialogs O01–O11/Admin | Accessible name/description, safe Cancel initial, modal focus trap, Esc safe close, return focus | Open from each trigger, cycle focus, cancel, confirm timeout | Native HTML dialog implemented; runtime external |
| Forms S003/S005/S011/S017/S020/S021/Admin | Visible label, helper+error association, error summary, retained values, required state | Submit empty/invalid/long text; inspect announcement and first invalid focus | Code/static specified; AT external |
| Navigation/deep links | Current location announced; heading receives focus; skip link; no disabled-only explanation | Traverse five mobile tabs and23 Admin sections | Static paths checked; runtime external |
| Status/async | Polite one-time announcements; alert only actionable validation/error; no loading-as-empty | Throttle, offline, timeout, partial, repeated polling | External |
| Tables/comparison | Caption, th scope, named values, card alternative, unknown distinct from0 | Screen reader rows/headers; narrow cards; provider redaction | Static structure checked; AT external |
| Language | Root changes with locale; no untranslated chrome; user mixed-language content lang/dir auto or bdi | Amharic and English with mixed numerals/URLs; glyph shaping | ARB parity checked; native linguistic/device review external |
| Text/reflow | 200% scaling;320px viewport; no essential clipped labels or fixed-height text | Both platforms, browser zoom400%, long copy | Specs/code fixed; rendering external |
| Motion | Reduced-motion removes nonessential transitions/skeleton shimmer; no flashing | OS setting and media query | Code present; device external |
| Contrast-independent meaning | Text+icon+tone; score caveats/evidence readable | Grayscale/high contrast inspect status and selection | Static specified; device external |
| Images/icons | Meaningful alt/name; decorative hidden; logo spoken once | Disable images, AT navigation | Static checked; AT external |
| Errors/privacy | Safe request reference; no secret/trace in error; 403/404 don't leak record | Permission revoke and unauthorized deep link | Requires live backend |

Accessibility defects found at implementation acceptance reopen the relevant component/screen gate. Do not mark a screen PASS merely because its semantic requirements exist in this table.


## Added payment/Admin acceptance
| Surface | Required behavior | Evidence |
|---|---|---|
| S023 | Amount and fixed-fee purpose before Pay; pending status polite live region; draft return; no client-success announcement | Browser/AT pending |
| Admin settings | Label+description+unit+error; read-only current value distinct from proposal; UNKNOWN text | Source implemented; browser/AT pending |
| Impact/history | Before/after semantic structure; focus heading; no color-only diff | Browser/AT pending |
| Confirmation | Cancel initial focus, trap, Escape, restore trigger; risk-specific reason/auth controls | Native dialog source; device pending |
| Health/recovery | Status icon hidden if redundant; text, timestamp and measured impact; accessible evidence links | Browser/AT pending |
| All46 screens | Amharic stress fixture,200% text, keyboard, reduced motion, light/dark contrast | Numeric contrast separate from rendered evidence |


## Comparison accessibility1.4
Read order: Offer → total → evidence coverage → requirement match → criterion → evidence → unknown → risk. Visible textual states supplement tone. Native details/summary must be keyboard operable and announce expanded state. Matrix has caption and row/column headers plus equivalent card/text view. Do not duplicate both representations in accessibility tree at the same viewport. Sticky CTA cannot cover focus/zoom content; reduced motion preserves controls. Under-three-second location/state/next-action comprehension requires user testing, not a static PASS.


## Per-screen acceptance bindings1.4
### S001
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S001; execution status REQUIRES_EVIDENCE.

### S002
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S002; execution status REQUIRES_EVIDENCE.

### S003
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S003; execution status REQUIRES_EVIDENCE.

### S004
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: AD_BROWSE_INLINE_01, AD_SEARCH_RESULTS_INLINE_01. Test SCREEN-S004; execution status REQUIRES_EVIDENCE.

### S005
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S005; execution status REQUIRES_EVIDENCE.

### S006
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S006; execution status REQUIRES_EVIDENCE.

### S007
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S007; execution status REQUIRES_EVIDENCE.

### S008
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: AD_NEED_DETAIL_BOTTOM_01. Test SCREEN-S008; execution status REQUIRES_EVIDENCE.

### S009
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S009; execution status REQUIRES_EVIDENCE.

### S010
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S010; execution status REQUIRES_EVIDENCE.

### S011
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S011; execution status REQUIRES_EVIDENCE.

### S012
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S012; execution status REQUIRES_EVIDENCE.

### S013
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S013; execution status REQUIRES_EVIDENCE.

### S014
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S014; execution status REQUIRES_EVIDENCE.

### S015
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S015; execution status REQUIRES_EVIDENCE.

### S016
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S016; execution status REQUIRES_EVIDENCE.

### S017
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S017; execution status REQUIRES_EVIDENCE.

### S018
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S018; execution status REQUIRES_EVIDENCE.

### S019
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S019; execution status REQUIRES_EVIDENCE.

### S020
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S020; execution status REQUIRES_EVIDENCE.

### S021
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S021; execution status REQUIRES_EVIDENCE.

### S022
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S022; execution status REQUIRES_EVIDENCE.

### S023
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-S023; execution status REQUIRES_EVIDENCE.

### A001
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A001; execution status REQUIRES_EVIDENCE.

### A002
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A002; execution status REQUIRES_EVIDENCE.

### A003
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A003; execution status REQUIRES_EVIDENCE.

### A004
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A004; execution status REQUIRES_EVIDENCE.

### A005
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A005; execution status REQUIRES_EVIDENCE.

### A006
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A006; execution status REQUIRES_EVIDENCE.

### A007
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A007; execution status REQUIRES_EVIDENCE.

### A008
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A008; execution status REQUIRES_EVIDENCE.

### A009
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A009; execution status REQUIRES_EVIDENCE.

### A010
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A010; execution status REQUIRES_EVIDENCE.

### A011
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A011; execution status REQUIRES_EVIDENCE.

### A012
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A012; execution status REQUIRES_EVIDENCE.

### A013
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A013; execution status REQUIRES_EVIDENCE.

### A014
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A014; execution status REQUIRES_EVIDENCE.

### A015
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A015; execution status REQUIRES_EVIDENCE.

### A016
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A016; execution status REQUIRES_EVIDENCE.

### A017
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A017; execution status REQUIRES_EVIDENCE.

### A018
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A018; execution status REQUIRES_EVIDENCE.

### A019
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A019; execution status REQUIRES_EVIDENCE.

### A020
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A020; execution status REQUIRES_EVIDENCE.

### A021
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A021; execution status REQUIRES_EVIDENCE.

### A022
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A022; execution status REQUIRES_EVIDENCE.

### A023
Native heading/landmarks, labelled controls, one task-primary action per mode,48dp minimum/56dp prominent, visible focus, field error+summary, non-color state text, polite status updates, no automatic focus theft. Modal safe Cancel first, trap/restore focus; route change focuses heading then restores context. Screen reader announces unknown/stale/advisory truth, not speculative success. Both themes, am/en, keyboard, TalkBack/VoiceOver,200% text and reduced motion require recorded evidence. Placement: NO_ADS. Test SCREEN-A023; execution status REQUIRES_EVIDENCE.
