# Final Runtime-State Matrix

Two dimensions: screen business/view state + runtime condition. Both are canonical in `Design_Data/screen-manifest.json`. A business label does not authorize a mutation. Source-of-truth is server; local drafts/view state are explicitly marked. Every state has locale label/description and preview selection; irrelevant runtime options are omitted per screen.

| State | Label key | Description key | Blocks mutation | Recovery |
|---|---|---|---|---|
| accepted | `stateAccepted` | `noFakeSuccess` | False | refresh-or-safe-return |
| acknowledgement-required | `stateAcknowledgementRequired` | `noFakeSuccess` | False | refresh-or-safe-return |
| already-rated | `stateAlreadyRated` | `noFakeSuccess` | True | refresh-or-safe-return |
| checkout | `stateCheckout` | `noFakeSuccess` | False | refresh-or-safe-return |
| completed | `stateCompleted` | `noFakeSuccess` | False | refresh-or-safe-return |
| completed-owner | `stateCompletedOwner` | `noFakeSuccess` | False | refresh-or-safe-return |
| completed-provider-own | `stateCompletedProviderOwn` | `noFakeSuccess` | False | refresh-or-safe-return |
| confirmation | `stateConfirmation` | `noFakeSuccess` | False | refresh-or-safe-return |
| confirmed | `stateConfirmed` | `noFakeSuccess` | False | refresh-or-safe-return |
| confirmed-active | `stateConfirmedActive` | `noFakeSuccess` | False | refresh-or-safe-return |
| conflict | `stateConflict` | `freshnessHelp` | True | edit-and-revalidate |
| conflicting | `stateConflicting` | `freshnessHelp` | False | refresh-or-safe-return |
| content | `stateContent` | `noFakeSuccess` | False | refresh-or-safe-return |
| deadline-passed | `stateDeadlinePassed` | `validationHelp` | True | refresh-or-safe-return |
| default | `stateDefault` | `noFakeSuccess` | False | refresh-or-safe-return |
| degraded | `stateDegraded` | `noFakeSuccess` | False | refresh-or-safe-return |
| denied | `stateDenied` | `permissionHelp` | True | reauthorize |
| detail | `stateDetail` | `noFakeSuccess` | False | refresh-or-safe-return |
| disabled | `stateDisabled` | `noFakeSuccess` | True | refresh-or-safe-return |
| draft | `stateDraft` | `noFakeSuccess` | False | refresh-or-safe-return |
| duplicate | `stateDuplicate` | `validationHelp` | True | refresh-or-safe-return |
| eligible | `stateEligible` | `noFakeSuccess` | False | refresh-or-safe-return |
| empty | `stateEmpty` | `emptyHelp` | False | refresh-or-safe-return |
| empty-offers | `stateEmptyOffers` | `emptyHelp` | False | refresh-or-safe-return |
| error | `stateError` | `validationHelp` | False | refresh-or-safe-return |
| expired | `stateExpired` | `noFakeSuccess` | False | refresh-or-safe-return |
| export-failed | `stateExportFailed` | `noFakeSuccess` | False | refresh-or-safe-return |
| export-processing | `stateExportProcessing` | `noFakeSuccess` | False | refresh-or-safe-return |
| export-ready | `stateExportReady` | `noFakeSuccess` | False | refresh-or-safe-return |
| failed | `stateFailed` | `validationHelp` | False | refresh-or-safe-return |
| failed-retry | `stateFailedRetry` | `noFakeSuccess` | False | refresh-or-safe-return |
| form | `stateForm` | `noFakeSuccess` | False | refresh-or-safe-return |
| impact-preview | `stateImpactPreview` | `noFakeSuccess` | False | refresh-or-safe-return |
| list | `stateList` | `noFakeSuccess` | False | refresh-or-safe-return |
| loading | `stateLoading` | `noFakeSuccess` | True | refresh-or-safe-return |
| maintenance | `stateMaintenance` | `noFakeSuccess` | True | refresh-or-safe-return |
| marking-read | `stateMarkingRead` | `noFakeSuccess` | False | refresh-or-safe-return |
| no-eligible-offers | `stateNoEligibleOffers` | `emptyHelp` | True | refresh-or-safe-return |
| not-completed | `stateNotCompleted` | `noFakeSuccess` | True | refresh-or-safe-return |
| offline | `stateOffline` | `offlineHelp` | True | refresh-or-safe-return |
| offline-cached | `stateOfflineCached` | `offlineHelp` | False | refresh-or-safe-return |
| offline-draft | `stateOfflineDraft` | `offlineHelp` | False | refresh-or-safe-return |
| over-cap | `stateOverCap` | `noFakeSuccess` | False | refresh-or-safe-return |
| over-cap-selection | `stateOverCapSelection` | `noFakeSuccess` | False | refresh-or-safe-return |
| overview | `stateOverview` | `noFakeSuccess` | False | refresh-or-safe-return |
| owner | `stateOwner` | `noFakeSuccess` | False | refresh-or-safe-return |
| packages | `statePackages` | `noFakeSuccess` | False | refresh-or-safe-return |
| partial | `statePartial` | `freshnessHelp` | False | refresh-or-safe-return |
| partial-failure | `statePartialFailure` | `noFakeSuccess` | False | refresh-or-safe-return |
| paused | `statePaused` | `noFakeSuccess` | False | refresh-or-safe-return |
| pending | `statePending` | `noFakeSuccess` | False | refresh-or-safe-return |
| posted | `statePosted` | `noFakeSuccess` | False | refresh-or-safe-return |
| preview | `statePreview` | `noFakeSuccess` | False | refresh-or-safe-return |
| processing | `stateProcessing` | `noFakeSuccess` | True | refresh-or-safe-return |
| public | `statePublic` | `noFakeSuccess` | False | refresh-or-safe-return |
| publication-queued | `statePublicationQueued` | `noFakeSuccess` | False | refresh-or-safe-return |
| published | `statePublished` | `noFakeSuccess` | False | refresh-or-safe-return |
| publishing | `statePublishing` | `noFakeSuccess` | True | refresh-or-safe-return |
| queued | `stateQueued` | `noFakeSuccess` | False | refresh-or-safe-return |
| quota | `stateQuota` | `noFakeSuccess` | True | refresh-or-safe-return |
| rate-limited | `stateRateLimited` | `noFakeSuccess` | False | refresh-or-safe-return |
| read-only | `stateReadOnly` | `permissionHelp` | True | refresh-or-safe-return |
| ready | `stateReady` | `noFakeSuccess` | False | refresh-or-safe-return |
| reauth-required | `stateReauthRequired` | `noFakeSuccess` | False | refresh-or-safe-return |
| rejected | `stateRejected` | `noFakeSuccess` | False | refresh-or-safe-return |
| removal-pending | `stateRemovalPending` | `noFakeSuccess` | False | refresh-or-safe-return |
| removed | `stateRemoved` | `noFakeSuccess` | False | refresh-or-safe-return |
| retry | `stateRetry` | `noFakeSuccess` | False | refresh-or-safe-return |
| review-required | `stateReviewRequired` | `noFakeSuccess` | True | refresh-or-safe-return |
| rollback | `stateRollback` | `noFakeSuccess` | False | refresh-or-safe-return |
| saving | `stateSaving` | `noFakeSuccess` | True | refresh-or-safe-return |
| sending | `stateSending` | `noFakeSuccess` | True | refresh-or-safe-return |
| sent | `stateSent` | `noFakeSuccess` | False | refresh-or-safe-return |
| skipped | `stateSkipped` | `noFakeSuccess` | False | refresh-or-safe-return |
| stale | `stateStale` | `freshnessHelp` | False | refresh-or-safe-return |
| stale-preview | `stateStalePreview` | `freshnessHelp` | True | edit-and-revalidate |
| submitted | `stateSubmitted` | `noFakeSuccess` | False | refresh-or-safe-return |
| submitting | `stateSubmitting` | `noFakeSuccess` | True | refresh-or-safe-return |
| success | `stateSuccess` | `noFakeSuccess` | False | refresh-or-safe-return |
| terminal | `stateTerminal` | `noFakeSuccess` | True | refresh-or-safe-return |
| timeout | `stateTimeout` | `unknownHelp` | True | reconcile |
| unauthorized | `stateUnauthorized` | `permissionHelp` | True | reauthorize |
| uncertain | `stateUncertain` | `unknownHelp` | True | reconcile |
| unknown | `stateUnknown` | `unknownHelp` | True | refresh-or-safe-return |
| uploading | `stateUploading` | `noFakeSuccess` | False | refresh-or-safe-return |
| validated | `stateValidated` | `noFakeSuccess` | False | refresh-or-safe-return |
| validating | `stateValidating` | `noFakeSuccess` | False | refresh-or-safe-return |
| validation | `stateValidation` | `validationHelp` | False | edit-and-revalidate |
| version-conflict | `stateVersionConflict` | `freshnessHelp` | True | edit-and-revalidate |
| versions | `stateVersions` | `noFakeSuccess` | False | refresh-or-safe-return |
| withdrawn | `stateWithdrawn` | `noFakeSuccess` | False | refresh-or-safe-return |
| zero-result | `stateZeroResult` | `emptyHelp` | False | refresh-or-safe-return |
| privileged-target | `statePrivilegedTarget` | `permissionHelp` | False | Main Admin only |

## Domain-specific state truth
- S006 stale-preview clears consent; edit creates new projection hash; acknowledgment is never prechecked.
- S007 Need-created is independent of publication-queued/partial-failure; no whole-operation false failure or false success.
- S012 accepted/rejected/withdrawn are server transitions; role/current Need state further restrict controls.
- S014 no-eligible/over-cap/quota block starting until the documented prerequisite is met. Explicit 1..cap selection discloses excluded count.
- S015 queued/processing/failed display no computed score. Completed owner gets full projection; provider-own excludes competitors. Offline-cache shows version/time, not current result.
- S016 export-processing polls boundedly; export-ready exposes authorized unexpired link; export-failed can re-request saved snapshot; expired must re-request, never reuse URL.
- S017 sending/sent/unknown/unsent are distinct; unknown reconciles by reference before resend.
- S019 pending/review-required never activates boost. Confirmed-active only follows verified payment plus exactly-once activation.
- S020 not-completed/already-rated suppress submission; submitted reflects server receipt.
- S022 RETRY is a scheduled safe retry with server retry_after; UNCERTAIN has no blind retry. PAUSED derives from destination/policy; REMOVED requires evidence; forwards may persist.
- Admin draft→validated→impact-preview→reauth-required→publishing→published. Any edited field/version invalidates validation and impact. Rollback creates a new version; old audit is immutable.


## Canonical two-layer taxonomy
Universal runtime: ready/loading/error/offline/timeout/unauthorized/denied/degraded/maintenance/stale/partial/unknown/read-only/validation/conflicting/rate-limited/empty/zero-result, scoped by screen registry. Business/view state is independently namespaced by screen ID; legacy `states` remains the preview view-state selector, `business_states` excludes runtime overlap. Qualified `state_ids` bind screen→state without pretending route strings equal translation keys.
Admin desired-version lifecycle: draft/validated/impact-preview/published/applying/applied/verified. Failure branches: dependency-blocked/version-conflict/application-failed/verification-failed/requires-verification/drift. Scheduling/freeze are orthogonal policy conditions. Secrets/irreversible actions have rollback N/A. S023 free/payment-required/pending/payment-verified/submission-recovery/submitted/refund-pending/failed/unknown. Payment verified does not mean Offer inserted until server receipt confirms it.


## Comparison and delivery separation1.4
Comparison PENDING/PROCESSING/COMPLETED/FAILED is independent of per-recipient in-app CREATED/read_at and Telegram QUEUED/SENDING/SENT/UNCERTAIN/FAILED/RETRY/SKIPPED. Failed Telegram does not change COMPLETED comparison. PARTIAL evidence coverage differs from unfinished scoring. Runtime offline/stale overlays immutable authorized cached result without changing its business state. NO_HISTORY/UNKNOWN are evidence states, not bad scores.


## Integrated 1.4 contract
Advertising has two layers: campaign DRAFT/VALIDATED/SCHEDULED/ACTIVE/PAUSED/ENDED/ARCHIVED/REJECTED/EXPIRED/BLOCKED; slot DISABLED/EMPTY/LOADING/READY/FAILED/EXPIRED/NOT_ELIGIBLE/FREQUENCY_CAPPED. Slot failure never sets the whole screen to failure. READY alone may render; all other slot states safely omit. Published≠Applied≠Verified.
