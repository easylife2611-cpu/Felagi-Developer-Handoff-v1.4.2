# Navigation / Route Map

Canonical owner: Design_Data/screen-manifest.json; routes.json is generated projection. Five user tabs remain. S011→S023→S012 adds guarded submission; A001 links all23 Admin areas. Authentication/scope rechecked on deep link; no write replay. Dirty draft uses O11.

| ID | Route | Role | API binding | Recovery |
|---|---|---|---|---|
| S001 | `/welcome` | public | api.S001 | preserve draft / S021 |
| S002 | `/auth/telegram` | public | api.S002 | preserve draft / S021 |
| S003 | `/profile` | self | api.S003 | preserve draft / S021 |
| S004 | `/browse` | public | api.S004 | preserve draft / S021 |
| S005 | `/needs/new` | requester | api.S005 | preserve draft / S021 |
| S006 | `/needs/new/public-preview` | requester | api.S006 | preserve draft / S021 |
| S007 | `/needs/:id/created` | requester | api.S007 | preserve draft / S021 |
| S008 | `/needs/:id` | public-or-owner | api.S008 | preserve draft / S021 |
| S009 | `/my/needs` | self | api.S009 | preserve draft / S021 |
| S010 | `/needs/:id/offers` | requester | api.S010 | preserve draft / S021 |
| S011 | `/needs/:id/offers/new` | provider | api.S011 | preserve draft / S021 |
| S012 | `/offers/:id` | participant | api.S012 | preserve draft / S021 |
| S013 | `/my/offers` | self | api.S013 | preserve draft / S021 |
| S014 | `/needs/:id/compare` | requester | api.S014 | preserve draft / S021 |
| S015 | `/comparisons/:id` | participant | api.S015 | preserve draft / S021 |
| S016 | `/needs/:id/comparisons` | participant | api.S016 | preserve draft / S021 |
| S017 | `/offers/:id/messages` | participant | api.S017 | preserve draft / S021 |
| S018 | `/notifications` | self | api.S018 | preserve draft / S021 |
| S019 | `/needs/:id/boost` | requester | api.S019 | preserve draft / S021 |
| S020 | `/needs/:id/rating` | completed-participant | api.S020 | preserve draft / S021 |
| S021 | `/support/report` | authenticated | api.S021 | preserve draft / S021 |
| S022 | `/needs/:id/publications` | requester | api.S022 | preserve draft / S021 |
| S023 | `/needs/:id/offers/unlock` | provider | api.S023 | preserve draft / S021 |
| A001 | `/admin/dashboard` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A001 | A018 |
| A002 | `/admin/telegram` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A002 | A018 |
| A003 | `/admin/health` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A003 | A018 |
| A004 | `/admin/features` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A004 | A018 |
| A005 | `/admin/marketplace` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A005 | A018 |
| A006 | `/admin/ai` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A006 | A018 |
| A007 | `/admin/payments` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A007 | A018 |
| A008 | `/admin/users` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A008 | A018 |
| A009 | `/admin/content` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A009 | A018 |
| A010 | `/admin/notifications` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A010 | A018 |
| A011 | `/admin/files` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A011 | A018 |
| A012 | `/admin/jobs` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A012 | A018 |
| A013 | `/admin/backups` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A013 | A018 |
| A014 | `/admin/integrity` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A014 | A018 |
| A015 | `/admin/security` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A015 | A018 |
| A016 | `/admin/audit` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A016 | A018 |
| A017 | `/admin/settings` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A017 | A018 |
| A018 | `/admin/recovery` | Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause | api.A018 | A018 |
| A019 | `/admin/safe-mode` | Main Admin | api.A019 | A018 |
| A020 | `/admin/monetization` | Main Admin | api.A020 | A018 |
| A021 | `/admin/maintenance` | Main Admin | api.A021 | A018 |
| A022 | `/admin/reports` | Main Admin | api.A022 | A018 |


## Provider result destination
Reuse S015 `/comparisons/:id`; role and included-Offer ownership choose server projection. Version is immutable record identity, not a client permission parameter. S018/authorized Telegram target the same route. No separate provider comparison truth. Unauthorized deep link shows safe denial without competitor data.


## Integrated 1.4 contract
A023 /admin/monetization/sponsored-ads, route ID admin-sponsored-ads, title screenA023, api.A023. Entry A020, back A020; links A016 audit and A018 recovery. S004/S008 ads never replace organic destinations.
