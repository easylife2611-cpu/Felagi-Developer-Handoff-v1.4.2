# Final Interaction Contract

 የእርምጃ ኮንትራት

| Trigger | Preconditions | Behavior/result | Failure/recovery |
|---|---|---|---|
| Primary CTA/Enter | enabled, valid form, idempotency for mutation | disable duplicate, named loader, server response then route | 422 inline; 401 reauth without replay; 409 refresh/reconfirm; timeout reconcile first; preserve values. |
| Search/filter | current query/filter | cancel obsolete request, update count/list | timeout retains query and labels stale; zero result offers clear filters. |
| Publish Need | valid, auth, attachments ready, fresh unchecked→checked consent | create Need; publication state is separate | lookup by reference before resubmit; partial failure distinct. |
| Submit Offer | eligible provider; Need OPEN; before deadline | server saves PENDING | duplicate/deadline/conflict message, draft retained. |
| Accept/reject | owner, pending Offer | O01/O02 with consequences, submit once | cancel returns; conflict reloads; no false state. |
| Compare | owner, eligible set/quota/cap | show criteria then freeze snapshot | none→S010; failed AI retries same snapshot only. |
| Message send | participant, valid text | mark sending then authoritative sent | offline draft; sent/unsent/unknown distinct; reconcile before retry. |
| Payment | owner, active package | exact amount/currency then provider handoff | app return is not proof; pending/reconcile; mismatch review. |
| Stop public post | owner, publication exists | O05 describes scope/limits then server stop | per-destination response; no claim stopped/removed without evidence. |
| Back on dirty form | unsaved changes | save/discard/stay | draft retained if interrupted; no silent loss. |
| Dialog/menu | opened from clear trigger | focus containment; Esc/back if safe; restore focus | prevent unsafe dismissal during irreversible action. |
| OS permission | feature requires it | explain first; request minimum scope | denial keeps unrelated functions available. |

Keyboard: Tab/Shift+Tab visual order; Enter activates; Space toggles; arrows for radios/tabs/menu; Esc closes safe overlays; platform back shares same stack. No action without defined behavior.



## Exact sensitive-action bindings

| Action | Origin / overlay | Endpoint | Preconditions | Confirmed result |
|---|---|---|---|---|
| accept | S012 / O01 | `POST /api/v1/offers/{id}/accept` | PENDING Offer on OPEN Need | IN_PROGRESS Need and ACCEPTED Offer; other pending Offers rejected |
| reject | S012 / O02 | `POST /api/v1/offers/{id}/reject` | PENDING Offer on OPEN Need | REJECTED Offer |
| cancelNeed | S008 / O03 | `POST /api/v1/needs/{id}/cancel` | OPEN Need, no award | CANCELLED Need |
| completeNeed | S008 / O04 | `POST /api/v1/needs/{id}/complete` | IN_PROGRESS Need with accepted Offer | COMPLETED Need; rating eligible |
| stop | S022 / O05 | `POST /api/v1/needs/{id}/telegram-publication/stop` | Owner, current version | Queued sends stopped; removal queued; no guaranteed deletion |
| selectOffers | S014 / O06 | `POST /api/v1/needs/{id}/comparisons` | OPEN Need, eligible PENDING Offers, cap and quota | Immutable snapshot, included IDs and excluded count |
| withdraw | S012 / O07 | `POST /api/v1/offers/{id}/withdraw` | Own PENDING Offer on OPEN Need | WITHDRAWN |
| checkout | S019 / O08 | `POST /api/v1/needs/{id}/boosts` | Active package, eligible own Need | PENDING payment and checkout instruction |
| publish | A017 / O09 | `POST /api/v1/admin/changes/{id}/publish` | Validated fresh draft, reviewed impact, reason, If-Match, risk-specific reauth/2FA | Published new immutable version and audit ID |
| rollback | A017 / O10 | `POST /api/v1/admin/changes/{id}/rollback` | Target approved version, reason, impact, risk-specific reauth/2FA | New version referencing prior value |
| draft | S005 / O11 | `LOCAL` | Dirty form | Encrypted production draft; session-memory preview |

Every mutation records one client request identity and uses server-supported idempotency; unknown responses reconcile before retry. A local lock alone does not prevent duplicates. If-Match is mandatory where DFM requires it. Optimistic UI is limited to reversible display preferences; payment, acceptance, publication and Admin changes wait for server evidence. Settings edits invalidate validation/impact proof. Reauth overlays preserve draft but never resume mutation without another explicit confirmation.

Dialogs show record context, consequence, default safe Cancel and explicit Confirm. Escape/back closes before dispatch; after dispatch retain progress and allow safe navigation only with a persistent reconciliation reference. Focus starts on safe Cancel; trapped until close; returns to invoker or heading if invoker disappeared. O06 is selection with labelled counts and excluded-provider disclosure; O11 is save/discard/stay, not a destructive business mutation.


## Offer Unlock and Main Admin
S011 saves validated draft then evaluates authoritative submission policy via S023; OFF/zero submits once without charge, positive fee displays quote before checkout. Client callback never unlocks. Server verified event automatically completes once; interrupted fulfillment resumes without recharge. Full error/version/refund rules belong to System_Specification/Monetization_Payment_Specification.md.
Admin publish requires immutable validated proposal+impact digest, scoped permission and risk-based reauth. Any edit invalidates prior validation. Published/Applied/Verified remain distinct; runtime cannot be faked by UI save. See Admin canonical contract for lifecycle, bulk, schedule, rollback and focus behavior.


## Locked premium UX quality contract1.4
Clarity + Speed + Continuity + Trust + Comfort + Subtle Delight = Premium Experience. Under-three-second orientation is a usability acceptance target, not a measured result: each screen exposes location, current state and one next primary action. No animation without purpose; no waiting without feedback; no action without response; no error without recovery; no navigation without continuity; no AI output without evidence context; no payment state without authoritative truth.

Perceived performance: reserve card/image/control dimensions; show stable skeleton at same geometry for unavailable content; retain previous authorized cached view with timestamp during refresh; progressively render complete safe sections, never partial final scores. Press feedback is immediate. Optimism allowlist: local filter/sort, disclosure, selection and draft edits only. Payments, Offer submission/acceptance, comparison completion, publication, moderation and Admin writes wait for authoritative receipt. Never celebrate client payment success.

Continuity: retain query/filter/sort/pagination, per-route scroll, selected comparison IDs, expanded sections and forms keyed by actor+entity+revision. Back restores origin; direct authorized deep link has deterministic parent (S015→S016 if history available, otherwise owning Need/own Offer). Tab switch preserves each tab stack; no implicit action replay. Dirty form Save/Discard/Stay; failed save remains dirty. Expired auth retains protected work, then restores only the same actor; different actor cannot access it.

Draft durability: Need/Offer/message/report drafts autosave locally after edits with protected device storage, then sync server draft when authorized/network available. Save acknowledgement says LOCAL_SAVED or SERVER_SAVED accurately. Draft fields exclude payment credentials, tokens and Admin secrets. Attachment files need separate resumable upload references; names alone do not prove retention. On app close/offline/session expiry retain recoverable drafts; sign-out asks whether to discard local protected drafts and explains device policy. Concurrent versions show local/server diff, never silently overwrite. Preview demonstrates tab-memory continuity only; production durable storage requires adapter/device tests.

Visual hierarchy/density: exactly one primary task CTA per screen mode; secondary in neutral style; dangerous action in detail/menu with explicit confirmation. Need cards show title, budget/unknown, location, deadline/unknown and Offer count; details contain description. Offer/comparison cards show essential facts, disclosure holds explanations. Quiet empty state: reason + next action, no gamified reward. Verified success includes next destination: Need→received Offers; Offer→own Offer status; payment→fulfilled action or pending fulfillment.

Motion: use registry durations/easing. Navigation subtle fade/slide, sheet rise, verified success one soft fade; no playful error bounce. Never delay navigation or input for animation. Reduced-motion/low-effects uses static skeleton/no blur/shimmer/transform; same functionality and hierarchy. Default reference intentionally avoids ornamental animation. Delight limited to authoritative Need/Offer completion/payment verification/meaningful completion and first empty-state entry, not every tap.

Touch:48dp minimum,56dp prominent; canonical spacing prevents accidental adjacent taps. Mobile primary action near bottom after content, sticky only when it cannot obscure focused content or keyboard; rare/destructive actions remain detail/menu. Light/dark have identical semantics/action order/readability. Error always states what happened, what remains saved, available retry and safe return. Unknown/stale/Telegram uncertain/AI advisory/payment verified use exact truthful copy.


## Integrated 1.4 contract
Advertising interactions: CTA is neutral and explicit; external destination disclosure precedes leaving. Disclosure expands in place with native keyboard behavior. Campaign edit invalidates validation/impact; publish confirmation includes placement/schedule/caps. No ad display or client click can change Offer selection, AI evaluation or payment truth. Back preserves wizard draft and step.
