# Final Error / Recovery Matrix

| Condition | Display | Data/action treatment | Recovery |
|---|---|---|---|
| 401 | Session expired | Preserve safe encrypted draft; clear protected response cache | Reauth+reauthorize; never auto-replay |
| 403/404 private | Unavailable | No object-existence leak; redact stale cache | Safe origin or support |
| 409 version/state | Current record changed | Preserve draft with current-vs-proposed diff; clear consent/confirmation | Refresh, revalidate, explicit reconfirm |
| 422 field/business | Linked field error and summary | Retain input/valid uploads; focus first error | Correct fields; new confirmation if material |
| 429 | Cooldown from server | Keep draft; no busy loop | Enable after retry_after; manual submit |
| 5xx known failure | Human message + request ID | No fabricated success | Bounded read retries; writes reconcile before retry |
| Timeout/connection loss after write | Outcome unknown | Keep idempotency/request reference; do not duplicate | Query authoritative resource/reconciliation |
| Offline | Cache timestamp + draft-only label | No queued silent business writes | Reconnect, refresh authorization/version, explicit submit |
| Upload/quarantine | Per-file reason | Valid files retained, failed attachment not bound | Replace/retry affected file; respect types/size |
| AI schema/failure | No score; failed snapshot/version | Immutable snapshot retained | Allowed retry same snapshot; Compare Again new version |
| Payment mismatch/late result | Review required | No boost activation or manual confirmed setter | Provider reconciliation job with evidence |
| Telegram uncertain | Unknown outcome | No resend before reconciliation | Admin evidence review; preserve dedupe identity |
| Telegram removal partial | Per-destination evidence | No universal removal promise | Retry only eligible known-message removal |
| Export expired | Link expired | No reuse of signed link | Request new export from stored result |
| Admin dependency failure | Validation report per dependency | No publish; preserve draft | Correct setting/provider readiness; validate again |
| Admin stale draft | Version conflict | No overwrite of current published settings | Rebase diff, revalidate, preview again |
| Maintenance/safe mode | Affected capabilities listed | Preserve authorized reads/history; accept valid existing payment callbacks | Main Admin controlled recovery and health verification |

Retry policy: at most3 automatic transient GET retries with exponential backoff capped30s and jitter; honor longer server Retry-After. Stop on navigation, offline or authorization failure. Mutations never retry simply because a timer expires. Job attempts and provider policies remain DFM/server-owned. Manual recovery retains diagnostic reference without secrets.


## Added recovery contracts
Payment pending → reconcile same intent; verified but interrupted → resume same submission, no charge; ineligible after payment → tracked refund; missing policy → preserve draft/refresh, no free fallback. Admin stale version → load diff/revalidate; invalid dependency → show related control; publish timeout → GET existing change id before retry; apply failure → inspect receipt and guided recovery; verification unavailable → requires verification; drift → compare desired/observed version; restore failure → retain evidence and recovery wizard. Unknown never means failed, empty or success.


## Comparison recovery1.4
No eligible→show exclusion reasons/return; missing material interpretation→confirm/edit; stale version→refresh/reconfirm; quota→show authoritative retry time; timeout/malformed/invented/privacy output→FAILED/no final rows; retry same snapshot/version; unavailable pinned model→explicit new comparison; Telegram failure→retry delivery only; uncertain send→reconcile transport reference; dispute→correct evidence/new version. Draft/Need/Offers remain unchanged. No silent score edit or fake completion.


## Integrated 1.4 contract
ADS-CREATIVE422: show field+locale errors, preserve draft, block publish. ADS-DESTINATION422: approved host/catalog required, no unsafe fallback. ADS-VERSION409: reload/diff/reconfirm. ADS-DELIVERY timeout: omit without blocking core. ADS-COUNTERS-UNKNOWN: no ad. ADS-TRACKING: report unavailable/partial, never zero. ADS-REVOKED: stop new delivery and retain audit.
