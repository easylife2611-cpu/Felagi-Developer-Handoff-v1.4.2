# Final Screen-by-Screen Specifications

**Revision:** FGM-PDS-1.3 / package 1.4.1. **Baseline lock:** Felagi demand-first marketplace; Amharic first with English launch support; product-owner supplied official logo master (canonical source included); navy/orange foundation; requester decision authority. DFM-FDS-1.4 business/security rules remain authoritative, with the explicit presentation integration decisions below. Design completeness is separate from production acceptance.

Shared placement: app bar min64dp, main content16/24/32 gutter, one primary action, 48dp targets/56dp prominent, labelled status above data, recovery inline. Page heading receives focus after navigation; changing locale/theme preserves draft and route. Details below bind every screen to canonical data.

## S001 — Welcome

**Path / ID:** `/welcome` / `welcome`. **Actor:** public. **Template:** auth.

**Purpose/anatomy:** Public entry. Full lockup centered; short purpose; primary sign-in; language option. Authenticated return→S004. States default/auth error/offline. Content max 440dp; logo read once; S002.

**Business/view states:** default, error, offline.

**Runtime conditions:** ready, loading, error, offline, timeout. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** Local projection only; no pre-creation network dependency.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S002. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** auth template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S001-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S001-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S002 — Telegram sign-in

**Path / ID:** `/auth/telegram` / `telegram-login`. **Actor:** public. **Template:** auth.

**Purpose/anatomy:** Anonymous. Back/title; explanation/privacy; Telegram action; help. OIDC start/callback/exchange; no phone/OTP. States starting/awaiting/denied/expired/error/offline; focus order; retry fresh; S001/S003.

**Business/view states:** default, loading, denied, expired, error, offline.

**Runtime conditions:** ready, loading, error, offline, timeout. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** POST /api/v1/auth/telegram/start; GET /api/v1/auth/telegram/callback; POST /api/v1/auth/telegram/exchange.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S003. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** auth template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S002-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S002-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S003 — Profile

**Path / ID:** `/profile` / `profile`. **Actor:** self. **Template:** form.

**Purpose/anatomy:** Own account only. Title; visible fields; optional photo; fixed save. GET me/PATCH profile. States loading/prefilled/validation/saving/saved/conflict/offline; form max720; linked errors; S002/S004.

**Business/view states:** loading, content, validation, success, conflict, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/auth/me; PATCH /api/v1/profile.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `full_name` | text | True | 1–150; DFM §5; reject unlisted fields |
| `phone_number` | tel | False | 0–30; DFM §5; reject unlisted fields |
| `profile_photo` | file | False | 0–server-bound; DFM §5; reject unlisted fields |

**Transitions:** S004. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** form template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S003-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S003-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S004 — Browse Needs

**Path / ID:** `/browse` / `browse`. **Actor:** public. **Template:** cards.

**Purpose/anatomy:** AppBar 64 with mark; search 48; category chips; filter/sort; need feed; separate create action; 5-item nav. GET categories/needs; public projection. States loading/skeleton/list/empty/zero/partial/stale/error/offline. Mobile1/tablet2/laptop3 card columns; S005/S008/S009/S013/S018.

**Business/view states:** loading, content, empty, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/categories; GET /api/v1/needs.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `keyword` | search | False | 0–255; DFM §5; reject unlisted fields |

**Transitions:** S005, S008, S009, S013, S018. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** cards template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S004-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S004-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S005 — Create/Edit Need

**Path / ID:** `/needs/new` / `need-form`. **Actor:** requester. **Template:** form.

**Purpose/anatomy:** Header; title/category/description/budget/currency/location/deadline; multi-file attachments; public intent; save draft/continue. POST/PUT Need + attachment API; authenticated requester; edit only owner OPEN. Draft/validation/upload/saving/conflict/offline; form max720; retain input; S004/S006/S007.

**Business/view states:** draft, validation, uploading, saving, success, conflict, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** POST /api/v1/needs; PUT /api/v1/needs/{id}; POST /api/v1/attachments.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `title` | text | True | 5–255; DFM §5; reject unlisted fields |
| `category_id` | select | True | 0–server-bound; DFM §5; reject unlisted fields |
| `description` | textarea | True | 20–10000; DFM §5; reject unlisted fields |
| `budget_min` | number | False | 0–server-bound; DFM §5; reject unlisted fields |
| `budget_max` | number | False | 0–server-bound; DFM §5; reject unlisted fields |
| `currency` | select | True | 0–server-bound; DFM §5; reject unlisted fields |
| `quantity` | number | False | 0.01–server-bound; DFM §5; reject unlisted fields |
| `location_text` | text | False | 0–255; DFM §5; reject unlisted fields |
| `deadline_at` | datetime-local | False | 0–server-bound; DFM §5; reject unlisted fields |
| `offer_deadline_at` | datetime-local | False | 0–server-bound; DFM §5; reject unlisted fields |
| `attachments` | file | False | 0–server-bound; DFM §5; reject unlisted fields |

**Transitions:** S006. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** form template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S005-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S005-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S006 — Public-post preview

**Path / ID:** `/needs/new/public-preview` / `telegram-preview`. **Actor:** requester. **Template:** preview.

**Purpose/anatomy:** Back/title; privacy note; exact outgoing post; destination policy; unchecked consent; confirm/edit. Uses the locked local public projection before creation; server validates the same fields at commit; stale needs renewed review. Ready/ack/stale/restricted/error/offline; exact copy screen-reader readable; S005/S007/S022.

**Business/view states:** preview, acknowledgement-required, ready, stale-preview.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** Local projection only; no pre-creation network dependency.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S005, S007. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** preview template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S006-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S006-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S007 — Need-created confirmation

**Path / ID:** `/needs/:id/created` / `need-success`. **Actor:** requester. **Template:** confirmation.

**Purpose/anatomy:** Success/reference; Need state; separate Telegram status; detail CTA and browse secondary. POST response + publication status; creation ≠ successful post. Confirmed/queued/partial/unknown/error; S008/S009/S022.

**Business/view states:** confirmed, publication-queued, partial-failure, error.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** POST /api/v1/needs.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S008, S022. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** confirmation template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S007-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S007-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S008 — Need details

**Path / ID:** `/needs/:id` / `need-details`. **Actor:** public-or-owner. **Template:** detail.

**Purpose/anatomy:** Back/title; status/category/title/description/budget/location/deadline/files; role-specific action group. GET Need; public vs owner projection. Provider offer CTA; owner offers/compare/edit/cancel/boost/publication. Loading/public/owner/empty/terminal/partial/stale/forbidden/offline; desktop split view; S004/S005/S010/S011/S014/S019/S022.

**Business/view states:** loading, public, owner, empty-offers, terminal, denied, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/needs/{id}; POST /api/v1/needs/{id}/cancel; POST /api/v1/needs/{id}/complete.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S010, S011, S005, S014, S016, S019, S022, S020, S021. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** detail template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S008-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S008-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S009 — My Needs

**Path / ID:** `/my/needs` / `my-needs`. **Actor:** self. **Template:** cards.

**Purpose/anatomy:** Title/create; status filters; sort; cards with status/count/boost/date; pagination. GET my needs, self only. Loading/list/empty/zero/partial/stale/error/offline; mobile1/tablet2; filters accessible; S005/S008/S010.

**Business/view states:** loading, list, empty, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/my/needs.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S005, S008. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** cards template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S009-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S009-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S010 — Received Offers

**Path / ID:** `/needs/:id/offers` / `received-offers`. **Actor:** requester. **Template:** offers.

**Purpose/anatomy:** Need summary; eligible count/cap; sort; Offer cards; compare CTA. GET offers, owner only; no hidden ranking. Loading/empty/over-cap/terminal/partial/forbidden/stale/offline; desktop accessible table fallback; S008/S012/S014.

**Business/view states:** loading, list, empty, over-cap, terminal, denied, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/needs/{id}/offers.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S012, S014. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** offers template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S010-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S010-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S011 — Submit/Edit Offer

**Path / ID:** `/needs/:id/offers/new` / `offer-form`. **Actor:** provider. **Template:** form.

**Purpose/anatomy:** Need context/deadline; price/currency; proposal; delivery/availability; attachments; submit. Provider not owner; Need OPEN before deadline. Draft/validation/upload/saving/success/duplicate/deadline/conflict/offline; max720; S008/S012/S013.

**Business/view states:** draft, validation, uploading, saving, success, duplicate, deadline-passed, conflict, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** POST /api/v1/needs/{id}/offers; PUT /api/v1/offers/{id}; POST /api/v1/attachments.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `offered_price` | number | True | 0–server-bound; DFM §5; reject unlisted fields |
| `currency` | select | True | 0–server-bound; DFM §5; reject unlisted fields |
| `proposal_message` | textarea | True | 20–10000; DFM §5; reject unlisted fields |
| `delivery_time_text` | text | False | 0–255; DFM §5; reject unlisted fields |
| `availability` | text | False | 0–255; DFM §5; reject unlisted fields |
| `notes` | textarea | False | 0–10000; DFM §5; reject unlisted fields |
| `attachments` | file | False | 0–server-bound; DFM §5; reject unlisted fields |

**Transitions:** S012, S013. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** form template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S011-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S011-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S012 — Offer details

**Path / ID:** `/offers/:id` / `offer-details`. **Actor:** participant. **Template:** detail.

**Purpose/anatomy:** Status; Need context; permitted provider fields; price/proposal/delivery/files; message; owner decision actions when pending. GET Offer. Pending/accepted/rejected/withdrawn/terminal/denied/offline; destructive confirmation; S008/S010/S013/S017/S020.

**Business/view states:** loading, pending, accepted, rejected, withdrawn, confirmation, denied, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/offers/{id}; POST /api/v1/offers/{id}/accept; POST /api/v1/offers/{id}/reject; POST /api/v1/offers/{id}/withdraw.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S017, S020, S021. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** detail template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S012-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S012-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S013 — My Offers

**Path / ID:** `/my/offers` / `my-offers`. **Actor:** self. **Template:** cards.

**Purpose/anatomy:** Status filters; Need/amount/state/date cards. GET my offers, self only. Loading/list/empty/zero/terminal/error/offline; preserve filter; S008/S011/S012.

**Business/view states:** loading, list, empty, terminal, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/my/offers.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S012. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** cards template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S013-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S013-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S014 — Compare confirmation

**Path / ID:** `/needs/:id/compare` / `compare-confirm`. **Actor:** requester. **Template:** selection.

**Purpose/anatomy:** Need context; eligible count; four equal criteria; snapshot info; explicit selection above cap; advisory notice; start. Owner only. Ready/none/over-cap/quota/processing/conflict/offline; announce count; S010/S015/S016.

**Business/view states:** ready, no-eligible-offers, over-cap-selection, quota, processing, conflict.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/needs/{id}/offers; POST /api/v1/needs/{id}/comparisons.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S015, S016. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** selection template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S014-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S014-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S015 — AI comparison result

**Path / ID:** `/comparisons/:id` / `comparison-result`. **Actor:** participant. **Template:** comparison.

**Purpose/anatomy:** Version/state; AI advice notice; each offer score+coverage; criteria/evidence/missing/risk; requester next action. GET results, owner full/provider restricted. Queued/processing/completed/failed/partial/offline cache/denied; cards mobile, matrix desktop with text alternative; S012/S014/S016.

**Business/view states:** queued, processing, completed-owner, completed-provider-own, failed-retry, denied, offline-cached.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/comparisons/{id}; GET /api/v1/comparisons/{id}/results; POST /api/v1/comparisons/{id}/retry.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S012, S016. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** comparison template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S015-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S015-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S016 — Comparison history/export

**Path / ID:** `/needs/:id/comparisons` / `comparison-history`. **Actor:** participant. **Template:** history.

**Purpose/anatomy:** Version list newest first, time/count/rules; export controls for saved version. Role projection. Loading/empty/ready/processing/failed/expired/offline; export doesn't rerun AI; S008/S014/S015.

**Business/view states:** loading, empty, versions, export-processing, export-ready, export-failed, expired, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/needs/{id}/comparisons; POST /api/v1/comparisons/{id}/exports; GET /api/v1/exports/{id}; GET /api/v1/exports/{id}/download; GET /api/v1/my/comparisons.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S015. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** history template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S016-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S016-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S017 — Messages

**Path / ID:** `/offers/:id/messages` / `messages`. **Actor:** participant. **Template:** conversation.

**Purpose/anatomy:** Offer context; chronological messages/time; multiline composer and send above keyboard. Participants only. Loading/empty/sending/sent/failed/rate-limit/offline draft/denied/session expired; announce politely; S012/S018/S021.

**Business/view states:** loading, empty, sending, sent, validation, rate-limited, error, offline-draft, denied.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/offers/{id}/messages; POST /api/v1/offers/{id}/messages.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `content` | textarea | True | 1–5000; DFM §5; reject unlisted fields |
| `attachments` | file | False | 0–server-bound; DFM §5; reject unlisted fields |

**Transitions:** S012, S021. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** conversation template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S017-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S017-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S018 — Notifications

**Path / ID:** `/notifications` / `notifications`. **Actor:** self. **Template:** notifications.

**Purpose/anatomy:** unread count; supported filters; date groups; type/title/summary/time/read. Recipient only; item marks read then reauthorizes deep link. Loading/empty/list/marking/error/offline/partial; read state not color-only; S004/S008/S010/S015/S019/S022.

**Business/view states:** loading, list, empty, marking-read, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/notifications; POST /api/v1/notifications/{id}/read.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S008, S012, S015, S019, S022. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** notifications template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S018-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S018-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S019 — Boost/Payments

**Path / ID:** `/needs/:id/boost` / `boost-payment`. **Actor:** requester. **Template:** payment.

**Purpose/anatomy:** Need context; package/duration/price/currency; payment handoff; pending state. Owner only; server confirms payment. Loading/packages/checkout/pending/confirmed/failed/review/timeout/offline; no local success; S008/S009/S018.

**Business/view states:** loading, packages, disabled, checkout, pending, confirmed-active, failed, review-required, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/boost-packages; POST /api/v1/needs/{id}/boosts; GET /api/v1/payments/{id}.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S008. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** payment template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S019-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S019-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S020 — Rating

**Path / ID:** `/needs/:id/rating` / `rating`. **Actor:** completed-participant. **Template:** form.

**Purpose/anatomy:** completed relationship; labelled 1–5 radio; optional comment; submit. Completed participants only. Eligible/validation/submitting/submitted/already/not completed/denied/offline draft; verbal scale; S008/S012.

**Business/view states:** eligible, validation, submitted, already-rated, not-completed, denied, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** POST /api/v1/needs/{id}/ratings.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `score` | rating | True | 1–5; DFM §5; reject unlisted fields |
| `review` | textarea | False | 0–10000; DFM §5; reject unlisted fields |

**Transitions:** S008. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** form template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S020-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S020-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S021 — Report/Support

**Path / ID:** `/support/report` / `report-support`. **Actor:** authenticated. **Template:** form.

**Purpose/anatomy:** Reason; accessible related record reference; details/privacy note; submit/reference. Authenticated; POST report. Form/validation/submitting/submitted/rate limit/error/offline draft/denied; errors linked; S008/S012/S017/S018.

**Business/view states:** form, validation, submitting, submitted, rate-limited, error, offline-draft.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** POST /api/v1/reports.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `entity_type` | select | True | 1–255; DFM reports projection; allowlisted enum and authorized source context |
| `entity_id` | text | True | 1–255; DFM reports projection; allowlisted enum and authorized source context |
| `reason_code` | select | True | 1–255; DFM reports projection; allowlisted enum and authorized source context |
| `details` | textarea | False | 0–10000; DFM §5; reject unlisted fields |

**Transitions:** S004. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** form template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S021-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S021-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## S022 — Telegram status/stop

**Path / ID:** `/needs/:id/publications` / `telegram-status`. **Actor:** requester. **Template:** publications.

**Purpose/anatomy:** Need context; authorized destination rows/status/time; stop/remove action and already-posted limits. Owner only. queued/sending/posted/retry/uncertain/failed/skipped/removal-pending/removed/paused/offline/denied; mobile cards/desktop table; never claim unsupported removal; S006/S007/S008/S018.

**Business/view states:** queued, sending, posted, retry, uncertain, failed, skipped, removal-pending, removed, paused.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/needs/{id}/telegram-publications; POST /api/v1/needs/{id}/telegram-publication/stop.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** S008. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** publications template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case S022-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case S022-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

## A001 — Dashboard

**Path / ID:** `/admin/dashboard` / `admin-dashboard`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Counts, incident list, freshness, bounded search

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/overview.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A001-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A001-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** count, incident, checkedAt. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A002 — Telegram Distribution

**Path / ID:** `/admin/telegram` / `admin-telegram`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Destinations, permission proof, rights check, category allowlist, caps, quiet hours, publication queue, uncertain sends, removal evidence

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, confirmation, processing, completed, conflict.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/telegram/destinations; POST /api/v1/admin/telegram/destinations; POST /api/v1/admin/telegram/destinations/{id}/validate; POST /api/v1/admin/telegram/destinations/{id}/activate; POST /api/v1/admin/telegram/destinations/{id}/pause; GET /api/v1/admin/telegram/publications; POST /api/v1/admin/telegram/publications/{id}/retry-or-reconcile.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `telegram_chat_id` | text | True | 1–255; Design Integration Contract; server enum/range/permission validation |
| `destination_name` | text | True | 1–255; Design Integration Contract; server enum/range/permission validation |
| `destination_type` | text | True | 1–255; Design Integration Contract; server enum/range/permission validation |
| `allowed_categories` | text | True | 1–255; Design Integration Contract; server enum/range/permission validation |
| `daily_cap` | number | True | 0–server-bound; Design Integration Contract; server enum/range/permission validation |
| `quiet_hours` | text | False | 1–255; Design Integration Contract; server enum/range/permission validation |
| `evidence_ref` | text | True | 1–255; DFM §5; reject unlisted fields |
| `permission_expires` | date | False | 1–server-bound; Design Integration Contract; server enum/range/permission validation |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A002-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A002-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** destination, permissionProof, rights, caps, quietHours, queue. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A003 — Health

**Path / ID:** `/admin/health` / `admin-health`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** DB, storage, queue, cron, AI, Telegram, payment and disk health with checked_at and incident link

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/health.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A003-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A003-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** component, status, latency, checkedAt. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A004 — Features

**Path / ID:** `/admin/features` / `admin-features`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Feature flags, dependencies, effective safe-mode override, active version

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, draft, validating, validated, impact-preview, reauth-required, publishing, published, version-conflict, rollback.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/settings; GET /api/v1/admin/settings/{key}/versions; POST /api/v1/admin/changes; POST /api/v1/admin/changes/{id}/validate; POST /api/v1/admin/changes/{id}/preview; POST /api/v1/admin/changes/{id}/publish; POST /api/v1/admin/changes/{id}/rollback.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `setting_key` | text | True | 1–255; DFM §5; reject unlisted fields |
| `proposed_value` | textarea | True | 1–10000; DFM §5; reject unlisted fields |
| `base_version` | number | True | 1–server-bound; DFM §5; reject unlisted fields |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A004-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A004-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** fieldSettingKey, effective, dependencies, version. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A005 — Marketplace

**Path / ID:** `/admin/marketplace` / `admin-marketplace`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Needs, Offers, categories, reports; masked support projection; assigned report queue

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, confirmation, processing, completed, conflict.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/reports; GET /api/v1/admin/marketplace; POST /api/v1/admin/reports/{id}/resolve.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `record_id` | text | True | 1–255; DFM §5; reject unlisted fields |
| `resolution` | text | True | 1–255; Design Integration Contract; server enum/range/permission validation |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A005-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A005-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** record, reportType, assigned, resolution. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A006 — AI

**Path / ID:** `/admin/ai` / `admin-ai`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Criteria and prompt versions, model ID, caps, token cost, failed comparison jobs

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, draft, validating, validated, impact-preview, reauth-required, publishing, published, version-conflict, rollback.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/settings; GET /api/v1/admin/settings/{key}/versions; POST /api/v1/admin/changes; POST /api/v1/admin/changes/{id}/validate; POST /api/v1/admin/changes/{id}/preview; POST /api/v1/admin/changes/{id}/publish; POST /api/v1/admin/changes/{id}/rollback; GET /api/v1/admin/ai/usage.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `setting_key` | text | True | 1–255; DFM §5; reject unlisted fields |
| `proposed_value` | textarea | True | 1–10000; DFM §5; reject unlisted fields |
| `base_version` | number | True | 1–server-bound; DFM §5; reject unlisted fields |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A006-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A006-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** criteriaVersion, promptVersion, model, caps, cost. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A007 — Payments

**Path / ID:** `/admin/payments` / `admin-payments`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Payment reference, amount/currency, provider evidence, mismatch, review status, reconciliation job

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, confirmation, processing, completed, conflict.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/payments; POST /api/v1/admin/payments/{id}/reconcile.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `record_id` | text | True | 1–255; DFM §5; reject unlisted fields |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |
| `evidence_ref` | text | True | 1–255; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A007-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A007-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** record, amount, fieldCurrency, providerReference, status. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A008 — Users

**Path / ID:** `/admin/users` / `admin-users`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Redacted identity, account state, privileged-role indicator, suspend reason/review date

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, confirmation, processing, completed, conflict, privileged-target.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/users; POST /api/v1/admin/users/{id}/suspend.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `record_id` | text | True | 1–255; DFM §5; reject unlisted fields |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |
| `review_at` | date | True | 0–server-bound; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A008-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A008-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** maskedIdentity, status, privileged, reviewDate. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A009 — Content

**Path / ID:** `/admin/content` / `admin-content`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Reviewed Amharic/English content, typed draft, diff and version history

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, draft, validating, validated, impact-preview, reauth-required, publishing, published, version-conflict, rollback.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/settings; GET /api/v1/admin/settings/{key}/versions; POST /api/v1/admin/changes; POST /api/v1/admin/changes/{id}/validate; POST /api/v1/admin/changes/{id}/preview; POST /api/v1/admin/changes/{id}/publish; POST /api/v1/admin/changes/{id}/rollback.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `setting_key` | text | True | 1–255; DFM §5; reject unlisted fields |
| `proposed_value` | textarea | True | 1–10000; DFM §5; reject unlisted fields |
| `base_version` | number | True | 1–server-bound; DFM §5; reject unlisted fields |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A009-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A009-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** contentKey, language, version, updated. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A010 — Notifications

**Path / ID:** `/admin/notifications` / `admin-notifications`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Delivery job class, state, attempt, next retry and safe error; no fabricated read evidence

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, confirmation, processing, completed, conflict.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/jobs; POST /api/v1/admin/jobs/{id}/retry.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `record_id` | text | True | 1–255; DFM §5; reject unlisted fields |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |
| `evidence_ref` | text | True | 1–255; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A010-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A010-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** jobClass, status, attempt, retryAfter. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A011 — Files

**Path / ID:** `/admin/files` / `admin-files`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Private file metadata, owner/purpose, quarantine status, retention deadline, audit access

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/files.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A011-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A011-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** record, purposeField, quarantine, retention. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A012 — Jobs

**Path / ID:** `/admin/jobs` / `admin-jobs`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Job class, request reference, attempt, eligibility, status, retry-after, last safe error

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, confirmation, processing, completed, conflict.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/jobs; POST /api/v1/admin/jobs/{id}/retry.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `record_id` | text | True | 1–255; DFM §5; reject unlisted fields |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |
| `evidence_ref` | text | True | 1–255; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A012-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A012-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** jobClass, status, attempt, retryAfter. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A013 — Backups

**Path / ID:** `/admin/backups` / `admin-backups`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Backup timestamp, scope, checksum, encryption status, restore drill evidence; no direct restore button

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/backups.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A013-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A013-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** updated, scope, checksum, encrypted, restoreEvidence. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A014 — Integrity

**Path / ID:** `/admin/integrity` / `admin-integrity`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Integrity report scope, run status, counts, safe references and last completed check

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, confirmation, processing, completed, conflict.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/integrity; POST /api/v1/admin/integrity/run.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `scope` | text | True | 1–255; Design Integration Contract; server enum/range/permission validation |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A014-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A014-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** scope, status, findings, checkedAt. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A015 — Security

**Path / ID:** `/admin/security` / `admin-security`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Role-scoped sessions/events, masked secret references, second-factor and rotation evidence

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/security.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A015-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A015-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** session, secretRef, checkedAt. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A016 — Audit

**Path / ID:** `/admin/audit` / `admin-audit`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Actor, purpose, timestamp, action, resource, request ID, before/after masked values and version

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/audit.

**Fields:** No editable business fields; read-only server projection.

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A016-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A016-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** actor, purposeField, requestId, beforeAfter, version. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A017 — Settings

**Path / ID:** `/admin/settings` / `admin-settings`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Typed key/value, risk, effective value, draft/validate/preview/publish, immutable versions and rollback

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, draft, validating, validated, impact-preview, reauth-required, publishing, published, version-conflict, rollback.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/settings; GET /api/v1/admin/settings/{key}/versions; POST /api/v1/admin/changes; POST /api/v1/admin/changes/{id}/validate; POST /api/v1/admin/changes/{id}/preview; POST /api/v1/admin/changes/{id}/publish; POST /api/v1/admin/changes/{id}/rollback.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `setting_key` | text | True | 1–255; DFM §5; reject unlisted fields |
| `proposed_value` | textarea | True | 1–10000; DFM §5; reject unlisted fields |
| `base_version` | number | True | 1–server-bound; DFM §5; reject unlisted fields |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A017-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A017-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** fieldSettingKey, effective, risk, version. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.

## A018 — Recovery

**Path / ID:** `/admin/recovery` / `admin-recovery`. **Actor:** Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. **Template:** admin.

**Purpose/anatomy:** Safe mode, dependent features, callbacks retained, paid pending boosts, integrity and rollback evidence

**Business/view states:** overview, detail, empty, loading, denied, stale, error, offline, confirmation, processing, completed, conflict.

**Runtime conditions:** ready, error, offline, timeout, unauthorized, denied, degraded, maintenance, loading, stale, partial, unknown, read-only, validation, conflicting, rate-limited, empty, zero-result. Their exact display, mutation gate and recovery are in the Runtime-State Matrix. All data statuses must carry source/time; a selected preview state is never live evidence.

**Data contract:** GET /api/v1/admin/health; POST /api/v1/admin/recovery/safe-mode; POST /api/v1/admin/recovery/feature-flags.

**Fields:** 

| Name | Type | Required | Bounds / semantics |
|---|---|---|---|
| `desired_mode` | text | True | 1–255; Design Integration Contract; server enum/range/permission validation |
| `reason` | textarea | True | 1–1000; DFM §5; reject unlisted fields |

**Transitions:** A001, A016, A017. Origin and action constraints are in the Transition/Interaction contracts; links are not grants of access.

**Responsive:** admin template: mobile single column, tablet two-column data cards, desktop bounded detail/table. Forms stay max720; data tables have card equivalents; Admin record details are inline below 1200 and side-by-side above. **Accessibility:** labelled heading, logical order, visible error summary, focus retained on refresh and restored on modal close; minimum48 targets; no essential truncation.

**Acceptance case A018-A:** render every applicable state in both locales/themes, check only role-authorized actions, preserve draft through error and locale change, reauthorize deep link, verify no successful server claim without response. **Recovery case A018-R:** inject 401/403/409/422/429/timeout where its API supports them; preserve safe input, avoid mutation replay and return to origin.

**Visible columns:** safeMode, dependencies, callbacks, paidPending. Each is localized; unknown evidence stays unknown. **Record panel:** Side panel >=1200px, inline expanded record below; close returns focus to row trigger. **Audit:** Record actor, purpose, resource, reason, request ID, timestamp and safe version delta; never secrets.


## Reconciled1.3 screen bindings

All existing screen anatomy above is retained. Updated registry fields govern IDs/API/states. Main Admin field rows are replaced by typed registry controls; generic setting_key/proposed_value editors are retired. Full per-area behavior is owned by Admin/Final_Admin_Control_Center_Design.md.

### S023 Offer Submission Unlock
Provider-only `/needs/:id/offers/unlock`; draft context, fixed quote/currency, reason, payment status, saved-draft notice, Pay/refresh/resume/back/support. Uses FgTextField/FgButton/FgStatePanel and existing payment pattern. New intent requires validated server policy; no preview default bypass. States and APIs in manifest. Pending preserves draft; verified automatically fulfills; interrupted resume does not pay twice; closed Need after payment shows refund pending. Layout form max720, single column mobile; amount wraps with bdi; accessible polite status/error focus. Both locales from canonical resources. Acceptance POL01–12.

### A001 Dashboard
Route `/admin/dashboard`; controls read evidence; title `screenA001`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A002 Telegram Distribution
Route `/admin/telegram`; controls telegram, telegramDestination; title `screenA002`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A003 Health
Route `/admin/health`; controls read evidence; title `screenA003`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A004 Features
Route `/admin/features`; controls allowNeeds, allowOffers, messaging, aiCompare; title `screenA004`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A005 Marketplace
Route `/admin/marketplace`; controls maxOffers; title `screenA005`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A006 AI
Route `/admin/ai`; controls aiModel, aiTimeout; title `screenA006`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A007 Payments
Route `/admin/payments`; controls payments, reconcilePayment; title `screenA007`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A008 Users
Route `/admin/users`; controls suspendUser; title `screenA008`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A009 Content
Route `/admin/content`; controls welcomeText, supportText, helpText, policyText, noticeText; title `screenA009`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A010 Notifications
Route `/admin/notifications`; controls notificationRetry; title `screenA010`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A011 Files
Route `/admin/files`; controls fileQuarantine; title `screenA011`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A012 Jobs
Route `/admin/jobs`; controls retryLimit, queueConcurrency, retryJob; title `screenA012`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A013 Backups
Route `/admin/backups`; controls verifyBackup; title `screenA013`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A014 Integrity
Route `/admin/integrity`; controls checkIntegrity; title `screenA014`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A015 Security
Route `/admin/security`; controls rateLimit, paymentSecret, aiSecret, telegramSecret; title `screenA015`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A016 Audit
Route `/admin/audit`; controls read evidence; title `screenA016`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A017 Settings
Route `/admin/settings`; controls freeze; title `screenA017`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A018 Recovery
Route `/admin/recovery`; controls restoreBackup, diagnose; title `screenA018`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A019 Safe Mode
Route `/admin/safe-mode`; controls safeMode; title `screenA019`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A020 Monetization
Route `/admin/monetization`; controls boost, offerUnlock, offerFee, offerCurrency, boostPackages; title `screenA020`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A021 Maintenance
Route `/admin/maintenance`; controls maintenance, maintenanceText, refreshCache; title `screenA021`; recovery A018; screen-specific contract in Admin canonical per-area section.

### A022 Reports
Route `/admin/reports`; controls reviewReport; title `screenA022`; recovery A018; screen-specific contract in Admin canonical per-area section.


## S014/S015/S016 canonical replacement1.4
The earlier abbreviated comparison anatomy is superseded by the screen contracts in AI_Evaluation_Contract.md. S014 binds requirement confirmation and explicit eligibility; S015 has requester full and provider-own role projections on the same route; S016 exposes immutable history and stored export. No new screen or parallel comparison source. The preview implements summary/cards/expandable criterion details, coverage, near-tie notice, own-result mode, notification destination and persistent selection. The reference uses fictional version2 and never calls a model.


## Canonical 1.4 bindings
### S001 — Welcome
Purpose: Welcome in the Need-first journey. Entry: authorized deep link. Primary action key: signIn. Permission: public. Data: api.S001 in api-mappings.json; form fields none. States: S001.default, S001.error, S001.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S001. Ads: prohibited.

### S002 — Telegram sign-in
Purpose: Telegram sign-in in the Need-first journey. Entry: S001, authorized deep link. Primary action key: signIn. Permission: public. Data: api.S002 in api-mappings.json; form fields none. States: S002.default, S002.loading, S002.denied, S002.expired, S002.error, S002.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S002. Ads: prohibited.

### S003 — Profile
Purpose: Profile in the Need-first journey. Entry: S002, authorized deep link. Primary action key: save. Permission: self. Data: api.S003 in api-mappings.json; form fields full_name, phone_number, profile_photo. States: S003.loading, S003.content, S003.validation, S003.success, S003.conflict, S003.error, S003.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S003. Ads: prohibited.

### S004 — Browse Needs
Purpose: Browse Needs in the Need-first journey. Entry: S003, S021, authorized deep link. Primary action key: createNeed. Permission: public. Data: api.S004 in api-mappings.json; form fields keyword. States: S004.loading, S004.content, S004.empty, S004.error, S004.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S004. Ads: AD_BROWSE_INLINE_01, AD_SEARCH_RESULTS_INLINE_01.

### S005 — Create/Edit Need
Purpose: Create/Edit Need in the Need-first journey. Entry: S004, S006, S008, S009, authorized deep link. Primary action key: continue. Permission: requester. Data: api.S005 in api-mappings.json; form fields title, category_id, description, budget_min, budget_max, currency, quantity, location_text, deadline_at, offer_deadline_at, attachments. States: S005.draft, S005.validation, S005.uploading, S005.saving, S005.success, S005.conflict, S005.error, S005.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S005. Ads: prohibited.

### S006 — Public-post preview
Purpose: Public-post preview in the Need-first journey. Entry: S005, authorized deep link. Primary action key: continue. Permission: requester. Data: api.S006 in api-mappings.json; form fields none. States: S006.preview, S006.acknowledgement-required, S006.ready, S006.stale-preview. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S006. Ads: prohibited.

### S007 — Need-created confirmation
Purpose: Need-created confirmation in the Need-first journey. Entry: S006, authorized deep link. Primary action key: screenS010. Permission: requester. Data: api.S007 in api-mappings.json; form fields none. States: S007.confirmed, S007.publication-queued, S007.partial-failure, S007.error. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S007. Ads: prohibited.

### S008 — Need details
Purpose: Need details in the Need-first journey. Entry: S004, S007, S009, S018, S019, S020, S022, authorized deep link. Primary action key: completeNeed. Permission: public-or-owner. Data: api.S008 in api-mappings.json; form fields none. States: S008.loading, S008.public, S008.owner, S008.empty-offers, S008.terminal, S008.denied, S008.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S008. Ads: AD_NEED_DETAIL_BOTTOM_01.

### S009 — My Needs
Purpose: My Needs in the Need-first journey. Entry: S004, authorized deep link. Primary action key: view. Permission: self. Data: api.S009 in api-mappings.json; form fields none. States: S009.loading, S009.list, S009.empty, S009.error, S009.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S009. Ads: prohibited.

### S010 — Received Offers
Purpose: Received Offers in the Need-first journey. Entry: S008, authorized deep link. Primary action key: compare. Permission: requester. Data: api.S010 in api-mappings.json; form fields none. States: S010.loading, S010.list, S010.empty, S010.over-cap, S010.terminal, S010.denied, S010.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S010. Ads: prohibited.

### S011 — Submit/Edit Offer
Purpose: Submit/Edit Offer in the Need-first journey. Entry: S008, S023, authorized deep link. Primary action key: submit. Permission: provider. Data: api.S011 in api-mappings.json; form fields offered_price, currency, proposal_message, delivery_time_text, availability, notes, attachments. States: S011.draft, S011.validation, S011.uploading, S011.saving, S011.success, S011.duplicate, S011.deadline-passed, S011.conflict, S011.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S011. Ads: prohibited.

### S012 — Offer details
Purpose: Offer details in the Need-first journey. Entry: S010, S013, S015, S017, S018, S023, authorized deep link. Primary action key: accept. Permission: participant. Data: api.S012 in api-mappings.json; form fields none. States: S012.loading, S012.pending, S012.accepted, S012.rejected, S012.withdrawn, S012.confirmation, S012.denied, S012.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S012. Ads: prohibited.

### S013 — My Offers
Purpose: My Offers in the Need-first journey. Entry: S004, authorized deep link. Primary action key: view. Permission: self. Data: api.S013 in api-mappings.json; form fields none. States: S013.loading, S013.list, S013.empty, S013.terminal, S013.error, S013.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S013. Ads: prohibited.

### S014 — Compare confirmation
Purpose: Compare confirmation in the Need-first journey. Entry: S008, S010, authorized deep link. Primary action key: evaluateOffers. Permission: requester. Data: api.S014 in api-mappings.json; form fields none. States: S014.ready, S014.no-eligible-offers, S014.over-cap-selection, S014.quota, S014.processing, S014.conflict, S014.insufficient-information, S014.requirement-confirmation. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S014. Ads: prohibited.

### S015 — AI comparison result
Purpose: AI comparison result in the Need-first journey. Entry: S014, S016, S018, authorized deep link. Primary action key: reviewOffer. Permission: comparison requester or included provider, own projection only. Data: api.S015 in api-mappings.json; form fields none. States: S015.queued, S015.processing, S015.completed-owner, S015.completed-provider-own, S015.failed-retry, S015.denied, S015.offline-cached, S015.close-result, S015.provider-own-result. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S015. Ads: prohibited.

### S016 — Comparison history/export
Purpose: Comparison history/export in the Need-first journey. Entry: S008, S014, S015, authorized deep link. Primary action key: compareAgain. Permission: participant. Data: api.S016 in api-mappings.json; form fields none. States: S016.loading, S016.empty, S016.versions, S016.export-processing, S016.export-ready, S016.export-failed, S016.expired, S016.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S016. Ads: prohibited.

### S017 — Messages
Purpose: Messages in the Need-first journey. Entry: S012, authorized deep link. Primary action key: send. Permission: participant. Data: api.S017 in api-mappings.json; form fields content, attachments. States: S017.loading, S017.empty, S017.sending, S017.sent, S017.validation, S017.rate-limited, S017.error, S017.offline-draft, S017.denied. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S017. Ads: prohibited.

### S018 — Notifications
Purpose: Notifications in the Need-first journey. Entry: S004, authorized deep link. Primary action key: view. Permission: self. Data: api.S018 in api-mappings.json; form fields none. States: S018.loading, S018.list, S018.empty, S018.marking-read, S018.error, S018.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S018. Ads: prohibited.

### S019 — Boost/Payments
Purpose: Boost/Payments in the Need-first journey. Entry: S008, S018, authorized deep link. Primary action key: checkout. Permission: requester. Data: api.S019 in api-mappings.json; form fields none. States: S019.loading, S019.packages, S019.disabled, S019.checkout, S019.pending, S019.confirmed-active, S019.failed, S019.review-required, S019.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S019. Ads: prohibited.

### S020 — Rating
Purpose: Rating in the Need-first journey. Entry: S008, S012, authorized deep link. Primary action key: save. Permission: completed-participant. Data: api.S020 in api-mappings.json; form fields score, review. States: S020.eligible, S020.validation, S020.submitted, S020.already-rated, S020.not-completed, S020.denied, S020.offline. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S020. Ads: prohibited.

### S021 — Report/Support
Purpose: Report/Support in the Need-first journey. Entry: S008, S012, S017, S023, authorized deep link. Primary action key: save. Permission: authenticated. Data: api.S021 in api-mappings.json; form fields entity_type, entity_id, reason_code, details. States: S021.form, S021.validation, S021.submitting, S021.submitted, S021.rate-limited, S021.error, S021.offline-draft. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S021. Ads: prohibited.

### S022 — Telegram status/stop
Purpose: Telegram status/stop in the Need-first journey. Entry: S007, S008, S018, authorized deep link. Primary action key: stop. Permission: requester. Data: api.S022 in api-mappings.json; form fields none. States: S022.queued, S022.sending, S022.posted, S022.retry, S022.uncertain, S022.failed, S022.skipped, S022.removal-pending, S022.removed, S022.paused. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S022. Ads: prohibited.

### S023 — Offer Submission Unlock
Purpose: Offer Submission Unlock in the Need-first journey. Entry: S011, authorized deep link. Primary action key: submit. Permission: provider. Data: api.S023 in api-mappings.json; form fields none. States: S023.free, S023.payment-required, S023.pending, S023.payment-verified, S023.submission-recovery, S023.submitted, S023.refund-pending, S023.failed, S023.unknown. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-S023. Ads: prohibited.

### A001 — Dashboard
Purpose: Manage Dashboard. Entry: A001, A002, A003, A004, A005, A006, A007, A008, A009, A010, A011, A012, A013, A014, A015, A016, A017, A018, A019, A020, A021, A022, authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A001 in api-mappings.json; form fields none. States: A001.overview, A001.detail, A001.empty, A001.loading, A001.denied, A001.stale, A001.error, A001.offline, A001.requires-verification, A001.drift, A001.application-failed, A001.verification-failed, A001.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A001. Ads: prohibited.

### A002 — Telegram Distribution
Purpose: Manage Telegram Distribution. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A002 in api-mappings.json; form fields none. States: A002.overview, A002.detail, A002.empty, A002.loading, A002.denied, A002.stale, A002.error, A002.offline, A002.confirmation, A002.processing, A002.completed, A002.conflict, A002.requires-verification, A002.drift, A002.application-failed, A002.verification-failed, A002.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A002. Ads: prohibited.

### A003 — Health
Purpose: Manage Health. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A003 in api-mappings.json; form fields none. States: A003.overview, A003.detail, A003.empty, A003.loading, A003.denied, A003.stale, A003.error, A003.offline, A003.requires-verification, A003.drift, A003.application-failed, A003.verification-failed, A003.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A003. Ads: prohibited.

### A004 — Features
Purpose: Manage Features. Entry: authorized deep link. Primary action key: publish. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A004 in api-mappings.json; form fields none. States: A004.overview, A004.detail, A004.empty, A004.loading, A004.denied, A004.stale, A004.error, A004.offline, A004.draft, A004.validating, A004.validated, A004.impact-preview, A004.reauth-required, A004.publishing, A004.published, A004.version-conflict, A004.rollback, A004.requires-verification, A004.drift, A004.application-failed, A004.verification-failed, A004.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A004. Ads: prohibited.

### A005 — Marketplace
Purpose: Manage Marketplace. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A005 in api-mappings.json; form fields none. States: A005.overview, A005.detail, A005.empty, A005.loading, A005.denied, A005.stale, A005.error, A005.offline, A005.confirmation, A005.processing, A005.completed, A005.conflict, A005.requires-verification, A005.drift, A005.application-failed, A005.verification-failed, A005.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A005. Ads: prohibited.

### A006 — AI
Purpose: Manage AI. Entry: authorized deep link. Primary action key: publish. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A006 in api-mappings.json; form fields none. States: A006.overview, A006.detail, A006.empty, A006.loading, A006.denied, A006.stale, A006.error, A006.offline, A006.draft, A006.validating, A006.validated, A006.impact-preview, A006.reauth-required, A006.publishing, A006.published, A006.version-conflict, A006.rollback, A006.requires-verification, A006.drift, A006.application-failed, A006.verification-failed, A006.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A006. Ads: prohibited.

### A007 — Payments
Purpose: Manage Payments. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A007 in api-mappings.json; form fields none. States: A007.overview, A007.detail, A007.empty, A007.loading, A007.denied, A007.stale, A007.error, A007.offline, A007.confirmation, A007.processing, A007.completed, A007.conflict, A007.requires-verification, A007.drift, A007.application-failed, A007.verification-failed, A007.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A007. Ads: prohibited.

### A008 — Users
Purpose: Manage Users. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A008 in api-mappings.json; form fields none. States: A008.overview, A008.detail, A008.empty, A008.loading, A008.denied, A008.stale, A008.error, A008.offline, A008.confirmation, A008.processing, A008.completed, A008.conflict, A008.privileged-target, A008.requires-verification, A008.drift, A008.application-failed, A008.verification-failed, A008.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A008. Ads: prohibited.

### A009 — Content
Purpose: Manage Content. Entry: authorized deep link. Primary action key: publish. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A009 in api-mappings.json; form fields none. States: A009.overview, A009.detail, A009.empty, A009.loading, A009.denied, A009.stale, A009.error, A009.offline, A009.draft, A009.validating, A009.validated, A009.impact-preview, A009.reauth-required, A009.publishing, A009.published, A009.version-conflict, A009.rollback, A009.requires-verification, A009.drift, A009.application-failed, A009.verification-failed, A009.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A009. Ads: prohibited.

### A010 — Notifications
Purpose: Manage Notifications. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A010 in api-mappings.json; form fields none. States: A010.overview, A010.detail, A010.empty, A010.loading, A010.denied, A010.stale, A010.error, A010.offline, A010.confirmation, A010.processing, A010.completed, A010.conflict, A010.requires-verification, A010.drift, A010.application-failed, A010.verification-failed, A010.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A010. Ads: prohibited.

### A011 — Files
Purpose: Manage Files. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A011 in api-mappings.json; form fields none. States: A011.overview, A011.detail, A011.empty, A011.loading, A011.denied, A011.stale, A011.error, A011.offline, A011.requires-verification, A011.drift, A011.application-failed, A011.verification-failed, A011.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A011. Ads: prohibited.

### A012 — Jobs
Purpose: Manage Jobs. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A012 in api-mappings.json; form fields none. States: A012.overview, A012.detail, A012.empty, A012.loading, A012.denied, A012.stale, A012.error, A012.offline, A012.confirmation, A012.processing, A012.completed, A012.conflict, A012.requires-verification, A012.drift, A012.application-failed, A012.verification-failed, A012.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A012. Ads: prohibited.

### A013 — Backups
Purpose: Manage Backups. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A013 in api-mappings.json; form fields none. States: A013.overview, A013.detail, A013.empty, A013.loading, A013.denied, A013.stale, A013.error, A013.offline, A013.requires-verification, A013.drift, A013.application-failed, A013.verification-failed, A013.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A013. Ads: prohibited.

### A014 — Integrity
Purpose: Manage Integrity. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A014 in api-mappings.json; form fields none. States: A014.overview, A014.detail, A014.empty, A014.loading, A014.denied, A014.stale, A014.error, A014.offline, A014.confirmation, A014.processing, A014.completed, A014.conflict, A014.requires-verification, A014.drift, A014.application-failed, A014.verification-failed, A014.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A014. Ads: prohibited.

### A015 — Security
Purpose: Manage Security. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A015 in api-mappings.json; form fields none. States: A015.overview, A015.detail, A015.empty, A015.loading, A015.denied, A015.stale, A015.error, A015.offline, A015.requires-verification, A015.drift, A015.application-failed, A015.verification-failed, A015.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A015. Ads: prohibited.

### A016 — Audit
Purpose: Manage Audit. Entry: A001, A002, A003, A004, A005, A006, A007, A008, A009, A010, A011, A012, A013, A014, A015, A016, A017, A018, A019, A020, A021, A022, A023, authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A016 in api-mappings.json; form fields none. States: A016.overview, A016.detail, A016.empty, A016.loading, A016.denied, A016.stale, A016.error, A016.offline, A016.requires-verification, A016.drift, A016.application-failed, A016.verification-failed, A016.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A016. Ads: prohibited.

### A017 — Settings
Purpose: Manage Settings. Entry: A001, A002, A003, A004, A005, A006, A007, A008, A009, A010, A011, A012, A013, A014, A015, A016, A017, A018, authorized deep link. Primary action key: publish. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A017 in api-mappings.json; form fields none. States: A017.overview, A017.detail, A017.empty, A017.loading, A017.denied, A017.stale, A017.error, A017.offline, A017.draft, A017.validating, A017.validated, A017.impact-preview, A017.reauth-required, A017.publishing, A017.published, A017.version-conflict, A017.rollback, A017.requires-verification, A017.drift, A017.application-failed, A017.verification-failed, A017.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A017. Ads: prohibited.

### A018 — Recovery
Purpose: Manage Recovery. Entry: A019, A020, A021, A022, A023, authorized deep link. Primary action key: viewEvidence. Permission: Main Admin / Admin per permission; Moderator only assigned marketplace reports and urgent Telegram pause. Data: api.A018 in api-mappings.json; form fields none. States: A018.overview, A018.detail, A018.empty, A018.loading, A018.denied, A018.stale, A018.error, A018.offline, A018.confirmation, A018.processing, A018.completed, A018.conflict, A018.requires-verification, A018.drift, A018.application-failed, A018.verification-failed, A018.dependency-blocked. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A018. Ads: prohibited.

### A019 — Safe Mode
Purpose: Manage Safe Mode. Entry: authorized deep link. Primary action key: publish. Permission: Main Admin. Data: api.A019 in api-mappings.json; form fields none. States: A019.content, A019.draft, A019.validated, A019.impact-preview, A019.published, A019.applying, A019.applied, A019.verified, A019.application-failed, A019.verification-failed, A019.requires-verification, A019.drift, A019.dependency-blocked, A019.scheduled, A019.frozen, A019.version-conflict. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A019. Ads: prohibited.

### A020 — Monetization
Purpose: Manage Monetization. Entry: A023, authorized deep link. Primary action key: publish. Permission: Main Admin. Data: api.A020 in api-mappings.json; form fields none. States: A020.content, A020.draft, A020.validated, A020.impact-preview, A020.published, A020.applying, A020.applied, A020.verified, A020.application-failed, A020.verification-failed, A020.requires-verification, A020.drift, A020.dependency-blocked, A020.scheduled, A020.frozen, A020.version-conflict. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A020. Ads: prohibited.

### A021 — Maintenance
Purpose: Manage Maintenance. Entry: authorized deep link. Primary action key: publish. Permission: Main Admin. Data: api.A021 in api-mappings.json; form fields none. States: A021.content, A021.draft, A021.validated, A021.impact-preview, A021.published, A021.applying, A021.applied, A021.verified, A021.application-failed, A021.verification-failed, A021.requires-verification, A021.drift, A021.dependency-blocked, A021.scheduled, A021.frozen, A021.version-conflict. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A021. Ads: prohibited.

### A022 — Reports
Purpose: Manage Reports. Entry: authorized deep link. Primary action key: viewEvidence. Permission: Main Admin. Data: api.A022 in api-mappings.json; form fields none. States: A022.content, A022.draft, A022.validated, A022.impact-preview, A022.published, A022.applying, A022.applied, A022.verified, A022.application-failed, A022.verification-failed, A022.requires-verification, A022.drift, A022.dependency-blocked, A022.scheduled, A022.frozen, A022.version-conflict. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A022. Ads: prohibited.

### A023 — Sponsored Ads
Purpose: Manage Sponsored Ads. Entry: A020, authorized deep link. Primary action key: publish. Permission: Main Admin. Data: api.A023 in api-mappings.json; form fields none. States: A023.content, A023.draft, A023.validated, A023.impact-preview, A023.published, A023.applying, A023.applied, A023.verified, A023.application-failed, A023.verification-failed, A023.requires-verification, A023.drift, A023.dependency-blocked, A023.scheduled, A023.frozen, A023.version-conflict. Recovery: retain protected actor-scoped draft/context; reconcile unknown writes by request ID; 401 reauth without replay;403 safe parent;409 reload/reconfirm;422 inline+summary; timeout Retry read or check mutation status; S021 support. Test: SCREEN-A023. Ads: prohibited.
