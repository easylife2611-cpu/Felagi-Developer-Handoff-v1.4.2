# Flutter Starter Coverage

Implemented shared classes (preserved and corrected): FgButton, FgStatusBadge, FgCategoryChip, FgSectionHeader, FgNeedCard, FgEmptyState, FgOfflineBanner, FgTelegramPreview, FgTelegramDeliveryBadge, FgIconButton, FgTextField, FgSearchField, FgOfferSummaryCard, FgComparisonCriterionTile, FgErrorState, FgLoadingSkeleton, FgNavigationBar, FgConfirmationSheet.

Canonical native adaptations: FgSelect→DropdownButtonFormField; FgCheckbox→CheckboxListTile; FgRadioGroup/Rating→RadioListTile group; FgSwitch→SwitchListTile; Tabs→TabBar/TabBarView; Pagination→named previous/next buttons; Menu→PopupMenuButton; Tooltip→Tooltip; Toast→ScaffoldMessenger with persistent inline error; Progress→labelled progress; table→DataTable plus narrow cards. These are composition instructions, not a claim that custom wrappers already exist. Product-specific attachment/payment/message/rating screens must bind these defined patterns to guarded adapters. The full Component Library owns props/behavior and is complete; the code starter remains intentionally bounded.

No fromSeed synthesis; primary min56; colorScheme-resolved button colors; light/dark semantic borders; Noto configured; complete Telegram presentation enum; destructive confirmation; full registry accessible from Dart. Flutter compile/device evidence remains external.


Revision1.3 adds shared FgStatePanel, generated control schema and Offer Unlock policy/receipt adapter. Admin named composites remain design specifications built from shared primitives; a production Flutter Admin application is not included. All46 screen bindings are generated in fgScreens. Compile/device verification remains required.


Revision1.4 extends the existing criterion tile with optional localized weight/coverage/explanation/missing/risk fields and aliases FgComparisonCriterion to the same class. New generated comparison/criteria contracts are exported. Caller must pass Unknown as scoreLabel for missing evidence; never synthesize a number. Production report/secure draft adapters remain application implementation work.

Revision1.4 also adds FgSponsoredCard, one canonical text-only composition with card/banner/compact variant API; generated advertising contract/placement registry. Approved media and live serving/measurement are adapters, not implemented here.
