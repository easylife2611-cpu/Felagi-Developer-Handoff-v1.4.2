# Final Component Library Specification

**Revision:** FGM-PDS-1.3 / package 1.4.1. **Baseline lock:** Felagi demand-first marketplace; Amharic first with English launch support; product-owner supplied official logo master (canonical source included); navy/orange foundation; requester decision authority. DFM-FDS-1.4 business/security rules remain authoritative, with the explicit presentation integration decisions below. Design completeness is separate from production acceptance.

All controls accept localized strings and callbacks; no component owns authorization, payment truth or product transitions. All async operations accept explicit loading/error/status props and suppress duplicate mutation dispatch. Targets are minimum sizes and labels may wrap.

## FgButton

**Anatomy and variants:** label, optional icon; 48dp standard, 56dp primary; primary/secondary/tertiary/destructive

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** full width on crowded mobile; Enter/Space; loading prevents duplicate; states default/hover/focus/pressed/disabled/loading/success/error.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgTextLink

**Anatomy and variants:** label/destination/external marker

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** wraps; 48dp target; link semantics/focus.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgIconButton

**Anatomy and variants:** 48×48 box, 20–24 icon, required accessible name

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** tooltip desktop; focus/pressed/disabled/loading.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgTextField

**Anatomy and variants:** visible label, ≥56dp field, helper/error, required/read-only

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** placeholder never replaces label; validation linked; focus/read-only/disabled/error.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgSearchField

**Anatomy and variants:** search icon, query, clear, hint

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** debounced query, cancel stale request; loading/zero result semantics.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgSelect

**Anatomy and variants:** label/value/disclosure/options

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** mobile sheet, wide popover; arrows/type-ahead/Esc; empty/loading/error/selected.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgCheckbox

**Anatomy and variants:** 20dp mark, labelled ≥48dp row

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** Space toggles; selected/disabled/error.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgRadioGroup

**Anatomy and variants:** labelled options/value

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** arrows move, Space selects; group/error semantics.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgSwitch

**Anatomy and variants:** label + 40×24 visual; ≥48dp row

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** reversible preference only; switch state announced.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgChip

**Anatomy and variants:** text/optional count/remove

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** scrollable group, selected state announced.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgBadge

**Anatomy and variants:** label+optional icon+semantic tone

**Public props:** label/title/body, semantic tone, data source/time, optional named recovery callback. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** status text is mandatory; never color only.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgNeedCard

**Anatomy and variants:** title/category/status/budget/location/age/offer count/boost

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** 1/2/3 columns across widths; public projection only.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgOfferCard

**Anatomy and variants:** provider projection/price/proposal/delivery/status

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** selection explicit; no hidden ranking.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgComparisonCriterion

**Anatomy and variants:** criterion/weight/score/evidence/coverage/missing

**Public props:** label/title/body, semantic tone, data source/time, optional named recovery callback. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** mobile card; desktop matrix plus text alternative; UNKNOWN explicit.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgFilterBar

**Anatomy and variants:** query/chips/result count/reset

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** mobile opens sheet; filters removable and announced.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgTabs

**Anatomy and variants:** labels/selected marker

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** tab semantics/arrows; scroll if needed.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgNavigation

**Anatomy and variants:** 5 labelled items/unread count

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** bottom mobile, rail wide; create action is separate.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgListTable

**Anatomy and variants:** headers/rows/sort/loading/end

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** tables convert to cards narrow; header associations.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgPagination

**Anatomy and variants:** previous/current/next/load more

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** only server-supported count; announce new result range.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgDialog/Sheet

**Anatomy and variants:** title/summary/actions; 24dp sheet top radius

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** mobile bottom sheet, wide dialog; focus trap/return/Escape/back safe.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgMenu/Popover

**Anatomy and variants:** trigger/options

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** clamp viewport; keyboard arrows/Esc; return focus.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgTooltip

**Anatomy and variants:** concise help

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** not sole label; hover/focus desktop, tap mobile.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgAlert/Banner

**Anatomy and variants:** icon/title/body/action/dismiss

**Public props:** label/title/body, semantic tone, data source/time, optional named recovery callback. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** inline/top; appropriate live announcement.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgToast

**Anatomy and variants:** brief message/optional undo

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** safe area, 5s; persistent failure also inline.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgProgress/Skeleton

**Anatomy and variants:** labelled progress/content-shaped placeholders

**Public props:** label/title/body, semantic tone, data source/time, optional named recovery callback. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** preserve layout; no fake percentage; reduced motion.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgEmptyState

**Anatomy and variants:** illustration/title/reason/next action

**Public props:** label/title/body, semantic tone, data source/time, optional named recovery callback. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** distinguish empty from zero-result/unknown.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgErrorState

**Anatomy and variants:** human message/ref/retry/back

**Public props:** label/title/body, semantic tone, data source/time, optional named recovery callback. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** no stack trace; preserve data.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgAttachmentPicker

**Anatomy and variants:** add/list/type/size/progress/remove/retry

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** per-file states; only server-approved types.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgPublicPostPreview

**Anatomy and variants:** exact public text/destinations/consent

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** unchecked consent; stale preview must be reviewed again.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgTelegramDeliveryStatus

**Anatomy and variants:** destination/status/time/safe detail/stop

**Public props:** label/title/body, semantic tone, data source/time, optional named recovery callback. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** uncertain prominent; no blind retry or fake reach.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgPaymentStatus

**Anatomy and variants:** amount/currency/masked reference/state/next step

**Public props:** label/title/body, semantic tone, data source/time, optional named recovery callback. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** only server verifies payment.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgMessageComposer

**Anatomy and variants:** labelled multiline/limit/send

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** keyboard aware; failed outgoing stays marked unsent.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## FgRatingControl

**Anatomy and variants:** five labelled choices/optional text

**Public props:** localized label, value/selection, enabled, loading, error, helper, callback; stable ID and semantic label. Required business data is passed after projection; unknown values remain explicitly unknown.

**Behavior and semantics:** accessible radio group and verbal scale.

**Token binding:** text styles from `text.*`; surfaces/text/borders from `color.*`; targets from `size.minimumTouchTarget`; field/primary height from `component.input.height` / `component.button.primary.height`; spacing from `space.*`; shape from `radius.*`.

**Failure/recovery:** Invalid inputs keep values and link field error by ID. Network outcomes remain loading/unknown until adapter confirmation. A restricted component presents a readable reason, not a bypass. Passive status is politely announced only on change. Layout grows vertically at 200% text and below 360dp.

## Composition and implementation coverage
The HTML and Flutter starters demonstrate components, not complete production feature implementations. `Flutter_Coverage.md` lists exact implemented classes and canonical native adaptations. FgSelect uses platform-native select/dropdown semantics; tabs use roving focus; dialogs use platform focus scope/trap and restore the invoker. Stateful feature owners provide validation and asynchronous transitions. No undocumented feature component is required: all product-specific compositions use the library above and Pattern Library.

## Responsive and interaction details
Lists preserve stable row IDs and sort criteria. Chips/tabs scroll only within labelled groups, with every control reachable. Search debounce is 300ms, stale requests cancelled or ignored by sequence ID; Enter submits immediately. Pagination uses server cursor where returned, never inferred total counts. Toast is 5s for informational feedback, persistent parallel inline text for errors. Attachment control presents name/type/size/status, per-file retry/remove and server quarantine result; successful uploads are not resent. Conversation input Enter inserts newline; explicit Send activates submission; desktop Ctrl+Enter may submit after validation. Rating is a labelled 1–5 radio group; arrows move, Space chooses. Selects preserve unknown server values as validation errors rather than silently choosing first option.


## Admin semantic compositions

These are compositions/aliases of existing primitives, not duplicate implementations.

| Name | Reuse | Contract |
|---|---|---|
| AdminSettingRow | FgTextField + FgButton + FgStatePanel | label/current/observed/proposed/dependencies/version |
| AdminToggleControl | FgTextField boolean | labeled toggle, draft only |
| AdminNumericControl | FgTextField number | unit/range/error |
| AdminRiskBadge | FgStatusBadge | text+icon+semantic tone |
| AdminImpactSummary | FgStatePanel | effects/unaffected/pending evidence |
| AdminDependencyNotice | FgStatePanel + FgButton | invalid dependency and destination |
| AdminChangeDiff | semantic definition list | before/after/version |
| AdminVersionHistory | existing table/card pattern | actor/time/new rollback version |
| AdminHealthCard | FgStatePanel | status/impact/timestamp |
| AdminIncidentCard | AdminHealthCard composition | evidence/recommended action |
| AdminVerificationStatus | FgStatusBadge | desired/applied/verified distinction |
| AdminAuditEntry | existing table/card pattern | immutable actor/event/evidence |
| AdminRecoveryAction | FgButton + confirmation pattern | allowlisted action/evidence/impact |
| AdminScheduledChange | FgTextField date/time + diff | timezone/start/end/conflict/cancel |
| AdminBulkActionBar | FgButton + selection summary | scope/count/progress/partial |
| AdminPermissionNotice | FgStatePanel | reason/safe return; no hidden data |


## Comparison compositions1.4
FgComparisonCriterion is the canonical expanded contract of existing FgComparisonCriterionTile; reuse that implementation rather than adding a duplicate primitive. Inputs: criterion/name/weight/nullable score/status/evidence/coverage/missing/explanation/risk, all localized. Unknown has no numeric meter. FgProfessionalComparisonReport composes existing cards, criterion tile, badges, native disclosure, semantic table and text alternative. FgRequirementSummary and FgEligibilityList are report/form compositions, not separate evaluation stores. States: pending/failed no final score; completed known/unknown/conflict; provider projection never accepts sibling private fields.


## Integrated 1.4 contract
FgSponsoredCard is the canonical sponsored component: persistent localized disclosure, sponsor, title, optional approved media, body, neutral CTA, context disclosure. Inline Banner and Compact Tile are variants, not duplicate components. Use component.sponsoredSurface/Text/Border/Disclosure aliases. No score/rating/Need badge. Text wraps, media keeps approved ratio, native action and48dp targets. Flutter text-only implementation is provided; media/serving integrations remain adapters.
