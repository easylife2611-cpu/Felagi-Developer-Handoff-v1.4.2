# Felagi — Final Design System Foundation

**Revision:** FGM-PDS-1.3 / package 1.4.1. **Baseline lock:** Felagi demand-first marketplace; Amharic first with English launch support; product-owner supplied official logo master (canonical source included); navy/orange foundation; requester decision authority. DFM-FDS-1.4 business/security rules remain authoritative, with the explicit presentation integration decisions below. Design completeness is separate from production acceptance.

The original Amharic foundation remains in `FGM-DS-1.0.md`. This correction preserves brand primitives and adds missing implementation rules.

| Family | Canonical rule |
|---|---|
| Brand | Navy #003366; orange #FF9933; dark accents #6FA8FF/#FFAD5C. Logo B assets unchanged. Full lockup on welcome/auth, mark on Browse, back/title internally. |
| Surfaces | Light #F4F6F8 canvas/#FFFFFF card/raised; dark #121820/#1B2430/#263342. |
| Text | Noto Sans Ethiopic first; system Ethiopic fallback. Display32/40, page24/32, section18/26, body16/24, secondary14/20, label12/16. Font scaling never capped. |
| Control contrast | Essential border #738496 light/#8293A5 dark. Decorative #D8E0E7/#3A4858 never identifies a control. Primary orange uses navy boundary light; dark orange boundary dark. Ink on orange; white only on light navy/dark red. |
| Focus | At least 2dp semantic focus ring, clear offset, never clipped; HTML uses 3px. Dark ring uses #6FA8FF. |
| Space/shape | Full 0–64dp spacing scale; radii8/12/16/24/999; min48 targets, prominent/input min56. Minimum heights, not fixed text boxes. |
| Layout | Exact 360/600/840/1200/1600 breakpoints; mobile16/tablet24/desktop32 gutters; max1280 content,720 form,760 reading. |
| Icons | 16/20/24/32dp; accessible name for control, decorative icon excluded. No emoji or logo as sole action label. |
| Motion | 120/200/280ms; OS reduced motion disables nonessential motion. Loading has no fake percent. |
| Layer | Base0, sticky10, menu20, scrim30, sheet40, toast50, system60. System consent remains platform-owned. |
| Density | Comfortable16dp row padding default; compact12/spacious20 never reduce 48dp target. |
| Disabled | 0.48 opacity only for truly unavailable controls; nearby explanation remains readable; critical data never faded. |

## Token generation
The registry retains raw→primitive→semantic→component metadata and every family. `design_tokens.json` contains the entire registry plus a resolved path dictionary; no spacing, status, layout or opacity family is omitted. CSS is generated from semantic colors. Flutter `registry.dart` exposes the full resolved dictionary; ergonomic constants in `tokens.dart` are a documented subset, verified against registry values. Literal styling is confined to the design-system implementation, never feature code. Registry additions need reason, role, measured pairings and regression evidence.

## Component lifecycle
Every component declares props, semantics, applicable states, keyboard behavior and recovery in the Component Library and Component-State Matrix. A skeleton is not empty; a successful UI gesture is not server confirmation; warnings use text/icon as well as color. Fallback images preserve alt semantics and do not invent verification badges.


## Controlled generation and Admin
`Tools/generate_runtime.py` generates CSS token values, responsive CSS template, Flutter aliases/theme/full registry/control schema/locales and token documentation from canonical inputs. Templates own composition, never alternative palette truth. Admin consumes the same primitives/semantic colors. Risk uses status meaning + text + icon. New composites below reuse shared inputs/buttons/dialog/status panels; no duplicate primitives. Source mutation followed by generator and contract tests is required before handoff.


## Official master logo governance
User-provided official master is the authority; packaged assets are preserved byte-for-byte while source attestation remains required. Do not create competing concepts. Preserve search/F geometry and aspect ratio. Use supplied mark for small contexts, lockup for welcome; existing dark/light/mono variants only. Minimum mark24dp; lockup120dp wide with readable wording; below24 use text brand instead of deforming geometry. Clear space at least one-quarter mark height on all sides; app icon retains supplied square crop and keep mark within central80% safe area. No stretch, rotation, recolor, added effects, outline rewrite or cropping of master strokes. Test24/32/48dp rendered mark before approving small-size derivative. Logo gradient is brand expression; application colors remain semantic navy#003366/orange#FF9933 with audited accessible pairings. No new derivative is represented as approved without master match evidence.


## Quality baseline1.4
Preserve navy/orange/official-master governance; no decorative redesign. Motion purposes now live in token registry; shared typography/spacing/48–56dp controls remain. Hierarchy, continuity and trustworthy state language take priority over visual effects. Light/dark parity and reduced-effects behavior share one component system.


## Integrated 1.4 contract
Sponsored variants consume the existing token chain; no independent advertiser UI palette. Raw→primitive→semantic→component→rendered remains enforced. Motion and feedback remain restrained; ad effects are disabled. All generated artifacts originate in token_registry.json and canonical design registries.
