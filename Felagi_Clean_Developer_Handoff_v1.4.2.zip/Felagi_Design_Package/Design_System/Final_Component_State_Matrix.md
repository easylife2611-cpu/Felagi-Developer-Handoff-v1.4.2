# Final Component-State Matrix

D=default, H=hover, F=focus, P=pressed, S=selected, X=disabled, L=loading, E=error, R=read-only, V=permission restricted. N/A states are explicitly noninteractive, not missing designs.

| Component | Applicable states | N/A and reason | State behavior |
|---|---|---|---|
| FgButton | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgTextLink | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgIconButton | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgTextField | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgSearchField | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgSelect | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgCheckbox | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgRadioGroup | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgSwitch | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgChip | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgBadge | D,L,E,R,V | H/P/S: noninteractive unless a separate recovery control is present | Readable text + icon + tone; no focus on decoration |
| FgNeedCard | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgOfferCard | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgComparisonCriterion | D,L,E,R,V | H/P/S: noninteractive unless a separate recovery control is present | Readable text + icon + tone; no focus on decoration |
| FgFilterBar | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgTabs | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgNavigation | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgListTable | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgPagination | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgDialog/Sheet | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgMenu/Popover | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgTooltip | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgAlert/Banner | D,L,E,R,V | H/P/S: noninteractive unless a separate recovery control is present | Readable text + icon + tone; no focus on decoration |
| FgToast | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgProgress/Skeleton | D,L,E,R,V | H/P/S: noninteractive unless a separate recovery control is present | Readable text + icon + tone; no focus on decoration |
| FgEmptyState | D,L,E,R,V | H/P/S: noninteractive unless a separate recovery control is present | Readable text + icon + tone; no focus on decoration |
| FgErrorState | D,L,E,R,V | H/P/S: noninteractive unless a separate recovery control is present | Readable text + icon + tone; no focus on decoration |
| FgAttachmentPicker | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgPublicPostPreview | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgTelegramDeliveryStatus | D,L,E,R,V | H/P/S: noninteractive unless a separate recovery control is present | Readable text + icon + tone; no focus on decoration |
| FgPaymentStatus | D,L,E,R,V | H/P/S: noninteractive unless a separate recovery control is present | Readable text + icon + tone; no focus on decoration |
| FgMessageComposer | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |
| FgRatingControl | D,H,F,P,S,X,L,E,R,V | S applies only to selectable variants; R only when data remains inspectable | F ring; P feedback; X suppresses action + reason; L disables duplicates; E linked text; R no mutation; V no private data |


## Admin composition state applicability

| Composition | Applicable states | N/A |
|---|---|---|
| AdminSettingRow | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminToggleControl | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminNumericControl | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminRiskBadge | default/loading/unknown/denied/error/stale | rollback for irreversible operations/secrets |
| AdminImpactSummary | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminDependencyNotice | default/loading/unknown/denied/error/stale | rollback for irreversible operations/secrets |
| AdminChangeDiff | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminVersionHistory | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminHealthCard | default/loading/unknown/denied/error/stale | editing/publishing for read-only evidence |
| AdminIncidentCard | default/loading/unknown/denied/error/stale | rollback for irreversible operations/secrets |
| AdminVerificationStatus | default/loading/unknown/denied/error/stale | editing/publishing for read-only evidence |
| AdminAuditEntry | default/loading/unknown/denied/error/stale | editing/publishing for read-only evidence |
| AdminRecoveryAction | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminScheduledChange | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminBulkActionBar | default/editing/draft/validation/dependency-blocked/stale-version/published/applying/applied/verified/requires-verification/failed | rollback for irreversible operations/secrets |
| AdminPermissionNotice | default/loading/unknown/denied/error/stale | rollback for irreversible operations/secrets |


## Comparison state additions
Requirement summary: unambiguous/derived-unconfirmed/confirmed/stale; changed source invalidates confirmation. Eligibility list: included/excluded/ineligible/insufficient, reason always supplied. Criterion: observed/inferred/unknown/conflicting; unknown score=null underv2, legacy5 explicitly policy-neutral. Report: pending/processing/failed/completed with partial evidence; provider own projection; near-tie; immutable history. Final score unavailable until entire output validates.


## Integrated 1.4 contract
FgSponsoredCard variants CARD/BANNER/COMPACT: READY→labelled content; DISABLED/EMPTY/FAILED/EXPIRED/NOT_ELIGIBLE/FREQUENCY_CAPPED→omit safely; LOADING→no blocking spinner. Focused content must not disappear until focus is safely restored; every interactive child has hover/focus/pressed/disabled semantics. Same state meaning in light/dark/am/en.
