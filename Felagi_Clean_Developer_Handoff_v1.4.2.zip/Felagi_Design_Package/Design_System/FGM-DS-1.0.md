# ፈላጊ — የዲዛይን ስርዓት መሠረት

**መለያ:** FGM-DS-1.0 | **ሁኔታ:** ተቆልፏል | **የምርት ሥልጣን:** DFM-FDS-1.4 | **ዝርዝር የንድፍ ሥልጣን:** FGM-PDS-1.0

ፈላጊ ፍላጎት ያላቸውን ሰዎች ከአቅራቢዎች ጋር የሚያገናኝ የፍላጎት-ቀዳሚ የገበያ መድረክ ነው። የእይታ መርሆቹ ግልጽ፣ ደፋር፣ ፕሪሚየም እና ለመጠቀም ምቹ መሆን ናቸው። አማርኛ ቀዳሚ ነው፤ እንግሊዝኛ አማራጭ ነው።

## የተቆለፉ ውሳኔዎች

- Logo variant B፤ ሙሉ ሎጎ በመግቢያ/ብራንድ ገጽ፣ mark በBrowse አሞሌ/app icon፣ በውስጣዊ ገጽ መመለሻ+ርዕስ ብቻ።
- ዋና ሰማያዊ `#003366`; ዋና ማድመቂያ ብርቱካናማ `#FF9933`; ነጭ ጽሑፍ በብርቱካናማ ጀርባ አይጠቀም።
- ነባሪ ፊደል Noto Sans Ethiopic ከመሣሪያ fallback ጋር። 32/40 display, 24/32 page, 18/26 section, 16/24 body, 14/20 secondary, 12/16 short label.
- 4dp spacing scale፤ 16dp mobile gutter፤ 48dp minimum touch target፤ 56dp prominent button/input፤ radius 8/12/16/24/999dp።
- አምስት የታች አሰሳዎች፤ ፍላጎት መፍጠር የተለየ ዋና እርምጃ ነው።
- ሁኔታ በጽሑፍ+አይኮን+ቀለም ይገለጻል፤ ቀለም ብቻ አይደለም። AI ምክር ነው፤ ውሳኔ ባለቤቱ ያደርጋል።

## አንድ የቶከን ምንጭ

`tokens/token_registry.json` የraw→primitive→semantic→component ምንጭ ነው፤ እያንዳንዱ token እሴት፣ ዓላማ፣ የተፈቀደና የተከለከለ አጠቃቀም፣ theme mapping ይይዛል። `tokens/design_tokens.json` ለFlutter የተዘጋጀ ማዛመድ ነው። በfeature code ውስጥ inline visual value አይፈጠርም።

## የአሰሳ እና የማያ ገጽ ሕግ

Bottom navigation፦ ፍላጎቶች፣ የእኔ ፍላጎቶች፣ የእኔ አቅርቦቶች፣ ማሳወቂያዎች፣ መገለጫ። የማያ ገጽ፣ component፣ runtime state፣ interaction፣ responsive behavior፣ accessibility፣ privacy እና transition ሙሉ ውል `../Product_Design/FGM-PDS-1.0.md` ውስጥ ነው።

## ለውጥ

ይህን መሠረት የሚቀይር ለውጥ የስሪት ቁጥር፣ ምክንያት፣ የሚነኩ ክፍሎችና የሙከራ ማስረጃ ይፈልጋል። የምርት ውሳኔ በDFM ይመዝገብ፤ ይህ ሰነድ የንግድ ሕግን አይቀይርም።

## Revision 1.1 clarification

`Final_Design_System_Foundation.md` and FGM-TOKENS-1.1 reconcile essential control borders, complete mappings and theme focus. Brand primitives are unchanged. English resources are included at launch, with Amharic default.

## Revision 1.1 clarification

`Final_Design_System_Foundation.md` and FGM-TOKENS-1.1 reconcile essential control borders, complete mappings and theme focus. Brand primitives are unchanged. English resources are included at launch, with Amharic default.

## Revision 1.1 clarification

`Final_Design_System_Foundation.md` and FGM-TOKENS-1.1 reconcile essential control borders, complete mappings and theme focus. Brand primitives are unchanged. English resources are included at launch, with Amharic default.
