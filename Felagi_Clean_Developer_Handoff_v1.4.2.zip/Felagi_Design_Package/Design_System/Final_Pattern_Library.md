# Final Pattern Library

**Revision:** FGM-PDS-1.3 / package 1.4.1. **Baseline lock:** Felagi demand-first marketplace; Amharic first with English launch support; product-owner supplied official logo master (canonical source included); navy/orange foundation; requester decision authority. DFM-FDS-1.4 business/security rules remain authoritative, with the explicit presentation integration decisions below. Design completeness is separate from production acceptance.

| Pattern | Screens | Composition | Guard and recovery |
|---|---|---|---|
| Secure entry | S001/S002/S003 | Public explanation → Telegram system-browser handoff → exchange → own profile | Denied/expired starts fresh attempt; never phone OTP; return URI allowlist; cancelled auth restores welcome |
| Browse and discover | S004/S008/S009/S013 | Search/filter → authorized public cards → detail → contextual action | Empty versus no matches; preserve query/filter/scroll on return; role projection revalidated |
| Need publication | S005/S006/S007/S022 | Editable draft → uploads ready → exact public projection → consent → create → separate distribution state | Material changes invalidate consent; unknown create outcome reconciled before another POST; partial publication does not erase Need success |
| Offer submission | S008/S011/S012/S013 | Open Need → provider proposal → validate → submit → server PENDING | No owner Offer; duplicate/deadline conflict retains draft; edit invalidates no past comparison |
| Human decision | S010/S012/O01/O02/O03/O04/O07 | Inspect Offer → consequence confirmation → current-version mutation → server result | No AI/Admin impersonation; conflict requires fresh review; cancellation is safe before dispatch |
| Comparison | S014/O06/S015/S016 | Show four criteria and eligible set → explicit capped selection → snapshot → result → saved export | UNKNOWN/NO_HISTORY neutral policy scores labelled; partial evidence counts shown; failed retry uses same snapshot |
| Conversation | S017 | Authorized participant context → chronological thread → composer → sending → acknowledged message | Unknown delivery reconciled; offline stays draft; do not infer read/listened from sent |
| Payment | S019/O08 | Versioned package/price → consequence review → checkout → pending → verified server status | Return URI is not confirmation; mismatch remains review-required; no local activation |
| Completion/rating | S008/O04/S020 | Owner completes awarded Need → completed participants rate once | Not-completed/duplicate state explains eligibility; rating does not alter immutable comparison |
| Notifications and reports | S018/S021 | Recipient notification → mark read → reauthorize target; source-linked report → reference | Read failure rollback; invalid target safe unavailable; report preserves content on failure |
| Admin governed change | A004/A006/A009/A017/O09/O10 | Typed draft → schema/dependency validation → impact → reauth by risk → publish → health verify → new rollback version | No direct DB edit; 409 stale draft refreshes diff; secret references masked; second factor for HIGH/CRITICAL |
| Operations recovery | A002/A007/A012/A014/A018 | Inspect evidence → reasoned scoped action → confirmation → job/status → audit | Uncertain Telegram reconciled before resend; payments never manually set confirmed; safe mode retains callbacks/history |


## Governed operational patterns
Settings row → draft → dependency validation → impact diff → authenticated confirmation → published → applying → applied → verification evidence → audit. Error preserves proposal. Restore creates new version. Payment gate shows snapshot, reason, preserved draft and pending truth; retry resumes same intent. Safe Mode/freeze/preset/schedule/bulk operations use the canonical Admin contract, never hidden writes. Content edits preview both locales. Health cards show timestamp/coverage and user impact, no fabricated healthy default.


## Professional comparison + calm UX
Report order: identity/version → Need → executive summary → Offer overview → criterion detail → evidence/unknown → risks/trade-offs → requester decision → method. No podium/winner/confetti. Essential first, detail on demand. Preserve context/back/drafts/selection; stable skeleton geometry and honest refresh labels. Only local reversible view actions may be optimistic. Authoritative success offers a next step, errors explain preserved work and recovery. Motion consumes canonical purpose/duration/easing and respects reduced motion.


## Integrated 1.4 contract
Pattern: labelled nonblocking sponsored insertion. Core content first; preserve organic order, one page slot, deterministic caps. Pattern: no-code campaign wizard shares guarded Admin draft/validate/impact/publish/apply/verify/rollback. Pattern: progressive disclosure holds optional details but never hides fee, risk, missing evidence or sponsorship.
