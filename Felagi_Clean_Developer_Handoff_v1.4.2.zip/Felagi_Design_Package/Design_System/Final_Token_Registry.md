# Token Registry — generated reference

Canonical owner: `tokens/token_registry.json`. Never edit generated files.

| Token | Resolved value |
|---|---|
| border.defaultWidth | 1 |
| border.errorColor | color.status.error |
| border.focusColor | color.brand.primary |
| border.focusWidth | 2 |
| border.rule | focus must remain visible and un-clipped |
| breakpoint.compactMax | 359 |
| breakpoint.desktop | 1200-1599 |
| breakpoint.desktopMin | 1200 |
| breakpoint.laptop | 840-1199 |
| breakpoint.laptopMin | 840 |
| breakpoint.mobile | 360-599 |
| breakpoint.mobileMax | 599 |
| breakpoint.stickyMinHeight | 700 |
| breakpoint.tablet | 600-839 |
| breakpoint.tabletMin | 600 |
| breakpoint.wideMin | 1600 |
| color.border.action | #003366 |
| color.border.action.dark | #FFAD5C |
| color.border.decorative | #D8E0E7 |
| color.border.decorative.dark | #3A4858 |
| color.border.default | #738496 |
| color.border.default.dark | #8293A5 |
| color.border.focus | #003366 |
| color.border.focus.dark | #6FA8FF |
| color.brand.accent | #FF9933 |
| color.brand.accent.dark | #FFAD5C |
| color.brand.primary | #003366 |
| color.brand.primary.dark | #6FA8FF |
| color.primitive.border.action | #003366 |
| color.primitive.border.action.dark | #FFAD5C |
| color.primitive.border.decorative | #D8E0E7 |
| color.primitive.border.decorative.dark | #3A4858 |
| color.primitive.border.focus | #003366 |
| color.primitive.border.focus.dark | #6FA8FF |
| color.primitive.brand.navy.400 | #6FA8FF |
| color.primitive.brand.navy.900 | #003366 |
| color.primitive.brand.orange.400 | #FFAD5C |
| color.primitive.brand.orange.500 | #FF9933 |
| color.primitive.neutral.border.dark | #8293A5 |
| color.primitive.neutral.canvas.dark | #121820 |
| color.primitive.neutral.card.dark | #1B2430 |
| color.primitive.neutral.ink | #192431 |
| color.primitive.neutral.line | #738496 |
| color.primitive.neutral.muted | #586675 |
| color.primitive.neutral.muted.dark | #C2CBD5 |
| color.primitive.neutral.paper | #F4F6F8 |
| color.primitive.neutral.raised.dark | #263342 |
| color.primitive.neutral.text.dark | #F7F9FC |
| color.primitive.neutral.white | #FFFFFF |
| color.primitive.overlay.scrim | rgba(16,24,32,.40) |
| color.primitive.status.error | #B42335 |
| color.primitive.status.error.dark | #FF7A86 |
| color.primitive.status.info | #155EEF |
| color.primitive.status.info.dark | #84ADFF |
| color.primitive.status.success | #176B35 |
| color.primitive.status.success.dark | #65D58A |
| color.primitive.status.warning | #8A4B00 |
| color.primitive.status.warning.dark | #FFD166 |
| color.primitive.surface.raised | #FFFFFF |
| color.primitive.text.onAccent | #192431 |
| color.primitive.text.onAccent.dark | #192431 |
| color.primitive.text.onBrand | #FFFFFF |
| color.primitive.text.onBrand.dark | #192431 |
| color.primitive.text.onError | #FFFFFF |
| color.primitive.text.onError.dark | #192431 |
| color.status.error | #B42335 |
| color.status.error.dark | #FF7A86 |
| color.status.info | #155EEF |
| color.status.info.dark | #84ADFF |
| color.status.success | #176B35 |
| color.status.success.dark | #65D58A |
| color.status.warning | #8A4B00 |
| color.status.warning.dark | #FFD166 |
| color.surface.canvas | #F4F6F8 |
| color.surface.canvas.dark | #121820 |
| color.surface.card | #FFFFFF |
| color.surface.card.dark | #1B2430 |
| color.surface.raised | #FFFFFF |
| color.surface.raised.dark | #263342 |
| color.surface.scrim | rgba(16,24,32,.40) |
| color.text.onAccent | #192431 |
| color.text.onAccent.dark | #192431 |
| color.text.onBrand | #FFFFFF |
| color.text.onBrand.dark | #192431 |
| color.text.onError | #FFFFFF |
| color.text.onError.dark | #192431 |
| color.text.primary | #192431 |
| color.text.primary.dark | #F7F9FC |
| color.text.secondary | #586675 |
| color.text.secondary.dark | #C2CBD5 |
| component.button.primary.background | #FF9933 |
| component.button.primary.border | #003366 |
| component.button.primary.foreground | #192431 |
| component.button.primary.height | 56 |
| component.button.secondary.border | #003366 |
| component.card.need.background | #FFFFFF |
| component.card.need.border | #738496 |
| component.card.need.radius | 16 |
| component.comparison.score | #192431 |
| component.comparison.unknown | #586675 |
| component.input.border | #738496 |
| component.input.focus | #003366 |
| component.input.height | 56 |
| component.navigation.selected | #003366 |
| component.navigation.target | 48 |
| component.sheet.background | #FFFFFF |
| component.sponsoredBorder | #738496 |
| component.sponsoredDisclosure | #586675 |
| component.sponsoredSurface | #FFFFFF |
| component.sponsoredText | #192431 |
| component.telegram.uncertain | #8A4B00 |
| default_locale | am |
| density.comfortable.default | True |
| density.comfortable.rowPadding | 16 |
| density.compact.minTarget | 48 |
| density.compact.rowPadding | 12 |
| density.spacious.minTarget | 48 |
| density.spacious.rowPadding | 20 |
| font.family | Noto Sans Ethiopic |
| icon.hero | 32 |
| icon.large | 24 |
| icon.medium | 20 |
| icon.rule | Label interactive icons; decorative icons hidden from semantics |
| icon.small | 16 |
| layer.base | 0 |
| layer.menu | 20 |
| layer.scrim | 30 |
| layer.sheet | 40 |
| layer.sticky | 10 |
| layer.system | 60 |
| layer.toast | 50 |
| layout.appBarMinHeight | 64 |
| layout.authMaxWidth | 440 |
| layout.brandLockupWidth | 180 |
| layout.brandMarkSize | 40 |
| layout.cardMaxWidth | 420 |
| layout.dialogMaxWidth | 560 |
| layout.formMaxWidth | 720 |
| layout.gridGutter.mobile | 16 |
| layout.gridGutter.wide | 24 |
| layout.navRailWidth | 88 |
| layout.pageGutter.desktop | 32 |
| layout.pageGutter.mobile | 16 |
| layout.pageGutter.tablet | 24 |
| layout.pageMaxWidth | 1280 |
| layout.readingMaxWidth | 760 |
| layout.sidebarWidth | 256 |
| layout.stickyActionInset | 16 |
| motion.duration.fast | 120 |
| motion.duration.slow | 280 |
| motion.duration.standard | 200 |
| motion.easing | cubic-bezier(.2,0,0,1) |
| motion.purpose.error | no bounce/shake |
| motion.purpose.navigation | subtle fade; no animation while restoring scroll |
| motion.purpose.reduced | zero animation, same functionality |
| motion.purpose.sheet | rise only when motion allowed |
| motion.purpose.success | one soft fade on authoritative success |
| motion.reduced | 0ms transition, no parallax |
| opacity.decorative | 0.08 |
| opacity.disabled | 0.48 |
| opacity.rule | never fade critical text |
| opacity.scrim | 0.4 |
| policy.contrast | WCAG 2.2 AA target; evidence required |
| policy.dark_theme | system or user preference |
| policy.no_arbitrary_visual_values | True |
| policy.raw_to_primitive_to_semantic_to_component | True |
| policy.reduced_motion | respect OS setting |
| policy.semantic_tokens_only_in_feature_code | True |
| productStatus.rule | Each status maps to semantic tone + icon + Amharic label. No color-only communication. |
| radius.card | 16 |
| radius.control | 12 |
| radius.pill | 999 |
| radius.sheet | 24 |
| radius.small | 8 |
| revision_reason | Audit H01-H05 and C03; brand primitives unchanged |
| shadow.rule | never sole state cue |
| shadow.shadow.0 | none |
| shadow.shadow.1 | 0 1px 3px rgba(16,32,48,.08) |
| shadow.shadow.2 | 0 8px 24px rgba(16,32,48,.12) |
| size.actionBasis | 160 |
| size.adminDetailMinimumWidth | 280 |
| size.controlCompact | 40 |
| size.controlProminent | 56 |
| size.controlStandard | 48 |
| size.iconHero | 32 |
| size.iconLarge | 24 |
| size.iconMedium | 20 |
| size.iconSmall | 16 |
| size.inputMinimumHeight | 56 |
| size.minimumTouchTarget | 48 |
| size.navigationItemBasis | 100 |
| size.previewControlMinWidth | 180 |
| size.progressStroke | 2 |
| size.skeletonLine | 14 |
| size.skeletonShort | 132 |
| size.skipOffscreen | -100 |
| size.textareaMinimumHeight | 120 |
| size.visuallyHidden | 1 |
| space.0 | 0 |
| space.1 | 4 |
| space.10 | 40 |
| space.12 | 48 |
| space.16 | 64 |
| space.2 | 8 |
| space.3 | 12 |
| space.4 | 16 |
| space.6 | 24 |
| space.8 | 32 |
| spec_id | FGM-TOKENS-1.4 |
| status | locked |
| text.body.primary.line_height_dp | 24 |
| text.body.primary.purpose | main reading |
| text.body.primary.size_dp | 16 |
| text.body.primary.weight | 400 |
| text.body.secondary.line_height_dp | 20 |
| text.body.secondary.purpose | supporting text |
| text.body.secondary.size_dp | 14 |
| text.body.secondary.weight | 400 |
| text.display.family | Noto Sans Ethiopic; system Ethiopic sans-serif fallback |
| text.display.line_height_dp | 40 |
| text.display.purpose | rare welcome/success heading |
| text.display.size_dp | 32 |
| text.display.weight | 700 |
| text.heading.page.line_height_dp | 32 |
| text.heading.page.purpose | page title |
| text.heading.page.size_dp | 24 |
| text.heading.page.weight | 700 |
| text.heading.section.line_height_dp | 26 |
| text.heading.section.purpose | section/card title |
| text.heading.section.size_dp | 18 |
| text.heading.section.weight | 600 |
| text.label.line_height_dp | 16 |
| text.label.prohibited | long instruction or error |
| text.label.purpose | short field/status label |
| text.label.size_dp | 12 |
| text.label.weight | 500 |
| unit | dp unless stated |
| version | FGM-TOKENS-1.4 |
