# Felagi — clean developer handoff package 1.4.2

**Design-source acceptance: PASS. Developer handoff: READY. Production release: NOT YET VERIFIED.** This ZIP contains the integrated design artifacts, canonical registries, interactive HTML reference, Flutter starter, bilingual localization, tests and preserved audit/provenance—not merely an addendum. Existing `Final_*` filenames identify requested deliverables, not production certification.

Developer: start with `Developer_Handoff/START_HERE.md`, then `DELIVERABLE_INDEX.json`, `Product_Design/Final_Master_Product_Design_Specification.md`, `Developer_Handoff/Release_Gates_and_Evidence.md` and `Audit/Final_Acceptance_Report.md`.

The **clean-handoff release is v1.4.2**; the underlying corrected canonical design-contract registries remain **v1.4.1**. v1.4.2 changes handoff/status documentation only and does not redesign product behavior.

46 canonical screens:23 user and23 Admin.55 governed controls.3 centrally registered sponsored placements (master/placements default OFF). Need-first flow, requester decision, advisory AI, navy/orange, no percentage commission and the product-owner supplied official brand master is canonical. Revenue domains: Need Boosting, Offer Submission Unlock and labelled Sponsored Advertising; sponsorship never changes organic rank or AI scores.

Open `UI_Handoff/ui-preview/index.html` offline. It uses fictional data and no live payment/AI/Telegram/ads service. Role switches do not implement authorization. Protected durable drafts and live integrations are application adapters, not falsely simulated receipts. Flutter is a bounded shared-component starter, not the complete production application.

One visual source: `Design_System/tokens/token_registry.json`. One screen source: `Design_Data/screen-manifest.json`. One static-copy source: `Localization/app_*.arb`. Generator and checks are in Tools; the acceptance report lists exact commands/results. Do not edit generated derivatives.

All prior ZIPs/audits are retained under Provenance/Audit. They are historical, not competing active authorities. Current design sources are reconciled for the v1.4.2 clean-handoff batch. The product-owner supplied official logo is included as the canonical master; Amharic terminology and action semantics were corrected at source and regenerated. Browser/device/AT, Flutter compilation, runtime font/rendering, live services and activation-governance gates remain REQUIRES EVIDENCE. No production-readiness claim is made.
