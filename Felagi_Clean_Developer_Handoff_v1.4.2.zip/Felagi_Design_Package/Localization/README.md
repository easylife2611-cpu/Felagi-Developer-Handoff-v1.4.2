# Final Localization Package

Amharic `am` is default; English `en` is required at launch. Canonical ARB files contain every delivered preview/starter label, field, action, state and Admin column. Generated JSON and Dart maps are derivatives; edit ARB then run the generator. Keys must match exactly; no inline production UI copy. User records and server codes are data, not translation keys. Escape plain text; never render untrusted HTML from translations/records.

Fallback: chosen locale→Amharic for an unexpected missing key, log missing key without private content; the package verifier rejects missing keys before delivery. Unsupported locale→Amharic. Locale changes preserve route/form state and clear no consent unless content itself materially changes. Amharic is LTR; mixed IDs/URLs use bdi/dir=auto. Root language matches all fixed chrome. Dates use user timezone (initial deployment Africa/Addis_Ababa) and explicit locale; API timestamps remain UTC/offset ISO8601. Currency uses server code and decimal string, two decimals for ETB unless server specifies currency precision; never convert currency silently.

Counts use number+localized noun labels in delivered fixtures; future sentence plurals must be ARB ICU plural with explicit metadata and matching placeholders, never English string concatenation. No placeholder-bearing ARB messages currently exist. Required field length cues are schema-derived numeric data. Long words wrap; essential labels never ellipsize. Terminology retains Need=ፍላጎት, Offer=አቅርቦት, Provider=አቅራቢ, requester decision and Telegram evidence semantics.

Font: preferred Noto Sans Ethiopic is configured in CSS/Flutter. A font binary is not bundled; host device fallback is permitted by the locked baseline. Production build must package licensed glyph coverage or verify system fallback on supported devices. This is a release evidence requirement, not a discretionary typography choice. Linguistic review of translations on real devices remains required.


## Microcopy constitution
Canonical glossary.json binds Need/Offer/Submit/Unlock/Boost/Compare/Pending/Unknown/Payment verified to am/en keys. ARB owns actual strings; consumers fail explicitly on missing translation. Unknown/pending/failed/verified are different concepts. No ad-hoc English fallbacks. Primary language Amharic; both launch locales required. Human linguistic review and device glyph/200% layout review remain external evidence. Edge-case corpus lives in Design_Data/edge-cases.json.


## Comparison and trust copy1.4
New canonical keys cover overall score, evidence coverage, requirement match, strengths/weaknesses/missing/risk/version/close result, requester/provider notices and safe failure. Model-generated narratives are content under validated locale/output contract; UI headings/actions remain ARB. AI must not translate UNKNOWN into negative evidence. Both locales require human QA. Sample exclusion machine reason must map to localized text before production display.


## Integrated 1.4 contract
Sponsored copy is canonical ARB: sponsored, advertisement, sponsorName, adDisclosure, adContextOnly, externalDestination, campaign/slot states, placement labels and wizard errors. Advertiser copy is bilingual validated content, never arbitrary HTML; canonical glossary terms remain unchanged. Linguistic/device evidence is still required.
