# Release gates and evidence — 1.4.2 clean handoff

## Acceptance is scoped
DESIGN SPECIFIED ≠ REFERENCE IMPLEMENTED ≠ PRODUCTION IMPLEMENTED ≠ VERIFIED. The names `Final_*` are retained deliverable filenames, not a release certification. A source check closes only the defect it actually examines. Every unexecuted manual test is REQUIRES_EVIDENCE, never PASS. Coverage mapping means a requirement has an owner, not that its runtime behavior has passed.

Design handoff and production release are separate gates. No identified fixable BLOCKER/CRITICAL ambiguity may remain before design acceptance. HIGH items must have a correction or explicit justification and owner. Runtime evidence cannot be manufactured by changing a document. The product-owner supplied official master logo is included and is the canonical brand authority. Source-level brand fidelity is closed by exact packaged derivatives and semantic verification; runtime/device rendering remains part of the browser/Flutter evidence gates.

## Canonical owners / dependency map

| Concern | Canonical owner | Consumers |
|---|---|---|
| Product identity, revenue, scope | Master Product Design Specification | All artifacts |
| Visual values and themes | token_registry.json | generated CSS, Flutter, token docs |
| Screen/route/state/API binding | screen-manifest.json | routes, preview data, Flutter registry, matrices |
| Static microcopy | Localization ARB + glossary | generated JSON and Flutter ARB |
| Payment/unlock/recovery | Monetization_Payment_Specification.md | S011/S023, Admin, adapter tests |
| AI evidence/snapshot/projection | AI_Evaluation_Contract.md + criteria registry | S014–S016/S018,A006, exports/notifications |
| Permission/risk/reauth/audit | Admin_Authorization_Contract.md + control registry | all Admin endpoints and UI |
| Ads/privacy/placement/evidence | Sponsored_Advertising_Contract.md | S004/S008,A023, serving/analytics |
| Telegram consent/delivery | Design_Integration_Contract.md and DFM publication model | S006/S007/S022,Admin delivery/recovery |
| UX continuity/drafts/motion | Final_Interaction_Contract.md + ux-quality.json | every screen and native adapter |
| Recovery and release evidence | this document + Error/Recovery Matrix | developer/QA/release owner |

No new source of truth may be introduced by copying these rules into independent code constants. Generated files are regenerated and checked for byte stability. Operational values must come from approved versioned configuration, not guessed source defaults. Initial OFF/zero monetization defaults apply only to a known new installation, not a failed configuration read.

## Security / privacy / permission contract
Read permissions and write capabilities are independently checked server-side on every request, including aliases, exports, event ingestion and deep links. Denial renders no restricted data. Reauth expiry preserves draft but never replays an action. Token expiry/revocation clears private cached views, keeps protected actor-scoped drafts inaccessible until the same actor authenticates, and returns to the safe parent. Logout discards in-memory sensitive values and offers explicit protected-draft disposition. No Admin secret is returned to browser/analytics/audit logs.

Requesters receive their complete authorized comparison; providers receive only their own Offer projection from the same immutable comparison version; other providers receive403. Telegram/export/notifications use the same server projection. Client role switches are demonstrations, not access control. Public Need projection excludes private contact and attachment data unless explicitly approved by the canonical consent flow. A revoked public publication does not imply remote deletion was successful.

Draft storage contains only editable business fields and resumable-upload references. Use OS-protected storage in native applications and an authenticated server draft service for cross-device recovery; browser sensitive drafts must not be plaintext localStorage. Autosave after500ms idle, flush on safe navigation/background, report LOCAL_SAVED/SERVER_SAVED only after acknowledgement. Conflict compares versions with explicit keep-local/use-server decision. Payment credentials, authentication tokens and Admin secrets are never draft fields. Draft retention defaults30 days since last edit with an expiry warning7 days before removal; verified submitted drafts may be cleared after24 hours only when the corresponding server record is retrievable. The implementation must expose retention metadata and deletion capability; unavailable protected storage yields explicit unsaved warning, never a false Saved label. These are design requirements, not a claim storage exists in the preview.

Analytics never collect message bodies, private attachments, payment credentials, secrets or full comparison narrative. Record event name, scoped pseudonymous actor/session reference, screen ID, request ID, observed time and outcome. Ads-specific retention and targeting limits are separately defined by its owner. Access to support/report evidence requires case-scoped permission. Export requires authorization at generation and download; expiring signed links are not public share URLs. A permission change invalidates outstanding access where the serving platform supports it and is tested before launch.

## Performance and UX acceptance targets (not measured results)

| Target | Budget | Evidence |
|---|---|---|
| Press/local reversible feedback | next frame; p95≤100ms | device interaction trace |
| Wait feedback | within100ms if task not completed | recording + trace |
| Warm cached navigation | p95≤300ms to retained authorized view | low-end device trace |
| Cold usable core screen | p75≤2.5s on agreed constrained profile | run log with network/device specs |
| Layout stability | cumulative shift≤0.1; no focus/action jumps | browser performance trace |
| Ad serving | core first;800ms slot budget then omit | delayed/failing service test |
| Draft feedback |500ms idle autosave; actual ack truth | crash/offline/auth-expiry test |
| Orientation | location/state/next action understood in≤3s | task-based usability evidence |

Performance profiles must record device CPU/RAM/OS, viewport, text scale, locale, theme, cold/warm state, network latency/bandwidth and sample size. No unrecorded “fast” claim. Low-end mode disables blur/shimmer/transforms; functionality, content, security and feedback remain unchanged. Safe optimism is limited to local filters/selection/disclosure/draft edits. Never show payment verified, Offer accepted or AI complete speculatively. Loading keeps stable skeleton and truthful accessible status; stale cache shows age and does not enable authority-sensitive mutations.

## Test protocol
Run each screen at320,359,360,599,600,839,840,1199,1200,1599,1600 CSS px; both themes/locales; normal and200% text;400% zoom; portrait/landscape, keyboard open and safe areas. Check no clipped Amharic glyphs, essential ellipses, horizontal page overflow, overlapping focus/CTA, accidental adjacent taps or color-only status. Comparison tables become labelled cards; sponsorship stays disclosed. Include0/1/50 Offers, huge ETB, no budget, long category/title/error, mixed scripts, expired deadline, absent provider history, offline draft, denied permission, payment pending and Telegram uncertain.

Keyboard and TalkBack/VoiceOver: correct landmarks/headings/names, logical focus order, native controls, safe dialogs, Escape/platform Back, error summary/field association, status announcements, reduced motion,200% text. Contrast report covers specified token pairs, not every possible advertiser image or system overlay. Test text-on-media only if a future approved component introduces it; current ads keep copy outside media.

Backend integration: duplicate/concurrent submission and verified-payment replay; policy change after quoted intent; expired/deleted Need after payment; resume without second charge; receipt mismatch/reversal/refund; unauthorized endpoint/alias/export; role revoke and reauth; AI malformed/invented output/unknown evidence/version consistency/own-result privacy; one result event per participant; Telegram uncertain never success; Admin stale draft/impact mutation/publish/apply/verify/rollback; ads master/placement/campaign OFF, expired/revoked creative, private targeting rejection, SSRF/redirect/media scan, caps concurrency, analytic deduplication and service isolation.

## Explicit release gates

| Gate | Pass condition | Owner / current boundary |
|---|---|---|
| G01 Source consistency | no unresolved references, generated drift, missing locale/state/route; reference tests green | package maintainer; automated report |
| G02 Design completeness | actual file review; no unresolved BLOCKER/CRITICAL; HIGH disposition justified | design owner; source audit |
| G03 Brand source | official product-owner master included; approved package derivatives match the canonical master | design/product owner; **MET at design source** |
| G04 Browser/responsive/AT | recorded matrix including Amharic/scaling/focus | frontend QA; REQUIRES_EVIDENCE |
| G05 Flutter | analyze/test/build plus device glyph/layout/accessibility | Flutter team; REQUIRES_EVIDENCE |
| G06 Service/security | server-authoritative guards, idempotency, projections, scans verified | backend/security QA; REQUIRES_EVIDENCE |
| G07 Monetization health | baseline time-to-first-Offer, Offers/Need, qualified Offers, submit conversion, accepted-Offer conversion, completion, repeats; approved deterioration thresholds and rollback | product operations; REQUIRES_EVIDENCE; paid activation blocked |
| G08 Localization/usability | canonical Amharic terminology/action voice corrected and generated parity verified; runtime glyph rendering and orientation/continuity tasks recorded | source portion **MET**; language/UX runtime evidence **REQUIRES_EVIDENCE** |
| G09 Observability | correlated safe request/audit IDs, UNKNOWN/partial reporting, rollback probe | operations; REQUIRES_EVIDENCE |

Evidence record: test ID, requirement IDs, commit/package hash, build/version, executor/date, environment, input, expected, actual, status, attachment hashes, limitations. A failure is retained, linked to a remediation and rerun; it is never erased by replacing an acceptance report. External evidence can close its own gate only. **Developer implementation may begin after design-source gates are satisfied; production release requires all applicable runtime gates, not just G01–G03.**

## Handoff implementation boundaries
HTML is an offline design reference. It does not implement durable protected storage, real server authorization, live payment/AI/Telegram/ad serving, media scanning or analytics instrumentation. Flutter is a shared component/token starter, not a complete production application or no-code Admin backend. Build the application from the canonical contracts, then attach implementation evidence. No mock success is a production receipt.


## Developer start condition
The v1.4.2 package is the locked implementation baseline. Development may begin without reopening product design. Any implementation-discovered contradiction must be logged against the canonical requirement owner rather than silently redesigning the behavior. Production PASS is granted only after the applicable runtime gates above are evidenced.
