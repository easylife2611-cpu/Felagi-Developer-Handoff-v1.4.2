# Final Developer Handoff Specification

## Start here
Read `Product_Design/Final_Master_Product_Design_Specification.md`, then canonical `Design_Data/*`. Preserve the locked Felagi identity and DFM business invariants. The original documents remain amended for continuity; final matrices and registries settle presentation shorthand. Prior audits are historical evidence. No Figma or external design service is required to consume this package.

## Build boundaries
- Flutter implements23 mobile screens using canonical IDs/paths/aliases; S003 profile/setup shares form, S005 and S011 create/edit share guarded components.
- Admin implements23 separate privileged browser surfaces. No Admin impersonation or unguarded settings setter.
- Backend implements DFM plus Design Integration Contract. UI flags never authorize an endpoint or change evidence truth.
- Shared design system owns tokens/components; feature modules consume them. Locale ARB owns static copy; adapter maps server errors to known keys plus safe request refs. Unknown server code uses safe generic error and does not invent missing data.

## Deterministic generation
Run `python3 Tools/generate_runtime.py`, then `python3 Tools/verify_package.py` from the extracted package (Python3; Node for JS syntax). The generator builds full token mapping, CSS, preview data and Dart registry/locales. Never hand-edit generated copies. `Design_Data/routes.json` is checked against screen-manifest. Tokens/strings/screen IDs must resolve before accepting a merge.

Open `UI_Handoff/ui-preview/index.html`; it works offline without a build or account. It is an interactive fixture with all46 screen selections, canonical business/runtime states, locales/themes/roles, form validation, safe confirmations and Admin flow demonstrations. Live API/Telegram/payment behavior is deliberately represented as simulated and never asserted as verified. Follow HTML README for coverage boundaries.

Flutter starter README contains exact commands. Component code is bounded shared implementation, not all product screens. `Flutter_Coverage.md` identifies native compositions for the complete component specification. Implement feature screens from the screen contracts, not by guessing from the starter example.

## Adapter boundary / no invented success
All reads return `{data, observed_at, source, version, request_id}` plus paging when applicable. Empty is only a confirmed empty result. Local validation is advisory; server field errors authoritative. Mutations accept idempotency and If-Match when required. Record unknown outcomes and reconcile; do not blindly retry sensitive writes. Package fixtures are not backend schemas or real user data.

## Acceptance execution
1. Run packaged static verifier and JS syntax; inspect new evidence outputs.
2. Run Flutter pub get/analyze/test and example on supported Android/iOS; record exact SDK/device build.
3. Run preview/device viewport matrix at320/359/360/599/600/839/840/1199/1200/1599/1600, both locales/themes; text200%, zoom400%, long Amharic, keyboard and OS safe area.
4. Exercise J01–J16 happy/denied/offline/conflict/timeout; attach expected/actual and screenshot/reference. TalkBack/VoiceOver/keyboard must confirm names/order/focus/status.
5. Backend integration gate: API projection, consent/hash mismatch, idempotency, role revoke, reauth/2FA, payment/provider verification, Telegram uncertainty/removal and immutable comparison snapshot.
6. Close external evidence rows only with artifacts. A passing static package does not release a production application.

## Traceability and change control
Every change states requirement→journey→screen→route→component→token→state→action→permission→API→error/recovery→locale→test. Canonical owners: DFM business; PDS presentation; token registry visual values; ARB static copy. Add version, reason and affected artifacts together. Baseline changes require explicit review; corrections may not weaken guards or remove capabilities.

## Handoff acceptance scope
All fixable audit findings must be closed with file-level evidence; high-risk code limitations explicitly justified. External device/compiler/live provider evidence remains separate and blocks production acceptance. No unimplemented API is presented as deployed. No unresolved design choice is delegated as “optional”; host-specific operational limits come from measured deployment configuration with fail-closed UI until known.


## Locked 1.3 integration
Implement Main Admin as a core no-code product control plane, not an unrestricted developer console. Canonical owners are listed in Master PDS. Consume generated controls/screen/API/localization/token registries; no hand-maintained route aliases or independent palette. Runtime fee truth and server receipt belong to Monetization_Payment_Specification.md; authorization belongs to Admin_Authorization_Contract.md. All legacy Offer-create entrypoints delegate to the guarded submission service. No client/provider callback directly writes confirmed payment.
Run `python3 Tools/generate_runtime.py`, `python3 Tools/verify_semantics.py`, `python3 Tools/verify_package.py`, `node Tools/policy_tests.js`, `node Tools/comparison_tests.js`, `node Tools/ads_tests.js`, `node Tools/preview_logic_probe.js`, `python3 Tools/verify_foundation.py`, `python3 Tools/verify_ai_ux.py`, and `python3 Tools/verify_completion.py`. Generated files must be byte-stable on a second run. Preview is design reference, Flutter is bounded starter, neither proves deployed backend behavior. Provision actual approved catalogs, provider integration bounds, liquidity thresholds and recorded browser/device/accessibility evidence before launch acceptance. The official product-owner master logo is already included and closed at design source; only runtime rendering remains to be evidenced. No ordinary configuration needs code once these typed capabilities are implemented.


## Evaluation/UX handoff1.4
Read canonical AI_Evaluation_Contract.md, criteria-registry.json, comparison-contract.json and ux-quality.json. Server owns snapshot/result/projection/fan-out; UI receives authorized fields only. Preview projection logic is demonstrative, never authorization. New v2 excludes UNKNOWN scores from observed aggregate and shows coverage; v1 immutable neutral contributions remain labelled. Same-version retries preserve versions; export never reruns AI. Durable drafts require protected storage adapters and actor-scoped recovery; tab-memory preview is not production durability. Execute AI acceptance matrix including adversarial output/privacy, event uniqueness, timeout/retry and delivery independence. Real provider/device evidence remains required.


## Integrated 1.4 contract
Advertising domain is specified in System_Specification/Sponsored_Advertising_Contract.md. Implement A023 typed wizard, approved-media/destination catalog, server policy/caps and evidence ingestion independently from organic and AI services. Preview is a text-only fictional reference; its in-memory counters and role switches are not production authorization. Run Tools/ads_tests.js. Maintain master OFF until integration/privacy/accessibility/performance gates pass.
