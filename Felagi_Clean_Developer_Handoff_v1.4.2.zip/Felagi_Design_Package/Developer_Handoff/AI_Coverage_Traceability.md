# AI directive coverage and traceability

Canonical AI behavior owner: AI_Evaluation_Contract.md. Machine chain: Design_Data/ai-requirement-coverage.json. All51 sections preserved; reference execution is distinguished from production evidence.

| Requirement | Screen | Canonical placement | Test |
|---|---|---|---|
| AI-1 Insert into the Product Definition | S015 | System_Specification/AI_Evaluation_Contract.md | AI-1 |
| AI-2 Add a canonical Need Requirement Model | S014 | System_Specification/AI_Evaluation_Contract.md | AI-2 |
| AI-3 Add Need Requirement Confirmation before comparison where needed | S014 | System_Specification/AI_Evaluation_Contract.md | AI-3 |
| AI-4 Add Eligibility Gate before AI scoring | S014 | System_Specification/AI_Evaluation_Contract.md | AI-4 |
| AI-5 Freeze one comparison snapshot | S014 | System_Specification/AI_Evaluation_Contract.md | AI-5 |
| AI-6 Add a canonical Evaluation Contract | S015 | System_Specification/AI_Evaluation_Contract.md | AI-6 |
| AI-7 Keep the 1–10 score, but make it evidence-grounded | S015 | System_Specification/AI_Evaluation_Contract.md | AI-7 |
| AI-8 Separate Score from Evidence Coverage | S015 | System_Specification/AI_Evaluation_Contract.md | AI-8 |
| AI-9 UNKNOWN must remain UNKNOWN | S015 | System_Specification/AI_Evaluation_Contract.md | AI-9 |
| AI-10 Add Hard Requirement handling | S015 | System_Specification/AI_Evaluation_Contract.md | AI-10 |
| AI-11 Add contradiction detection | S015 | System_Specification/AI_Evaluation_Contract.md | AI-11 |
| AI-12 Add Missing Information / Clarification guidance | S015 | System_Specification/AI_Evaluation_Contract.md | AI-12 |
| AI-13 Add trade-off analysis | S015 | System_Specification/AI_Evaluation_Contract.md | AI-13 |
| AI-14 Add Near-Tie handling | S015 | System_Specification/AI_Evaluation_Contract.md | AI-14 |
| AI-15 Preserve AI as advisory only | S015 | System_Specification/AI_Evaluation_Contract.md | AI-15 |
| AI-16 Upgrade S014 Compare Confirmation | S014 | System_Specification/AI_Evaluation_Contract.md | AI-16 |
| AI-17 Upgrade S015 Comparison Result | S015 | System_Specification/AI_Evaluation_Contract.md | AI-17 |
| AI-18 Add criterion-level cards | S015 | System_Specification/AI_Evaluation_Contract.md | AI-18 |
| AI-19 Add professional executive summary | S015 | System_Specification/AI_Evaluation_Contract.md | AI-19 |
| AI-20 Add downloadable professional result | S016 | System_Specification/AI_Evaluation_Contract.md | AI-20 |
| AI-21 Add Provider Result Projection | S015 | System_Specification/AI_Evaluation_Contract.md | AI-21 |
| AI-22 Add Provider Feedback UX | S015 | System_Specification/AI_Evaluation_Contract.md | AI-22 |
| AI-23 Lock equal result-event semantics | S018 | System_Specification/AI_Evaluation_Contract.md | AI-23 |
| AI-24 Add in-app notification contract | S018 | System_Specification/AI_Evaluation_Contract.md | AI-24 |
| AI-25 Add Telegram result delivery | S018 | System_Specification/AI_Evaluation_Contract.md | AI-25 |
| AI-26 Lock Telegram evidence semantics | S018 | System_Specification/AI_Evaluation_Contract.md | AI-26 |
| AI-27 Telegram failure must not corrupt comparison | S018 | System_Specification/AI_Evaluation_Contract.md | AI-27 |
| AI-28 Add comparison state machine | S015 | System_Specification/AI_Evaluation_Contract.md | AI-28 |
| AI-29 Add output validation gate | S015 | System_Specification/AI_Evaluation_Contract.md | AI-29 |
| AI-30 Add criteria versioning | S015 | System_Specification/AI_Evaluation_Contract.md | AI-30 |
| AI-31 Add Admin AI Control Center | A006 | System_Specification/AI_Evaluation_Contract.md | AI-31 |
| AI-32 Add criteria governance | A006 | System_Specification/AI_Evaluation_Contract.md | AI-32 |
| AI-33 Add AI Safe Mode / Kill Switch | A006 | System_Specification/AI_Evaluation_Contract.md | AI-33 |
| AI-34 Add failure and recovery UX | S015 | System_Specification/AI_Evaluation_Contract.md | AI-34 |
| AI-35 Add partial / uncertain result rules | S015 | System_Specification/AI_Evaluation_Contract.md | AI-35 |
| AI-36 Add comparison history | S016 | System_Specification/AI_Evaluation_Contract.md | AI-36 |
| AI-37 Add re-evaluation / appeal boundary | S015 | System_Specification/AI_Evaluation_Contract.md | AI-37 |
| AI-38 Add privacy projections to the design contract | S015 | System_Specification/AI_Evaluation_Contract.md | AI-38 |
| AI-39 Add audit trail | S015 | System_Specification/AI_Evaluation_Contract.md | AI-39 |
| AI-40 Add professional result design pattern | S015 | System_Specification/AI_Evaluation_Contract.md | AI-40 |
| AI-41 Add visual rules | S015 | System_Specification/AI_Evaluation_Contract.md | AI-41 |
| AI-42 Add responsive behavior | S015 | System_Specification/AI_Evaluation_Contract.md | AI-42 |
| AI-43 Add accessibility requirements | S015 | System_Specification/AI_Evaluation_Contract.md | AI-43 |
| AI-44 Add localization | S015 | System_Specification/AI_Evaluation_Contract.md | AI-44 |
| AI-45 Add traceability | S015 | System_Specification/AI_Evaluation_Contract.md | AI-45 |
| AI-46 Add mandatory acceptance tests | S015 | System_Specification/AI_Evaluation_Contract.md | AI-46 |
| AI-47 Add fairness consistency test | S015 | System_Specification/AI_Evaluation_Contract.md | AI-47 |
| AI-48 Add result integrity checks | S015 | System_Specification/AI_Evaluation_Contract.md | AI-48 |
| AI-49 Add package placement requirements | S015 | System_Specification/AI_Evaluation_Contract.md | AI-49 |
| AI-50 Final locked architecture statement | S015 | System_Specification/AI_Evaluation_Contract.md | AI-50 |
| AI-51 Final implementation instruction | S015 | System_Specification/AI_Evaluation_Contract.md | AI-51 |
