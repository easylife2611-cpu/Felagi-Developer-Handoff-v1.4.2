# Felagi — Developer START HERE

## Release identity
- **Clean handoff release:** v1.4.2
- **Canonical design-contract version:** v1.4.1
- **Design-source acceptance:** PASS
- **Developer handoff:** READY
- **Production release:** NOT YET VERIFIED

The v1.4.2 change is a documentation/handoff reconciliation layer over the already-corrected v1.4.1 canonical design contracts. Do not reinterpret this as a product redesign.

## First reading order
1. `README.md`
2. `Product_Design/Final_Master_Product_Design_Specification.md`
3. `Developer_Handoff/Final_Developer_Handoff_Specification.md`
4. `Developer_Handoff/Release_Gates_and_Evidence.md`
5. `Design_Data/screen-manifest.json`
6. `Design_Data/routes.json`
7. `Design_Data/actions.json`
8. `Design_Data/control-registry.json`
9. `System_Specification/AI_Evaluation_Contract.md`
10. `System_Specification/Monetization_Payment_Specification.md`
11. `System_Specification/Sponsored_Advertising_Contract.md`
12. `System_Specification/Admin_Authorization_Contract.md`

## Locked implementation rule
Treat this package as the implementation baseline. Do not redesign approved behavior, rename canonical states/routes/actions, or introduce a second source of truth. If implementation exposes a contradiction, record it against the canonical owner and resolve it explicitly; do not silently improvise.

## Implementation order
1. App shell, auth/session and route/state infrastructure.
2. Shared design system, tokens, localization and accessibility primitives.
3. Need and Offer marketplace flow.
4. Messaging/notifications/Telegram publication.
5. AI comparison snapshot/evaluation/result projections.
6. Payment + Need Boost + Offer Submission Unlock.
7. Main Admin control plane.
8. Sponsored Advertising subsystem.
9. Observability, jobs, backups/recovery and production operations.
10. Production-pass verification gates.

## Do not claim production PASS from source tests
The following still require implementation/runtime evidence: browser/device responsive behavior, keyboard/screen-reader accessibility, Flutter analyze/test/build/device proof, authenticated backend authorization, payment provider verification/reconciliation, AI provider behavior, Telegram delivery semantics, ads serving/security/analytics, jobs/queues, observability and backup/restore.

## Definition of DONE for a production work package
`IMPLEMENTED + INTEGRATED + TESTED + VERIFIED + DOCUMENTED + EVIDENCED`

Use `Developer_Handoff/Release_Gates_and_Evidence.md` as the production-pass checklist.
