# Felagi Design Integration Contract — revision1.1

This contract closes presentation ambiguities discovered in the package audit. DFM-FDS-1.4 invariants are preserved. The following contracts specify required implementation; they are not evidence of deployed endpoints. All paths use `/api/v1`, authenticated server-side projection, error envelope and pagination from DFM §5.

## Public preview before creation
S006 computes only the DFM allowlisted public projection from local draft: title, category display, coarse location, approved budget/currency and public link placeholder. The future link is explicitly labelled server-inserted, never invented. The server recomputes allowlisted content at POST/PUT and stores publication_version/content_hash/payload_snapshot and consent timestamp. A material mismatch with reviewed fields/destination policy returns422 PUBLIC_PREVIEW_CHANGED with refreshed safe projection; client returns to S006 unchecked. This error is added to the create/update contract, not a pre-creation server draft resource. Successful create allocates ID before S007. Edits use existing ID and If-Match and return S008 after success. Attachments for unsaved drafts use parent_id nullable with server-bound uploader ownership; parent binding occurs atomically after validation, not by trusting arbitrary client parent IDs.

## Additional read-only Admin evidence routes
Every route requires browser Admin session, CSRF for writes, explicit permission and purpose-bound audit. Pagination shape `{data:[],meta:{next_cursor,total:null},observed_at,request_id}`; unknown total stays null. Filters allowlisted, max100 rows; no sensitive detail in forbidden responses.

| Route | Permission | Exact returned view fields | Error/recovery |
|---|---|---|---|
| GET /admin/files | FILES_METADATA_READ; Main Admin or scoped Admin | id, purpose, masked_owner_ref, size_bytes, media_type, quarantine_status, created_at, retention_at; no download URL | 403 safe denial; failure unknown, not zero files |
| GET /admin/backups | BACKUP_EVIDENCE_READ; Main Admin/scoped Admin | id, scope, created_at, checksum, encrypted, last_restore_drill_at, restore_evidence_ref, status | Missing drill evidence is UNKNOWN; no restore mutation |
| GET /admin/security | SECURITY_EVIDENCE_READ; Main Admin/scoped safe Admin projection | masked session/event refs, event_type, occurred_at, masked secret_reference, rotation_evidence_ref; never token/secret | Scope filter before result counts; no mutation |
| GET /admin/marketplace | MARKETPLACE_SUPPORT_READ with purpose, bounded Moderator report scope | public Need rows, controlled Offer summaries, category IDs/names/active, report links; projection by role | No competitor/private data beyond granted support purpose |
| GET /admin/ai/usage | AI_OPERATIONS_READ; Main Admin/scoped Admin | criteria_version, prompt_version, model_id, cap_settings_version, request_count, token_count, cost_decimal, currency, interval_start/end, coverage | Partial provider cost is labelled PARTIAL; null not0 |
| GET /my/comparisons | ACTIVE included provider only | id, version, Need public summary, own participation status, created_at; paginated | No competitor details; only comparisons containing own Offer |

These read endpoints expose existing DFM records/evidence and add no new product policy or direct edit capability. Files/backups/security rows do not imply a download, restore, secret rotation or database-edit UI. Those remain controlled runbooks/permission-specific implementation.

## Telegram activation and operations
POST `/admin/telegram/destinations/{id}/activate`: Main Admin, recent reauth+2FA, reason, If-Match. Require unexpired permission proof, category scope and fresh successful posting-rights validation. Return200 ACTIVE with new version/audit ID. 409 if evidence/version stale,422 missing permission/rights,403 role denied. Creation yields DRAFT; validation is not activation. POST pause preserves history and skips future unauthorized sends.

POST `/admin/telegram/publications/{id}/retry-or-reconcile`: `{intent: RECONCILE|RETRY_ELIGIBLE, reason, evidence_ref, base_version}` plus idempotency key. UNCERTAIN permits only RECONCILE; server verifies known message/provider evidence before an eligible retry. Return202 operation_ref; GET publications exposes operation state. No generic force-resend or direct POSTED setter.

## Admin data mappings using existing endpoints
Features/Content/AI/Settings use filtered GET settings and exact typed draft/validate/preview/publish/rollback lifecycle. Notifications uses GET jobs filtered to notification class. Dashboard/health/integrity/audit/payments/users/reports use existing DFM endpoints. No per-screen duplicate truth store.

## UI schema refinements
DFM explicit bounds take priority: Need title5..255, description20..10000; Offer proposal20..10000; message1..5000; rating1..5. Optional UI text caps (profile name150, phone30, coarse location255, reason1000, notes/review/details10000) are defensive presentation ceilings; API validates and returns field errors. Amounts are decimal strings; no binary-float currency calculations. Quantity positive when present, budget nonnegative with min<=max; dates use server-time eligibility. Currency defaults ETB, cannot silently change existing records. Enum fields must use the stated allowlist. Upload max/type come from verified deployment config; don't invent an untested universal size.

## Local draft policy
Production draft content uses app-private encrypted storage bound to current user, expires7 days after last edit, clears on explicit discard/logout/account switch and is excluded from backups where platform permits. Attachments remain quarantined server refs or local temporary files with corresponding expiry. Preview drafts are memory-only and vanish on reload; no real personal data should be entered. Reconnect reloads authorization/version and requires explicit submit. Production storage/deletion proof is a release test.

## Report field binding
POST reports serializes `entity_type` (NEED/OFFER/MESSAGE/USER), `entity_id`, `reason_code` (SAFETY/FRAUD/SPAM/OTHER), and optional details. These concrete report-reason codes are a design-contract allowlist implementing the existing DFM reason_code field; OTHER preserves expressiveness. Context is prefilled from origin, still server-authorized. Rating recipient is derived from the accepted relationship and verified server-side, never freely selected. Provider history `/my/comparisons` is read-only own-participation projection; export is requester-only.
