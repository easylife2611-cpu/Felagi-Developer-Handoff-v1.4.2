# Monetization and Payment Specification — canonical 1.3

## Policy
Revenue: requester Need Boosting; provider Offer Submission Unlock. No percentage of final transaction. Production unlock default: feature_enabled=false; amount_minor=0; currency=ETB. `payment_required = feature_enabled AND amount_minor > 0`. Amount is integer hundredths of ETB; show exact localized amount before Pay. Missing policy is UNKNOWN and blocks submission while preserving draft. Do not substitute zero for a missing value.

OFF = FREE. ON + 0 ETB = FREE. ON + positive amount = PAYMENT REQUIRED. CLIENT SUCCESS ≠ VERIFIED PAYMENT. VERIFIED PAYMENT → NO SECOND CHARGE. Existing published boost package prices remain; directive examples 50/120/250 ETB are not launch defaults. Provider bounds and current published packages must be loaded before checkout.

## S011 → S023 → S012 contract
S011 validates and saves draft before leaving. Submit calls `POST /api/v1/offer-submissions` with Need ID, draft ID/version/hash, complete validated Offer payload, and stable idempotency key. Server atomically checks actor/provider, Need OPEN, deadline, limits, feature policy and duplicates. Free policy creates exactly one Offer and returns its ID. Paid policy creates exactly one submission aggregate and one payment intent, returning immutable quote, currency, version, explanation, provider checkout link and pending state. S023 shows exact amount, purpose, preserved draft, cancel/back, pending status and recovery action. Payment is access to submit this Offer, not a success guarantee or commission.

New schema owned here: submission_id UUID; provider_id; need_id; draft_id/version/hash; idempotency_key; policy_version; amount_minor; currency; payment_id nullable; offer_id nullable; state; created_at/updated_at; refund_reference nullable. Unique(provider_id,idempotency_key), unique(payment_id), unique(offer_id); existing product duplicate-Offer constraints still apply. Same key + different payload returns 409 IDEMPOTENCY_CONFLICT. Intent creation and outbox scheduling are transactional. Payment records add OFFER_UNLOCK purpose and submission_id foreign key. Existing `POST /needs/{id}/offers` must delegate to this same service and cannot bypass paid gating; edits to an already submitted Offer do not charge again.

`GET /api/v1/offer-submissions/{id}` is owner-only and returns authoritative receipt, snapshot, Offer ID, pending/recovery/refund status, allowed actions and timestamps. `POST /api/v1/offer-submissions/{id}/resume` reuses receipt and same submission key; it never creates a second charge. Cross-account requests return denied without private draft/payment data. Poll using server Retry-After (5 seconds if explicitly absent); pause while background/offline; after 2 minutes show pending with manual refresh, not failure. Callback and polling both converge on the same aggregate.

## Authoritative fulfillment
Provider evidence is authenticated server-side; merchant, reference, amount, currency and purpose must match snapshot. Client callbacks only trigger GET reconciliation. After verified payment, transaction locks submission and Need, verifies eligibility, inserts Offer exactly once and records offer_id. Automatically complete submission; notify provider and navigate/recover to S012. Interrupted worker/response resumes same aggregate, no second charge. Repeated callback or double click returns the existing receipt.

If Need has expired/closed, permissions revoked, or a nonrecoverable rule prevents insertion after verified payment: do not create invalid Offer; retain draft and payment receipt, mark fulfillment blocked/refund pending and queue a full fixed-fee refund through the payment provider. No wallet credit. If provider cannot automatically refund, create a tracked support case with receipt, owner, timestamps and escalation; UI remains refund pending until authoritative evidence. Never promise refund completion without evidence. Refund is compensating payment record; original CONFIRMED history is immutable.

## Version and pending intent policy
Only intents created after a published policy's effective timestamp use the new policy. Existing pending intents retain original fee/version even if price changes or unlock turns OFF. S023 explicitly states this. User may request cancellation; cancellation must be confirmed by server/provider before abandoning the intent and evaluating a new free submission. If cancellation is uncertain, keep pending and reconcile; do not begin another charge or duplicate free submission. If verified payment arrives during cancellation, fulfill once if eligible; otherwise refund. Config disable blocks new paid intents, not callbacks/reconciliation/refunds for existing intents. Expired provider checkout is not proof of nonpayment. Reconcile before generating a replacement intent; replacements link to the aggregate and require authoritative terminal nonpayment.

## Draft retention and privacy
Server stores an authorized saved draft before intent creation; device keeps an encrypted local draft where platform storage supports it. Do not persist secrets or provider credentials in draft. Deleting a local draft does not cancel an intent. Sign-out removes local private cache; authenticated recovery reloads server receipt. Preview memory-only drafts demonstrate interaction, not production durability. A fee change never changes draft content.

## Failure responses
| Code | UI / recovery | Charge behavior |
|---|---|---|
| POLICY_UNKNOWN / 503 | Draft saved, refresh policy | No intent |
| VALIDATION / 422 | Field-linked errors, focus summary | No intent |
| DEADLINE / 409 | Explain expired Need, keep draft | No intent; post-payment refund path |
| STALE_VERSION / 409 | Reload diff, reconfirm amount | No automatic replay |
| IDEMPOTENCY_CONFLICT / 409 | Recover existing submission; compare payload | No second intent |
| PAYMENT_PENDING / 202 | Pending receipt, refresh, back safely | Reconcile same intent |
| PAYMENT_REVIEW_REQUIRED / 202 | Evidence mismatch; support reference | No unlock/second payment |
| SUBMISSION_RECOVERY / 202 | Resume without charge | Verified entitlement retained |
| DENIED / 403 | Preserve allowed draft, return/sign-in | Never charge unauthorized actor |
| RATE_LIMITED / 429 | Show retry time | Same idempotency key |

## Marketplace health guardrail
All metrics show cohort, numerator, denominator, window, last measured time and coverage. Unknown is never zero. Define daily cohorts and rolling 7/28-day views in Africa/Addis_Ababa, retaining UTC events. Time-to-first-Offer uses eligible posted Needs and first valid Offer, showing median/p90 plus no-Offer fraction. Offers/Need and qualified Offers/Need divide valid/qualified Offers by eligible posted Needs; qualified means passes the existing eligibility rules, not an invented AI score. Submission conversion = submitted unique draft IDs / validated submission-attempt draft IDs. Accepted-Offer conversion = Needs with accepted Offer / eligible posted Needs. Completion = completed awarded Needs / awarded Needs. Repeat usage = actors with >=2 successful postings/submissions / active requester/provider actors, reported separately.

Before enabling a positive fee, impact review must show baseline and recent metrics plus data coverage. Missing metrics block ordinary activation; Main Admin may use an explicitly audited emergency override only to restore free submission, never to raise fees. Set a comparison window and approved maximum deterioration per metric as required structured governance inputs; no unapproved threshold defaults. Breach creates visible incident and blocks further fee increases; Main Admin reviews and can restore free-launch preset through the governed loop. Do not automatically optimize price or quietly sacrifice liquidity for revenue. Numeric launch thresholds require product-owner evidence and remain a publication gate, not a developer guess.

## Acceptance
POL-01 all three fee branches; POL-02 invalid/missing policy blocks; POL-03 duplicate click one intent; POL-04 client success leaves pending; POL-05 repeated verified event one Offer; POL-06 interruption resume no recharge; POL-07 expired Need refunds; POL-08 snapshots survive config change; POL-09 disable pending retains snapshot; POL-10 old API cannot bypass; POL-11 no commission; POL-12 liquidity evidence gates activation. Reference tests cover model behavior; backend concurrency/provider tests remain external.


## Third revenue domain: Sponsored Advertising
Sponsored Advertising buys clearly labelled approved placement, not organic rank or AI influence. It defaults OFF; see Sponsored_Advertising_Contract.md for campaign, controls, schedule, privacy, analytics and rollback. This addition does not change Offer Unlock's OFF/zero free invariant, Need Boost receipt authority, or no-percentage-commission rule. MVP ad commercial reference is Admin-recorded; no invented ad payment gateway is specified.
