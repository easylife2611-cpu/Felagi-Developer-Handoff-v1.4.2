# Demand-First Marketplace — Final Developer Technical Design

**Specification ID:** DFM-FDS-1.4  
**Date:** 2026-09-28  
**Status:** Implementation specification; locked product baseline preserved  
**Audience:** Laravel, Flutter, database, AI integration, Admin, QA, and operations teams  
**System:** Flutter mobile app → HTTPS REST → Laravel monolith → MySQL/MariaDB, with Telegram login, an AI provider, a local payment adapter, cPanel cron and database queue.

## 0. How to use this document

This document is the single implementation contract. The three supplied sources are: (S1) Demand-First Marketplace App — Complete System Design v4.0, (S2) FINAL BASELINE FREEZE, and (S3) Final Hardened Baseline. S1 defines product behavior; S2 and S3 strengthen integrity, privacy, operations and deployment. A later hardening rule prevails when an older illustrative schema or label conflicts with it. The reconciliation table below records such decisions. Illustrative numbers and example prices in source material are not production prices.

Revision 1.4 adds the canonical Flutter screen crosswalk and screen-level implementation appendix without changing the locked product rules. Revision 1.3 makes public-supergroup broadcasting a required launch capability, subject to destination permission and public-post disclosure. Revision 1.2 adds an authorized Telegram distribution channel without changing marketplace authority, privacy or comparison fairness. Revision 1.1 strengthens the one-award database invariant, closes deadline-edit and late-payment behavior, and clarifies retryable versus terminal states. The later attached “Pasted markdown(1).md” contains an exact token-for-token prefix of revision 1.0 through the middle of §4; its tables were flattened and the rest of the document is absent. It contributes no additional product decision and is not used as a replacement for the complete source.

The developer must implement the interfaces, state guards, access rules and tests here. A provider integration requiring external credentials or an actual hosting account passes its release gate only after that environment is supplied and verified. This document specifies the contract without pretending those credentials or hosting limits have been tested.

### 0.1 Reconciliation and implementation decisions

| ID | Source tension / unresolved choice | Canonical decision for this specification | Reason and verification |
|---|---|---|---|
| D01 | S3 says a provider cannot “add its own Offer”; S1 explicitly allows providers to submit Offers. | A provider may create and edit its own Offer on someone else's OPEN Need. The Need owner cannot offer on that Need; only that owner may accept an Offer. | Preserves the demand-first flow. Test self-offer and self-accept denial. |
| D02 | S1 payment success is SUCCESS; S2 uses CONFIRMED. | Internal payment status is CONFIRMED. Provider SUCCESS/PAID is an external event mapped only after server verification. | One internal state language; test duplicate and forged callbacks. |
| D03 | S1 suggests rating_score defaults to 5.00 before any rating. | A user with zero valid ratings has rating_score = NULL and rating_count = 0; show “No ratings yet.” | Avoids representing unknown credibility as a five-star observation. |
| D04 | S1 includes is_boosted and boost_expires_at on needs and a boosts table. | boosts is the authority. Need boost display is derived from an ACTIVE, unexpired boost; any cached flag is disposable and reconciled. | No parallel financial truth. |
| D05 | S1 proposes optional attachment_url fields or a central table. | Use one attachments table with explicit parent FKs and private storage. | Enforces ownership and download authorization. |
| D06 | S1 says one active Offer per provider per Need “normally.” | MVP permits one Offer per provider per Need, editable while PENDING and withdrawable. Withdrawal ends that submission. | Portable UNIQUE constraint; a future resubmission policy requires a versioned change. |
| D07 | S2 allows automatic selection or requester selection when too many Offers exist. | Compare all eligible Offers up to the configured cap. Above it, return TOO_MANY_OFFERS with the full eligible count and a requester-only selection list. The requester explicitly selects up to the cap; the server rechecks eligibility and records selected and excluded Offer IDs. The UI explains that excluded providers do not receive that version's result. No hidden ranking or silent exclusion. | Preserves a usable comparison path and makes inclusion inspectable. |
| D08 | S1 defines four criteria and a 1–10 total but no weights. | Criteria v1 uses four equal weights, 25% each. The AI returns per-criterion assessments; the backend computes the overall score and records evidence availability. Unknown evidence is displayed explicitly and cannot be invented. | Transparent, versioned default. See §6. |
| D09 | S1 calls scheduled settings optional. | Draft/publish/version/rollback is required. Scheduled changes are Phase 4, disabled until implemented. | Prevents a promised control from appearing functional before it exists. |
| D10 | RPO/RTO are named without numbers. | Initial operational targets are RPO ≤ 24 hours and RTO ≤ 8 hours, conditional on an external backup and a measured restore drill. Failed proof blocks a production-readiness claim; a stricter business target requires hosting and backup changes. | Concrete measurable release gate, not a claim about the current host. |
| D11 | S1 permits Telegram login variants and either Telebirr or Chapa. | Telegram OIDC authorization-code + PKCE is the primary identity contract; no bot-chat OTP is assumed. Payment adapter interface supports a selected local provider, with the first live adapter named and contract-tested at deployment. | Provider choice does not change core business rules. |
| D12 | S1 phases put Admin dashboard and audit late, while hardening requires safe operations earlier. | Minimum Admin, audit, settings, health, moderation and recovery controls ship with each capability they govern; richer reporting can wait until Phase 4. | No ungoverned AI/payment release. |
| D13 | A single needs.accepted_offer_id pointer does not by itself prevent inconsistent offers.status rows. | need_awards is the canonical acceptance record with need_id PK and a same-Need composite FK to the awarded Offer; Need/Offer statuses are transactional projections. | Database enforces at most one award and correct Offer ownership. |
| D14 | S1 allows Offer editing before acceptance and offers an optional submission deadline without stating whether edits remain open after it. | If offer_deadline_at exists, new submissions and edits close at that server-time boundary; withdrawal remains allowed while PENDING and Need OPEN. | Competitive cutoff cannot be bypassed through late edits. |
| D15 | Broad Telegram distribution is requested, but public visibility alone grants neither posting permission nor measured reach. | Official owned channel and at least one administrator-approved public partner supergroup are required at launch. Broadcast eligible public Needs automatically after the requester acknowledges the exact public distribution preview; third-party destinations require recorded administrator authorization, bot posting capability and category policy. Publish a redacted Need summary through Bot API jobs; the bot is added/approved by group administrators, not self-joined or scraped. | A defensible acquisition channel, not an assumed right to post to thousands of groups. |

These are explicit design closures derived from the supplied baseline. Changes require a new spec revision, impact analysis and regression tests; they are not silent implementation guesses.

## 1. Product contract

### 1.1 Vision, flow and business model

A requester posts a Need first. Eligible providers submit Offers. The requester triggers a comparison using a fixed snapshot and the same criteria for every included Offer. The requester sees the full result; participating providers receive the same comparison-ready event and may see their own detailed assessment plus permitted aggregate context. The requester chooses one Offer, tracks fulfillment, confirms completion, and both parties may rate the completed relationship. AI advises and never accepts, rejects or awards an Offer.

Core sequence: NEED → OFFERS → AI COMPARISON → FIXED SNAPSHOT → SAME CRITERIA → EQUAL RESULT EVENT → REQUESTER DECISION → ACCEPTED OFFER → IN_PROGRESS → COMPLETED → RATING.

Need posting, messaging and marketplace access remain free. Offer submission is free when Offer Submission Unlock is OFF or its configured amount is zero; otherwise a fixed verified payment unlocks submission. Initial production default is OFF and 0 ETB. The marketplace takes zero percentage commission. Canonical revenue is Need Boosting plus Offer Submission Unlock. See the owned Monetization and Payment Specification for exact intent/version/recovery rules. The app serves goods, services, recruitment, rentals, logistics, tutoring and Admin-managed categories. Basic keyword, location, budget, deadline, boost and recency discovery is included. No in-app social feed, wallet, escrow, subscription tiers, advanced BI, semantic search, microservices, Kubernetes, Kafka, Redis requirement, GraphQL, vector database or complex map stack is in scope.

### 1.2 Non-negotiable invariants

| ID | Invariant |
|---|---|
| I01 | Every Offer belongs to exactly one Need and one provider; the Need owner cannot submit it. |
| I02 | At most one Offer is awarded for a Need by the need_awards primary key; acceptance and Need/Offer projections change atomically. |
| I03 | A COMPLETED or CANCELLED Need cannot return to OPEN through a normal API. |
| I04 | A comparison reads only the Need, Offer, rating and rules captured in its immutable snapshot. |
| I05 | Editing an Offer or creating a new Offer never changes an earlier comparison. |
| I06 | All included Offers use the same criteria and prompt version; no paid boost, arrival time or private fact enters hidden scoring. |
| I07 | A completed result and its participant list are immutable; Compare Again makes version N+1. |
| I08 | All included providers get records from one comparison completion event and an access-controlled view. Physical Telegram delivery may differ in time and must not be claimed simultaneous. |
| I09 | Only the Need owner decides acceptance; AI and Admin cannot silently decide for them. |
| I10 | Client user IDs, offered price changes, payment status, deadlines and comparison eligibility are never trusted without server validation. |
| I11 | A boost activates only from a verified, amount/currency/reference-matched payment, once. |
| I12 | Critical changes are transactional and retryable external actions have idempotent business effects. |
| I13 | Authorization is checked by Laravel on every operation and private file download. |
| I14 | Admin settings and feature flags cannot weaken core authorization, privacy, payment verification or audit. |
| I15 | Historical comparisons, confirmed payments and audit evidence are never silently rewritten or physically deleted by routine cleanup. |
| I16 | A failed AI call leaves the snapshot and Offers intact and never produces fabricated scores. |
| I17 | Telegram distribution is required for eligible public Needs to authorized destinations; an external post is a public copy, cannot alter Need/Offer/comparison/payment state or promise an Offer outside the app. |
| I18 | Only a destination with current recorded administrator permission and working bot posting rights may receive an automated post; STOP, ban or revoked rights halt queued sends. |

### 1.3 Time, money and identity conventions

All persisted business timestamps are UTC DATETIME(6); the UI renders in the selected local timezone and sends offset-aware ISO 8601 timestamps. Deadline decisions use server UTC, with the exact boundary defined as now < offer_deadline. Money uses DECIMAL(12,2), never binary floating point, and currency ISO-like CHAR(3), initially ETB. UUIDs use CHAR(36) consistently across primary and foreign keys. The authenticated user ID is derived from the server session/token, not a client body. One human account may act as Requester on its Needs and Provider on other Needs; these contextual roles are not separate identities.

## 2. Components and trust boundaries

| Component | Owns | Does not own |
|---|---|---|
| Flutter | Navigation, accessible presentation, form feedback, local draft state, offline indication, secure token storage, API calls. | Eligibility, authorization, status transitions, payment truth or AI scoring. |
| Laravel Auth | Telegram identity verification, session/token issuance and revocation, user state checks. | Trusting a client-provided Telegram ID without proof. |
| Marketplace | Need and Offer policy, edits, deadlines, acceptance, completion, ratings, discovery. | Provider payment confirmation. |
| Comparison service | Eligibility, version allocation, snapshot, AI request, validation, immutable result, equal notification event. | Accepting an Offer. |
| Payment/Boost service | Provider adapter, verified callback/reconciliation, amount matching, activation. | Client “paid” assertions. |
| Admin | Published settings, moderation, health, recovery, audit views and controlled operations. | Direct manual mutation of confirmed payment or immutable comparison rows. |
| Database | Referential integrity, uniqueness, transactions, durable queues/outbox. | Network calls inside open business transactions. |
| Telegram distribution adapter | Authorized destination registry, safe public projections, posting jobs, Telegram receipt evidence and pause/removal. | Acting as a Telegram user account, unsolicited public-group posting, Need authority or offer acceptance. |

The Laravel monolith is the only business authority. External calls to Telegram, AI and payment providers occur outside database transactions through bounded jobs and adapters. The app can read existing state when an optional external provider is unavailable. Feature kill switches block UI entry, API writes and service execution together.

## 3. Relational schema contract

### 3.1 Common rules

Use InnoDB, matching UUID collation/charset and FK types, UTC DATETIME(6), created_at/updated_at on mutable rows, and restrictive foreign keys for business records. Avoid physical cascades on financial, comparison and audit history. A deleted/archived user or Need remains referentially present. status values use constrained application enums plus database CHECK where the deployed MySQL/MariaDB version enforces them; a migration compatibility test must verify actual enforcement. All status transitions use services and row locks, not unrestricted model updates. Unique keys are always database-enforced. JSON columns are validated against a versioned application schema before storage.

### 3.2 Canonical tables

**users** — id PK; telegram_subject VARCHAR(100) NOT NULL UNIQUE; full_name VARCHAR(150) NOT NULL; phone_number VARCHAR(30) NULL; profile_photo_url TEXT NULL; status ENUM-like ACTIVE/SUSPENDED/BANNED NOT NULL DEFAULT ACTIVE; rating_score DECIMAL(3,2) NULL; rating_count INT UNSIGNED NOT NULL DEFAULT 0; version INT UNSIGNED NOT NULL DEFAULT 1; last_login_at, deleted_at NULL; timestamps. CHECK rating_score BETWEEN 1 AND 5 when non-null and rating_count ≥ 0. Index status, created_at. Telegram subject is stable provider identity; never use username as a key.

**user_roles** — user_id FK users; role MAIN_ADMIN/ADMIN/MODERATOR; granted_by FK users NULL; granted_at; revoked_at NULL; PK (user_id, role). This is the current grant record; every grant/revocation/regrant is also recorded in append-only audit_logs. Requester/Provider authority is contextual from record ownership and eligibility.

**categories** — id PK; slug VARCHAR(60) UNIQUE; name_am, name_en; active BOOLEAN; sort_order INT; created_by FK users NULL; timestamps. Initial slugs goods, services, recruitment, rental, logistics, tutoring, other. Deactivation blocks new Needs but preserves old Need references.

**needs** — id PK; requester_id FK users RESTRICT; category_id FK categories RESTRICT; title VARCHAR(255) NOT NULL; description TEXT NOT NULL; location_text VARCHAR(255) NULL; budget_min, budget_max DECIMAL(12,2) NULL; currency CHAR(3) NOT NULL DEFAULT ETB; quantity DECIMAL(12,2) NULL; deadline_at, offer_deadline_at NULL; status OPEN/IN_PROGRESS/COMPLETED/CANCELLED NOT NULL DEFAULT OPEN; version INT UNSIGNED DEFAULT 1; telegram_publication_consent_at DATETIME(6) NOT NULL; telegram_publication_version INT UNSIGNED NOT NULL DEFAULT 1; telegram_publication_stopped_at NULL; completed_at, cancelled_at, archived_at, deleted_at NULL; timestamps. CHECK nonnegative budgets, budget_min ≤ budget_max, positive quantity if present. The accepted Offer is read from need_awards, not duplicated in this table. Increment telegram_publication_version only on a material change to approved public fields; stop cannot be silently reversed by a routine edit. Index (status, created_at), (category_id, status, created_at), (requester_id, status), offer_deadline_at, location_text. A plain-text location is the MVP truth; no map dependency.

**offers** — id PK; need_id FK needs RESTRICT; provider_id FK users RESTRICT; offered_price DECIMAL(12,2) NOT NULL CHECK ≥ 0; currency CHAR(3) NOT NULL DEFAULT ETB; proposal_message TEXT NOT NULL; delivery_time_text VARCHAR(255) NULL; availability_text VARCHAR(255) NULL; additional_notes TEXT NULL; status PENDING/ACCEPTED/REJECTED/WITHDRAWN; version INT UNSIGNED DEFAULT 1; accepted_at, withdrawn_at, deleted_at NULL; timestamps. UNIQUE (need_id, provider_id), UNIQUE (id, need_id); index (need_id, status, created_at), (provider_id, status). Need owner cannot be provider, checked by service under transaction. No Offer content mutation after acceptance, rejection, withdrawal or Need completion.

**need_awards** — need_id PK and FK needs RESTRICT; offer_id UUID NOT NULL UNIQUE; accepted_by FK users RESTRICT; accepted_at DATETIME(6) NOT NULL; request_id VARCHAR(100) NOT NULL. Composite FK (offer_id, need_id) references offers (id, need_id) so an award cannot point to another Need's Offer. This row is the sole authority for acceptance. The acceptance transaction locks the Need, inserts one award, updates that Offer to ACCEPTED, other PENDING Offers to REJECTED, Need to IN_PROGRESS, and writes audit/outbox. Only the application acceptance service has a write path; general Admin endpoints expose no arbitrary SQL or award mutation. Integrity checks verify the status projections agree with the award.

**comparisons** — id PK; need_id FK needs RESTRICT; version_number INT UNSIGNED NOT NULL; triggered_by FK users RESTRICT; status PENDING/PROCESSING/COMPLETED/FAILED; criteria_version VARCHAR(50); prompt_version VARCHAR(50); output_schema_version VARCHAR(30); ai_provider VARCHAR(50); model_id VARCHAR(100); need_snapshot JSON NOT NULL; snapshot_hash CHAR(64); eligible_offer_count INT UNSIGNED; included_offer_count INT UNSIGNED; input_token_count, output_token_count INT NULL; estimated_cost DECIMAL(12,4) NULL; failure_code VARCHAR(80) NULL; attempt_count INT UNSIGNED DEFAULT 0; requested_at, started_at, completed_at, failed_at; timestamps. UNIQUE (need_id, version_number), index (need_id, status, created_at). Exactly one active PENDING/PROCESSING comparison per Need is enforced by locking the Need row before allocation and rejecting another active request. Only completed rows expose results.

**comparison_offers** — id PK; comparison_id FK comparisons RESTRICT; offer_id FK offers RESTRICT; provider_id FK users RESTRICT; offer_snapshot JSON NOT NULL; credibility_snapshot JSON NOT NULL; offer_snapshot_hash CHAR(64); created_at. UNIQUE (comparison_id, offer_id), UNIQUE (comparison_id, id); index comparison_id, provider_id. Snapshot captures price/currency/proposal/delivery/availability, relevant public credibility and evidence timestamp; no private contact, message or document body.

**comparison_results** — id PK; comparison_id FK comparisons RESTRICT; comparison_offer_id FK comparison_offers RESTRICT; score DECIMAL(4,2) NOT NULL CHECK 1 ≤ score ≤ 10; criterion UNKNOWN scores are null under v2; at least one assessable criterion is required; criterion_scores JSON NOT NULL; strengths, weaknesses, missing_information, risk_notes JSON NOT NULL; fit_explanation TEXT NOT NULL; result_hash CHAR(64); created_at. UNIQUE (comparison_id, comparison_offer_id), index comparison_id. FK consistency between comparison_id and comparison_offer_id is enforced with composite FK or validated within the final transaction plus an integrity check. Results are insert-only; corrections make a new comparison version.

**comparison_attempts** — id PK; comparison_id FK comparisons; attempt_number INT UNSIGNED; started_at, finished_at; status PROCESSING/SUCCEEDED/FAILED; provider_request_id VARCHAR(150) NULL; failure_code VARCHAR(80) NULL; token_usage JSON NULL; UNIQUE (comparison_id, attempt_number). Retries reuse the same frozen snapshot and version until a comparison completes; a new comparison version is for new business input, not a transport retry.

**messages** — id PK; offer_id FK offers RESTRICT; sender_id FK users RESTRICT; content TEXT NOT NULL; read_at NULL; created_at, deleted_at NULL. Index (offer_id, created_at). Only the Offer provider and Need requester participate. Moderation access is a separately audited permission, never blanket browsing.

**notifications** — id PK; recipient_user_id FK users RESTRICT; type VARCHAR(50); entity_type VARCHAR(40); entity_id UUID; event_id FK outbox_events NULL; title VARCHAR(255); body TEXT; channel IN_APP/TELEGRAM; delivery_status PENDING/SENT/FAILED/SKIPPED; available_at, sent_at, read_at NULL; failure_code NULL; created_at. UNIQUE (event_id, recipient_user_id, channel). Index (recipient_user_id, created_at), (delivery_status, available_at). A notification record is not proof a Telegram message was delivered or read.

**ratings** — id PK; need_id FK needs RESTRICT; from_user_id, to_user_id FK users RESTRICT; score TINYINT CHECK 1..5; review TEXT NULL; created_at. UNIQUE (need_id, from_user_id, to_user_id); CHECK from_user_id ≠ to_user_id. Service requires Need COMPLETED and parties equal requester/accepted provider. Recompute rating count and mean from valid ratings; no fabricated default.

**boost_packages** — id PK; duration_days SMALLINT > 0; price DECIMAL(12,2) ≥ 0; currency CHAR(3); active BOOLEAN; published_settings_version FK setting_versions NULL; timestamps. Seed 1, 3 and 7 day packages; actual prices are Admin-published, not source examples.

**boosts** — id PK; need_id FK needs RESTRICT; requester_id FK users RESTRICT; package_id FK boost_packages RESTRICT; payment_id FK payments UNIQUE; price_snapshot DECIMAL(12,2); currency CHAR(3); duration_days SMALLINT; status PENDING/ACTIVE/EXPIRED/CANCELLED; starts_at, expires_at NULL; timestamps. ACTIVE requires a confirmed matching payment, starts_at ≤ now < expires_at, and Need eligible under policy. Index (need_id, status, expires_at). Overlapping active boosts on the same Need are rejected under a Need row lock.

**payments** — id PK; payer_id FK users RESTRICT; need_id FK needs RESTRICT; purpose BOOST/OFFER_UNLOCK; provider VARCHAR(50); provider_reference VARCHAR(255) NULL; idempotency_key VARCHAR(100) NOT NULL; amount DECIMAL(12,2) > 0; currency CHAR(3); status PENDING/CONFIRMED/FAILED/CANCELLED/REVIEW_REQUIRED; confirmed_at, failed_at NULL; failure_code NULL; timestamps. UNIQUE (payer_id, idempotency_key), UNIQUE (provider, provider_reference) when reference non-null; index (status, created_at), need_id. CONFIRMED is reachable only through verified provider evidence. Amount, currency, merchant, reference and purpose must match the frozen initiation record.

**payment_events** — id PK; payment_id FK payments NULL until matched; provider; provider_event_id VARCHAR(255); payload_digest CHAR(64); received_at; signature_valid BOOLEAN; event_type; processing_status RECEIVED/APPLIED/DUPLICATE/REVIEW_REQUIRED/REJECTED; sanitized_metadata JSON. UNIQUE (provider, provider_event_id). Raw sensitive provider data, if retention is necessary, is encrypted and separately access-controlled; it is never logged in plaintext.

**attachments** — id PK; uploaded_by FK users; need_id FK needs NULL; offer_id FK offers NULL; message_id FK messages NULL; purpose PROFILE/NEED/OFFER/MESSAGE; storage_disk, storage_key; original_name; detected_mime; byte_size; sha256; visibility PUBLIC/PRIVATE; scan_status PENDING/CLEAN/REJECTED; created_at, deleted_at. Exactly one parent for NEED/OFFER/MESSAGE purposes; profile uses user ownership. Store outside public document root and serve through authorization. No public raw path is an access grant.

**reports** — id PK; reporter_id FK users; entity_type NEED/OFFER/MESSAGE/USER; entity_id; reason_code; details TEXT NULL; status OPEN/IN_REVIEW/RESOLVED/DISMISSED; assigned_to FK users NULL; resolution_code NULL; timestamps. Moderation decisions produce audit events.

**audit_logs** — id PK; actor_id FK users NULL; action VARCHAR(100); entity_type; entity_id; request_id; reason TEXT NULL; before_digest/after_digest CHAR(64) NULL; safe_metadata JSON; occurred_at; prev_hash/hash CHAR(64) NULL. Append-only at application permission level, protected from routine UI edits and exports with secrets redacted. Off-host backup and integrity review provide tamper evidence; a hash chain alone is not a guarantee against a privileged database operator.

**settings** — key VARCHAR(120) PK; group FEATURE/CONFIG/CONTENT/SECURITY; type BOOLEAN/INTEGER/DECIMAL/STRING/JSON; value_json JSON; default_json JSON; schema_json JSON; description; risk LOW/MEDIUM/HIGH/CRITICAL; is_secret BOOLEAN DEFAULT FALSE; version_number INT; updated_by FK users; updated_at. Secret values are references to environment/secret store, not readable plaintext in settings. Security invariants are code policy, never toggles.

**setting_versions** — id PK; setting_key FK settings; version_number INT; value_json JSON or redacted secret reference; published_by FK users; published_at; reason; source_draft_id NULL; UNIQUE (setting_key, version_number). Immutable publish history. Rollback publishes a new version with a previous approved value.

**setting_drafts** — id PK; setting_key FK settings; proposed_value_json; proposed_by FK users; status DRAFT/VALIDATED/REJECTED/PUBLISHED; validation_report JSON; impact_preview JSON; created_at, updated_at. UNIQUE live draft by key/actor can be implemented with service locking. All draft, validation, publish and rollback actions also create audit_logs; no redundant setting_change_logs table is required.

**scheduled_settings** — Phase 4 only: id PK; setting_key FK settings; planned_value_json; activate_at UTC; expire_at UTC NULL; approved_by FK users; status; version guard; audit reference. Do not show a scheduler control until this table, conflict policy and jobs exist.

**outbox_events** — id PK; event_type; aggregate_type; aggregate_id; event_key VARCHAR(160) UNIQUE; payload_json; status PENDING/PROCESSING/DONE/FAILED; attempts; available_at; locked_until NULL; created_at, completed_at NULL. Created in the same transaction as the business state it describes; dispatch after commit. Consumers are idempotent.

**idempotency_keys** — actor_scope VARCHAR(100) NOT NULL (verified user ID or signed webhook provider namespace); actor_id FK users NULL; scope; key VARCHAR(100); request_hash CHAR(64); response_code; response_body JSON NULL; status IN_PROGRESS/COMPLETE; expires_at; created_at; PK (actor_scope, scope, key). A reused key with different body returns 409.

**exports** — id PK; comparison_id FK comparisons; requester_id FK users; format PDF/XLSX/CSV/TXT; status PENDING/PROCESSING/READY/FAILED/EXPIRED; storage_key NULL; expires_at; created_at, completed_at NULL. Exports read stored results, never rerun AI; provider export is not included by default.

**telegram_destinations** — id PK; telegram_chat_id BIGINT UNIQUE NOT NULL; public_username VARCHAR(120) NULL (mutable display hint, not identity); type OWNED_CHANNEL/PARTNER_CHANNEL/PARTNER_SUPERGROUP; name; allowed_category_ids JSON or normalized destination_categories join table (use the latter when enforcing FK); permission_evidence TEXT with private evidence reference, granted_by_name/contact kept private, granted_at, reviewed_at, expires_at NULL; bot_permission_checked_at; status DRAFT/ACTIVE/PAUSED/REVOKED; daily_cap INT; quiet_hours JSON NULL; created_by/updated_by FK users; timestamps. Admin activates only after permission evidence and a successful posting-rights check. No automatic discovery or joining; a public listing is not permission. Restrict access to administrator records.

**telegram_publications** — id PK; need_id FK needs RESTRICT; destination_id FK telegram_destinations RESTRICT; need_publication_version INT UNSIGNED; content_hash CHAR(64); payload_snapshot JSON (approved public fields only); state QUEUED/SENDING/POSTED/RETRY/UNCERTAIN/FAILED/SKIPPED/REMOVAL_PENDING/REMOVED; telegram_message_id BIGINT NULL; attempts INT; next_attempt_at, posted_at, removed_at NULL; last_error_code VARCHAR(80) NULL; created_at, updated_at. UNIQUE (need_id, destination_id, need_publication_version). One row per authorized destination/Need/version; recipient is a chat, never an individual subscriber. POSTED means Telegram accepted the send, not that members viewed it. An unknown network outcome is UNCERTAIN and needs reconciliation/manual review before any repeat to avoid duplicate posting. Store public snapshots without phone, precise address, attachments, message text, provider identity or private metadata. Keep a tombstone for audit after removal.

**telegram_publication_events** — id PK; publication_id FK telegram_publications RESTRICT; event_type; request_id; telegram_response_code NULL; safe_metadata JSON; occurred_at. Append-only attempt/rights/stop/removal evidence; redact token and personal content.

**jobs / failed_jobs** — Laravel database queue framework tables, created by the compatible framework migrations. Store execution/lease/retry state. They are transport records; comparison_attempts and outbox_events are business evidence. These tables are not manually edited from Admin.

### 3.3 ERD

~~~mermaid
erDiagram
    USERS ||--o{ NEEDS : requester
    USERS ||--o{ OFFERS : provider
    CATEGORIES ||--o{ NEEDS : classifies
    NEEDS ||--o{ OFFERS : receives
    NEEDS ||--o| NEED_AWARDS : accepts_once
    OFFERS ||--o| NEED_AWARDS : awarded
    NEEDS ||--o{ COMPARISONS : versions
    COMPARISONS ||--o{ COMPARISON_OFFERS : freezes
    COMPARISON_OFFERS ||--|| COMPARISON_RESULTS : assessed
    OFFERS ||--o{ MESSAGES : conversation
    NEEDS ||--o{ BOOSTS : promotes
    PAYMENTS ||--o| BOOSTS : activates
    NEEDS ||--o{ RATINGS : completed_relation
    COMPARISONS ||--o{ EXPORTS : renders
    OUTBOX_EVENTS ||--o{ NOTIFICATIONS : fans_out
    SETTINGS ||--o{ SETTING_VERSIONS : publishes
    NEEDS ||--o{ TELEGRAM_PUBLICATIONS : public_copy
    TELEGRAM_DESTINATIONS ||--o{ TELEGRAM_PUBLICATIONS : receives
~~~

Additional FK links: telegram_publications → telegram_publication_events; comparisons.triggered_by → users; comparison_offers.offer_id → offers; messages.sender_id → users; notifications.recipient_user_id → users; boosts.requester_id → users; payment_events.payment_id → payments; attachments reference their explicit parent; audit_logs.actor_id → users. A diagram edge denotes relationship, not permission. The full FK/uniqueness definitions above are authoritative.

## 4. State transitions

| Entity | Allowed transition | Actor / guard | Atomic effects |
|---|---|---|---|
| Need | create → OPEN | Authenticated, ACTIVE requester; active category, valid inputs. | Need + audit. |
| Need | OPEN → IN_PROGRESS | Requester accepts one PENDING Offer from this Need. | Insert need_awards, accept selected Offer, reject other PENDING Offers, update Need, audit, outbox. |
| Need | OPEN → CANCELLED | Owner; no accepted Offer. | Cancel, close PENDING Offers, audit, notify. |
| Need | IN_PROGRESS → COMPLETED | Owner confirms delivery. | completed_at, audit, notify, enable rating. |
| Offer | create → PENDING | ACTIVE provider other than owner; Need OPEN; server deadline not passed; one Offer/Need/provider. | Offer + audit + new-offer outbox. |
| Offer | PENDING → PENDING | Provider edits with current version; Need OPEN; server time precedes offer_deadline_at if set. | Increment version, audit. |
| Offer | PENDING → WITHDRAWN | Provider; Need OPEN. | Withdrawal, audit, notification. |
| Offer | PENDING → ACCEPTED | Only as part of requester acceptance transaction. | See Need transition. |
| Offer | PENDING → REJECTED | Requester explicitly rejects, or another Offer is accepted. | Audit and notification. |
| Comparison | PENDING → PROCESSING → COMPLETED | Requester trigger; frozen eligible set; AI output passes schema and business validation. | Insert all results and all in-app notifications in one completion transaction. |
| Comparison | PENDING/PROCESSING → FAILED → PROCESSING | Bounded retry on same snapshot, with recorded attempt, no result published. | Failure code and attempt, then retry job. |
| Payment | PENDING → CONFIRMED | Verified provider callback or reconciliation, matching reference/amount/currency/merchant. | Payment event, boost activation, audit, outbox once. |
| Payment | PENDING → FAILED/CANCELLED/REVIEW_REQUIRED | Provider evidence, expiry or mismatch. | No boost activation; audit. |
| Payment | FAILED/CANCELLED → REVIEW_REQUIRED | A late, authenticated success event or provider reconciliation after a local terminal failure. | Persist unique event and evidence; no automatic boost activation; Admin reconciles against provider and payer with an audited resolution. |
| Boost | PENDING → ACTIVE → EXPIRED | Confirmed payment; scheduled expiry using server time. | Visibility changes and notification. |
| User | ACTIVE → SUSPENDED/BANNED | Authorized moderation with reason. | Revoke active tokens as policy, audit, notify. |
| Telegram destination | DRAFT → ACTIVE → PAUSED/REVOKED | Main Admin/Admin with permission evidence and bot rights; loss of permission forces pause/revoke. | Stop pending sends, audit, expose health. |
| Telegram publication | QUEUED → SENDING → POSTED; SENDING → RETRY/UNCERTAIN/FAILED; QUEUED/RETRY → SKIPPED; POSTED → REMOVAL_PENDING → REMOVED | Recorded public-distribution acknowledgment, active destination and open published Need rechecked before send; cancellation/moderation/owner stop attempts removal where bot rights permit. | Record Telegram message ID on success; otherwise honest delivery state and audit. |

COMPLETED/CANCELLED Need, ACCEPTED/REJECTED/WITHDRAWN Offer, COMPLETED Comparison, CONFIRMED Payment and EXPIRED Boost are terminal through routine APIs. A late authenticated provider event may move a FAILED/CANCELLED Payment to REVIEW_REQUIRED only through the reconciliation service; the routine payer API cannot reopen it. FAILED Comparison is specifically retryable on the same snapshot; a new attempt is recorded and no old result is edited. Acceptance uses SELECT ... FOR UPDATE on the Need and selected Offer, a version check, and one transaction. Competing acceptance returns 409 STATE_CONFLICT; exactly one need_awards row can exist. External sends happen after commit through outbox. Soft deletion/archive affects visibility, not historical referential truth.

## 5. HTTP API contract

### 5.1 Common protocol

Base path /api/v1, HTTPS only, JSON UTF-8. Authenticated mobile requests use a short-lived opaque Bearer access token stored in platform secure storage. A rotating refresh token is held separately; token hashes, device label, expiry, revoked_at and last_used_at are server records. Admin browser requests use a secure, HttpOnly, SameSite cookie session with CSRF protection, additional re-authentication for critical actions and a second factor before critical publishing. The selected Laravel auth implementation must meet this behavior; no plaintext token is stored in application tables.

Telegram login uses an OIDC authorization-code flow with PKCE, state and nonce. Backend starts an auth attempt, registers the configured HTTPS redirect, exchanges the code server-side, validates Telegram signature/JWKS and issuer/audience/expiry/nonce, then upserts users by verified subject. Flutter opens the system browser or a supported native SDK flow; the backend redirects only a single-use, short-lived handoff code to the app, and Flutter exchanges it for app tokens. Never pass the Telegram ID token, bot secret, refresh token or long-lived access token in a deep link. Store auth_attempts: id PK, state_hash UNIQUE, nonce_hash, encrypted PKCE verifier, handoff_hash UNIQUE NULL, return_uri_allowlisted, expires_at, consumed_at NULL, created_at; expire promptly. Bot message permission is separately consented; successful login does not imply permission to send Telegram messages.

Every success envelope has success=true, data, message, request_id, and meta for list pagination. Every error has success=false, error {code, message, details?}, request_id. Details contain field validation information only; no stack trace or secret. 400 malformed; 401 unauthenticated; 403 not allowed; 404 absent or deliberately concealed; 409 state/version/idempotency conflict; 422 field invalid or business input failure; 429 rate limit with Retry-After; 503 temporarily unavailable. Use 201 for created resources, 202 for queued comparisons/exports, 204 for logout, and 200 otherwise. Page-based pagination uses page ≥ 1 and per_page 1..50 (default 20); return total only where query cost permits and document any omission. All list filters have allowlisted sort keys and deterministic id tie-break.

Writes with side effects use Idempotency-Key (opaque 16..100 chars), scoped by actor and action, plus a canonical request hash. Replay returns the original outcome. A key reused for a different body returns 409 IDEMPOTENCY_CONFLICT. PATCH/PUT on mutable Need or Offer requires If-Match version; a stale version returns 409 VERSION_CONFLICT with current version, without overwriting. Read responses include version. Every endpoint checks account ACTIVE, feature state, owner/participant policy and DB state independently of Flutter visibility. Private resources return 404 to unrelated users to limit enumeration. Rate limits are policy keys in published settings with lower hard-coded security floors that Admin cannot disable.

### 5.2 Route register

The request and response shapes below are the minimum required fields. Unlisted client-supplied actor IDs and statuses are rejected, not mass-assigned. All GET list endpoints are paginated and use ETag/conditional retrieval where practical.

| Route | Request / validation | Authority and state | Success / principal errors |
|---|---|---|---|
| POST /auth/telegram/start | return_uri allowlisted; optional desired profile scope. | Public; rate-limited by IP/device. | 200 auth_url, attempt_id; 422 URI_NOT_ALLOWED. |
| GET /auth/telegram/callback | code, state from Telegram. | Verify state, nonce, PKCE, signed claims, expiry; single use. | Redirect with handoff code; 401 TELEGRAM_AUTH_INVALID. |
| POST /auth/telegram/exchange | handoff_code. | Single-use, short TTL, bound to attempt. | 200 access_token, expires_in, refresh_token, user; 401. |
| POST /auth/refresh | refresh_token. | Rotation, replay detection, active user. | 200 new token pair; 401 TOKEN_REVOKED. |
| POST /auth/logout | optional all_devices only when reauthenticated. | Auth required. | 204; revoked tokens. |
| GET /auth/me | none. | Auth required. | 200 current profile and effective capabilities. |
| PATCH /profile | full_name, optional consented phone/photo, If-Match. | Self only; input sanitation. | 200 user; 409 version; 422. |
| GET /categories | active=true default. | Public. | 200 list. |
| GET /needs | keyword, category_id, location, budget range, deadline, boosted, sort newest. | Public published OPEN records; no private fields. | 200 paginated. |
| POST /needs | title 5..255, description 20..10000, active category, optional budget/quantity/location/deadline/offer_deadline, currency ETB; required telegram_publication_acknowledged=true after exact public preview; server records consent timestamp. | Auth ACTIVE; NEED_CREATE on; server validates dates and budget relation. | 201 Need; 422 VALIDATION_FAILED; 503 FEATURE_DISABLED. |
| GET /needs/{id} | none. | Public fields for visible Need; owner gets management fields. | 200 Need and offer_count; 404. |
| PUT /needs/{id} | editable fields and public preview re-acknowledgment if materially changed, If-Match. | Owner, OPEN, no need_awards row; material edit after comparison requires new comparison later. | 200 incremented version; 409 STATE_CONFLICT/VERSION_CONFLICT. |
| POST /needs/{id}/cancel | reason, If-Match, Idempotency-Key. | Owner, OPEN, no accepted Offer. | 200 CANCELLED; 409. |
| GET /needs/{id}/offers | page, sort created_at/price. | Owner sees participating Offers; each provider can query only its own via /my/offers. | 200 owner list; 404 private. |
| POST /needs/{id}/offers | offered_price, currency, proposal_message 20..10000, optional delivery_time_text/availability/notes, attachment IDs; Idempotency-Key. | ACTIVE provider ≠ owner; Need OPEN; now < offer_deadline if set; no existing provider Offer. | 201 Offer; 409 OFFER_EXISTS; 422 OFFER_DEADLINE_PASSED. |
| GET /offers/{id} | none. | Owner of Offer or Need owner, with field-level redaction. | 200 appropriate projection; 404. |
| PUT /offers/{id} | price/proposal/delivery/availability/notes, If-Match. | Provider owner; PENDING; Need OPEN; now < offer_deadline_at if set; previous snapshot unaffected. | 200 new version; 409/422 OFFER_DEADLINE_PASSED. |
| POST /offers/{id}/withdraw | reason, If-Match, Idempotency-Key. | Provider owner; PENDING, Need OPEN. | 200 WITHDRAWN; 409. |
| POST /offers/{id}/reject | reason optional; If-Match Need version; Idempotency-Key. | Need owner; PENDING; Need OPEN. | 200 REJECTED; 409. |
| POST /offers/{id}/accept | If-Match Need version; Idempotency-Key. | Need owner; PENDING Offer in OPEN Need; row locks. | 200 accepted Offer and IN_PROGRESS Need; 409 STATE_CONFLICT. |
| POST /needs/{id}/complete | confirmation, If-Match, Idempotency-Key. | Owner; IN_PROGRESS and accepted Offer. | 200 COMPLETED; 409. |
| GET /my/needs and GET /my/offers | page, status. | Auth self. | 200 paginated. |
| POST /needs/{id}/comparisons | include_eligible_offers=true for all when within cap, or explicit offer_ids[] (1..cap) above cap; Idempotency-Key. | Owner; OPEN; ≥1 eligible PENDING Offer; no active comparison; cap and quota checks. Server selects all eligible by default and validates each explicit ID against the current eligible set. | 202 comparison id/version/status/included_count/excluded_count; 409 COMPARISON_PROCESSING; 422 NO_ELIGIBLE_OFFERS / TOO_MANY_OFFERS / OFFER_NOT_ELIGIBLE; 429 AI_QUOTA. |
| GET /needs/{id}/comparisons | page. | Owner; a provider sees only comparisons containing its Offer via /my/comparisons. | 200 history summaries. |
| GET /comparisons/{id} | none. | Owner full projection; included provider redacted own projection; processing status permitted to participants. | 200; 404. |
| GET /comparisons/{id}/results | none. | COMPLETED only; owner full set, provider own result plus offer count and version. | 200; 409 COMPARISON_NOT_READY; 404. |
| POST /comparisons/{id}/retry | Idempotency-Key. | Owner or authorized Main Admin; FAILED with retry allowance, same snapshot. | 202 PROCESSING; 409 RETRY_NOT_ALLOWED. |
| POST /comparisons/{id}/exports | format PDF/XLSX/CSV/TXT; Idempotency-Key. | Owner; COMPLETED; export quota. | 202 export id; 409 NOT_READY; 429. |
| GET /exports/{id} | none. | Owner. | 200 status, expires_at and authorized download link when READY. |
| GET /exports/{id}/download | none. | Owner, READY, unexpired; stream with safe filename. | 200 file; 404/410. |
| GET /offers/{id}/messages | page. | Need owner or Offer provider. | 200 paginated; 404. |
| POST /offers/{id}/messages | content 1..5000, optional attachment ID; Idempotency-Key. | Participant only; messaging enabled; account active; rate limit. | 201 message; 403/429. |
| GET /notifications | page, unread filter. | Auth self. | 200 paginated. |
| POST /notifications/{id}/read | none, Idempotency-Key. | Recipient only. | 200 read_at. |
| POST /needs/{id}/ratings | to_user_id, score 1..5, optional review; Idempotency-Key. | One party to the accepted relationship; Need COMPLETED; one rating per direction. | 201 rating; 409 RATING_EXISTS; 422. |
| GET /boost-packages | none. | Auth; only published active packages/prices. | 200 list with settings version. |
| POST /needs/{id}/boosts | package_id; Idempotency-Key. | Need owner, eligible Need, payments enabled, package active. | 201 PENDING boost/payment and provider checkout instruction; 409 BOOST_ACTIVE; 503. |
| GET /payments/{id} | none. | Payer own status, Admin controlled view. | 200 sanitized status; 404. |
| POST /payments/webhooks/{provider} | provider raw payload/signature headers; no user token. | Signature verification + provider lookup; dedupe by event/reference, amount/currency/purpose check. Late success after FAILED/CANCELLED enters REVIEW_REQUIRED without boost activation. | 200 acknowledged applied/duplicate/review pending; invalid signature 401, mismatch recorded REVIEW_REQUIRED. |
| GET /attachments/{id}/download | none. | Owner/authorized participant and purpose visibility. | 200 streamed file; 404. |
| POST /attachments | multipart file, purpose and parent id; size/type allowlist. | Auth, ownership; quarantine and validation before use. | 201 attachment id; 422 INVALID_FILE; 413 FILE_TOO_LARGE. |
| POST /reports | target type/id, reason, details; Idempotency-Key. | Auth, rate limited. | 201 report. |
| GET /needs/{id}/telegram-publications | page. | Need owner sees per-destination send state, URL only when Telegram returns resolvable public link; Admin sees audit. | 200 paginated; no member/view count claim. |
| POST /needs/{id}/telegram-publication/stop | If-Match, Idempotency-Key. | Need owner or authorized moderator; stop new sends and attempt removal of posted copies; cannot guarantee removal of forwards/screenshots. | 202 removal queued; 409 VERSION_CONFLICT. |

The Admin API is under /api/v1/admin with browser session, CSRF, Admin role and explicit permission per route. Minimum routes: GET /telegram/destinations, /telegram/publications; POST /telegram/destinations, /telegram/destinations/{id}/validate, /telegram/destinations/{id}/pause, /telegram/publications/{id}/retry-or-reconcile (idempotent and restricted); GET /overview, /health, /jobs, /audit, /integrity, /reports, /users, /payments, /settings, /settings/{key}/versions; POST /reports/{id}/resolve, /users/{id}/suspend, /settings/{key}/drafts, /settings/drafts/{id}/validate, /preview, /publish, /settings/{key}/rollback, /recovery/safe-mode, /recovery/feature-flags, /jobs/{id}/retry, /integrity/run, /payments/{id}/reconcile. Critical writes require recent re-authentication, second factor, reason, version precondition and audit. There is no generic database edit/import endpoint.

### 5.3 Request rate defaults

| Action | Initial bound | Scope | Response |
|---|---:|---|---|
| Telegram start/exchange | 5 / 15 minutes | IP plus device/attempt | 429 Retry-After |
| Public browsing | 120 / minute | IP | 429 |
| Create Need or Offer | 10 / hour each | User | 429 |
| Messages | 30 / minute | User | 429 |
| AI comparison | 3 / Need / day and 10 / user / day | Need and user, plus system cost budget | 429 AI_QUOTA |
| Export | 5 / day | User | 429 |
| Payment creation | 10 / hour | User | 429 |
| Admin critical publish | 10 / hour | Admin | 429 |

These are conservative seed values, not claims about measured capacity. Admin may lower or adjust within hard safety bounds after load/cost evidence. Webhooks have a separately bounded network and signature policy so legitimate provider retries are safely acknowledged and deduplicated.

### 5.4 Admin route details

All routes below require an Admin session and CSRF token for writes; each GET is permission-filtered and paginated where it returns a collection. Critical writes require a recent re-authentication proof and second factor. Every write takes a reason and Idempotency-Key; versioned resources additionally require If-Match.

| Route | Input and guard | Response / errors |
|---|---|---|
| GET /admin/overview, /health | None; Admin+. | 200 counts, timestamped component checks; no secret values. |
| GET /admin/users, /reports, /payments, /jobs, /audit | page/per_page, allowlisted status/date filters. | 200 redacted page; 403 out of scope. |
| GET /admin/settings, /settings/{key}/versions | group/risk filters or key. | 200 typed current value and immutable history; secret references masked. |
| POST /admin/changes | proposed_value, base_version, reason; Admin LOW/MEDIUM or Main Admin HIGH/CRITICAL. | 201 draft; 422 schema/dependency; 409 stale base. |
| POST /admin/changes/{id}/validate | No new value; draft owner or Main Admin. | 200 validation report; 409 stale draft. |
| POST /admin/changes/{id}/preview | Validated draft. | 200 affected features, pending work and rollback impact. |
| POST /admin/changes/{id}/publish | Confirmation, recent re-auth, second factor if HIGH/CRITICAL, If-Match. | 200 new published version and audit ID; 409 dependency/version conflict. |
| POST /admin/changes/{id}/rollback | target_version, reason, confirmation, re-auth for risk. | 200 newly published version; never edits older version. |
| POST /admin/users/{id}/suspend | reason, duration/review date; Admin only for non-admin target, Main Admin for privileged target. | 200 status/revocation evidence; 403/409. |
| POST /admin/reports/{id}/resolve | resolution WARN/HIDE/SUSPEND/DISMISS and reason; assigned Moderator+ within scope. | 200 resolution and audit ID; 409 already resolved. |
| POST /admin/payments/{id}/reconcile | provider evidence reference, resolution reason; Main Admin. | 202 verification job, never a direct CONFIRMED setter; 409 invalid state. |
| POST /admin/jobs/{id}/retry | reason; Main Admin or delegated safe notification job class. | 202 retry scheduled; 409 exhausted/unsafe. |
| POST /admin/integrity/run | scope, reason; Main Admin. | 202 report job; 429 when one is running. |
| POST /admin/recovery/safe-mode, /feature-flags | desired mode/flag, reason, impact confirmation; Main Admin only. | 200 published setting version and audit; 409 dependency conflict. |

## 6. Canonical comparison and AI contract

### 6.1 Eligibility and snapshots

A comparison is initiated only by the owner of an OPEN Need. Eligible Offers are those PENDING on that Need at the transaction's server-time cutoff. Withdrawn and rejected Offers are excluded. An Offer submitted exactly at offer_deadline is not accepted. When eligible count exceeds the cap, the first request returns TOO_MANY_OFFERS with the count and requester-only eligible list; the requester may submit an explicit subset of 1..cap IDs after seeing the exclusion notice. The server rechecks the entire set and the selected IDs within a short Need-row-locked transaction. Store selection_policy ALL_ELIGIBLE or REQUESTER_EXPLICIT, selected IDs and excluded count in the immutable Need snapshot and audit. Excluded providers do not receive that version's result; they remain eligible for a later comparison. Then allocate version = max(version_number)+1, copy the Need and all included Offer/credibility facts into snapshots, record canonical SHA-256 hashes, insert comparison PENDING and an outbox work event, commit. No AI network call occurs inside the transaction.

The snapshot includes Need title, description, category, budget/currency, quantity, deadlines; Offer price/currency, proposal, delivery, availability; provider marketplace rating mean/count and completed count as of snapshot time; criteria_version, prompt_version, model_id and timestamp. It excludes phone/address, private attachments, messages, payment details and secrets. An Offer edited after snapshot still belongs to the old version exactly as captured. Compare Again creates a new version from current eligible Offers. Completed version and result rows are read-only.

The job claims the comparison, changes PENDING to PROCESSING with a lease, records comparison_attempts, enforces timeout and cost limits, calls the configured AI adapter, validates the entire response, then commits every result row and the comparison COMPLETED state along with one outbox event and recipient in-app records in a single transaction. The unique key (comparison_id, recipient_user_id, IN_APP) makes duplicate completion harmless. A failed attempt records a safe failure code, retries with bounded exponential delay and jitter on the same snapshot; after the configured maximum it marks FAILED. A user-visible failure includes a retry path and no score. A completed version is never reopened.

### 6.2 Criteria v1, scoring and evidence

Historical criteria v1 below is retained for immutable historical results. New comparisons use evidence-only v2 in AI_Evaluation_Contract.md and criteria-registry.json. Every included Offer in a given version uses the same rubric:

| Criterion | Weight | Evidence | Assessment anchors |
|---|---:|---|---|
| Cost/budget efficiency | 25% | Frozen offered price/currency and Need budget/quantity. | 10: fits stated budget and comparable scope; 1: clearly outside budget or incompatible; unknown budget receives neutral policy score 5 with UNKNOWN label. |
| Provider credibility | 25% | Frozen valid rating mean/count and completed marketplace activity. | 10: substantial relevant verified history; 1: documented serious contradictory history; no history receives neutral 5 and NO_HISTORY label, never a fabricated five-star rating. |
| Proposal completeness/fit | 25% | Frozen Need requirements and proposal text. | 10: clearly addresses all explicit material requirements; 1: clearly misses them; ambiguous or absent detail is called out in missing_information. |
| Delivery/availability | 25% | Frozen delivery text, availability, Need deadline. | 10: explicit, feasible commitment within stated deadline; 1: explicit incompatible timing; absent time/deadline receives neutral 5 with UNKNOWN label. |

For historical v1, the AI returned each criterion's 1..10 assessment, evidence field references, status OBSERVED/INFERRED/UNKNOWN, a concise explanation, strengths, weaknesses, missing_information and risk_notes. The backend checks each referenced field exists in the snapshot, validates scalar ranges and full Offer ID coverage, then computes overall = round half-up(sum of the four criterion scores × 0.25), two decimal places. The AI's suggested total, if supplied, is ignored. Show evidence coverage (number of assessable criteria / 4) next to every total and explicitly label neutral policy scores. A score compares stated fit under this rubric; it is not an award, verified delivery guarantee or price-only ranking. Admin may publish v2 rules with a new criteria version and tests; old comparisons retain v1.

No Boost purchase, submission order, account age, hidden geography or private contact contributes to the four scores. The model may identify an inference but must label it as inference. Provider credibility uses evidence with count; a single rating cannot be portrayed as equivalent to a mature review history. If offer content or AI response attempts prompt injection, it is treated as untrusted data; system rubric and output schema remain authoritative.

### 6.3 AI input/output schema

Input object: comparison_id, criteria_version, prompt_version, Need snapshot, an array of comparison_offer_id plus permitted Offer and credibility snapshot, same rubric and field-reference vocabulary for every Offer. Prompt text instructs no invention, no winner selection, no external knowledge, no private data, no output for unincluded IDs, and JSON only. The model and prompt parameters are published versioned settings; inference temperature is set to the provider's lowest practical deterministic option, with provider behavior documented rather than assumed bit-for-bit reproducible.

Required output per included comparison_offer_id: cost {score,status,evidence_refs,explanation}, credibility {...}, fit {...}, delivery {...}, strengths[], weaknesses[], missing_information[], risk_notes[], fit_explanation. Arrays are bounded (maximum 10 strings each, maximum 500 characters per item); explanations have bounded length and UTF-8. Results array must contain each included ID once and no others. No acceptance, winner or provider private data field is allowed. Validate JSON schema, finite decimal ranges, list cardinality, referential completeness, prohibited keys and evidence refs. Reject malformed or unsupported claims; retry only under policy. Store raw provider response only in a restricted, short-retention debug store with secrets and personal data redacted; store validated result and provenance permanently per retention policy.

Each comparison records provider, model, prompt version, criteria version, schema version, snapshot hash, creation/completion time, attempt count, token usage and cost. Admin settings include AI enable flag, model, max offers, hourly/daily caps, per-user caps, maximum prompt/output size, timeout, retry count and a cost ceiling. If the budget or provider is unavailable, return 503 AI_UNAVAILABLE and preserve existing results. These settings cannot override the requester decision or privacy rules.

### 6.4 Equal notification semantics

The completion transaction establishes one result set, one event ID, and one in-app notification for the requester and each included Offer provider. Every included provider's record has the same event ID and available_at timestamp; no provider receives a new event earlier based on Offer submission order. The provider projection contains only its own detailed result, the comparison version/time, and permitted aggregate offer count. The requester projection contains the full comparison. Telegram delivery, if consented and technically possible, is dispatched from the same event after commit with per-recipient delivery status/retry; differences in external delivery time are measured, never falsely described as simultaneous reading. Failed Telegram delivery does not erase the in-app result or roll back the comparison.

## 7. Roles, permissions and data projections

Requester and Provider are contextual roles available to an ACTIVE user. A requester is the owner of a particular Need. A provider is the owner of a particular Offer on another user's Need. Main Admin, Admin and Moderator are explicit privileged grants. A suspended or banned account cannot initiate business writes, even if it still owns records. Reads needed for payment receipts, appeal or privacy rights use separately controlled paths.

| Action / resource | Main Admin | Admin | Moderator | Requester (own Need) | Provider (own Offer) |
|---|---|---|---|---|---|
| Public Need browse | Yes | Yes | Yes | Yes | Yes |
| Public Need distribution preview/stop | Audited support | Audited support | Moderation stop | Yes, own Need | No |
| Activate/pause partner Telegram destination | Yes, permission and rights proof | Validate/propose; pause for incident | Flag/urgent pause | No | No |
| Create/edit/cancel Need | No impersonation | No | No | Yes, guarded state | As requester on own other Needs |
| Create/edit/withdraw Offer | No impersonation | No | No | Only as provider on others' Needs | Yes, guarded state |
| Read all Offers on Need | Controlled support view | Controlled support view | Report context only | Yes | Own Offer only |
| Read comparison full result | Controlled audited support view | Controlled audited support view | Report context only | Yes | No |
| Read provider own comparison detail | Controlled support view | Controlled support view | Report context only | Only via full owner view | Yes |
| Trigger comparison / retry | Recovery retry only | No | No | Yes | No |
| Accept/reject Offer; complete Need | No impersonation | No | No | Yes | No |
| Message in Offer conversation | No impersonation | No impersonation | Audited report investigation only | Yes | Yes |
| Rate completed relationship | No impersonation | No | No | Yes | Yes |
| Create boost/payment | No impersonation | No | No | Yes | No |
| View payment | All, reason logged | Operational payment view | No | Own sanitized payment | No |
| Resolve/reconcile payment | Controlled workflow | View/flag only | No | No | No |
| Review reports / hide content | Yes | Yes | Yes, bounded | Report only | Report only |
| Suspend user | Yes | Allowed non-admin users | Propose/escalate | No | No |
| Manage categories/content | Yes | Yes | No | No | No |
| Publish LOW/MEDIUM settings | Yes | Yes with reason | No | No | No |
| Publish HIGH/CRITICAL settings, secrets, security, safe mode | Yes with re-auth + second factor | No | No | No | No |
| Inspect audit, jobs, backups, integrity | Yes | Role-scoped read | No except assigned reports | No | No |
| Retry failed jobs | Yes, scoped and audited | Approved nonfinancial notification jobs | No | No | No |
| Export personal data | Controlled, reason logged | Limited | No | Own data via privacy flow | Own data via privacy flow |

An Admin viewing a payment or private conversation is a controlled purpose-bound support action, not an unconditional general read. Provider result projection excludes competitor identity, phone, private address, documents, raw proposal, individual score and precise competitor price; only an anonymized count may be exposed in MVP. Flutter never receives forbidden fields. Object ownership and field projection are tested at query and serialization layers.

## 8. Admin Control Center and settings

### 8.1 Required Admin surfaces

Dashboard (counts and incidents), Telegram Distribution (destinations, permission proof, rights checks, queue, uncertain sends, removals), Health (DB/storage/queue/cron/AI/Telegram/payment/disk), Features, Marketplace (Needs/Offers/categories/reports), AI (rules/model/caps/cost), Payments (records/mismatch/reconciliation), Users, Content, Notifications, Files, Jobs, Backups, Integrity, Security, Audit, Settings and Recovery. Search across users/Needs/Offers/payments/comparisons is permission-filtered, bounded and audited. Exports are queued, size-limited and private, never a direct database import/editor. A visible control is not shown as functional until its backend and verification exist.

### 8.2 Settings catalog

| Key | Type / seed default | Risk | Validation and dependency |
|---|---|---|---|
| feature.needs, feature.offers, feature.messaging | boolean / true | HIGH | Safe mode overrides to false; disabling affects UI, API and service. |
| feature.telegram_publication | boolean / true only after official-channel and at least one authorized public-supergroup rights/consent release gate | HIGH | Stops new scheduling/sends globally; immutable history remains; safe mode overrides. |
| telegram.max_destinations_per_need, telegram.daily_cap_per_destination | integer / 3, 10 initial bounds | HIGH | Bounded by code safety limits; rights/permission and category matching always required. |
| telegram.min_interval_seconds, telegram.max_attempts | integer / 30, 3 initial bounds | MEDIUM | Observe per-chat/global flood responses and retry_after; no claim of guaranteed throughput. |
| feature.ai_compare | boolean / true after provider verification | HIGH | Requires configured AI provider; disabling blocks new comparisons, preserves history. |
| feature.payments, feature.boosts | boolean / false until live provider gate | HIGH | Boosts require payments for new purchases; existing verified callbacks still reconcile. |
| marketplace.max_open_needs_per_user | integer / 20 | MEDIUM | 1..1000. |
| marketplace.offer_deadline_max_days | integer / 90 | MEDIUM | 1..365; server UTC guard. |
| marketplace.max_offers_per_comparison | integer / 20 | HIGH | 1..100; over cap returns explicit error, never silent selection. |
| ai.criteria_version | string / v1 | HIGH | Must refer to published immutable rubric. |
| ai.prompt_version | string / v1 | HIGH | Must refer to reviewed prompt artifact. |
| ai.model_id | string / provider-selected | HIGH | Must pass schema and privacy integration test before publish. |
| ai.max_input_tokens, ai.max_output_tokens | integer / measured deployment seed | HIGH | Provider-compatible, bounded; no fictitious universal number. |
| ai.timeout_seconds, ai.max_attempts | integer / 60, 3 | MEDIUM | Timeout < queue retry_after; attempts 1..5. |
| ai.user_daily_cap, ai.need_daily_cap | integer / 10, 3 | MEDIUM | Nonnegative within code safety floor. |
| payments.provider | string / deployment-selected | CRITICAL | Live adapter/credentials/webhook test required before enabling. |
| boosts.package_prices | managed rows / no implicit price | HIGH | Decimal ETB ≥ 0, reviewed, versioned, new purchases use new price only. |
| uploads.max_bytes, exports.max_rows | integer / host-tested limits | MEDIUM | Never above verified PHP/cPanel limits. |
| content.welcome_am, content.welcome_en | string / reviewed copy | LOW | Bounded, escaped; language keys. |
| privacy.temp_file_days, privacy.export_days | integer / 7, 7 | MEDIUM | Legal/security floor cannot be reduced by Admin. |
| system.safe_mode | boolean / false | CRITICAL | Main Admin re-auth + second factor; recovery reason and impact preview. |

Secret names (Telegram client secret, bot token, AI API key, payment signing secret, DB credentials, app key) are environment/secret references with rotation procedure, never normal settings values or audit before/after plaintext. A missing/corrupt security setting fails closed. A content setting may fall back to a reviewed safe default. Dependencies are validated before publish: boost purchase cannot be enabled without a verified payment adapter; AI compare cannot be enabled with an invalid prompt/schema pairing.

### 8.3 Controlled change lifecycle

Draft → Validate schema/ranges/dependencies → Preview affected features and in-flight work → Publish in transaction (settings current value, immutable setting_version, audit, outbox) → Verify runtime health → Rollback by publishing a new version referencing an older approved value. LOW/MEDIUM changes require an Admin or Main Admin; HIGH/CRITICAL changes require Main Admin, recent re-auth, second factor, reason and explicit confirmation. Concurrent drafts use version preconditions; stale publish returns 409 SETTINGS_VERSION_CONFLICT. The preview for “Payments OFF” must explain that new checkout and new boosts stop, confirmed history remains, existing initiated payment callbacks are still verified/reconciled, and payment-based activation waits safely if safe mode pauses it. No direct edit to immutable historical rows.

Safe mode keeps authorized reads and Admin recovery available. It blocks new Needs, Offers, comparisons, payments, boosts and Telegram publication sends; messaging defaults OFF during incident. A verified payment callback for an already created payment is still accepted and audited. If boost activation is paused, keep the paid boost PENDING with an explicit operational reason and, when recovered, activate its full purchased duration exactly once. Recovery Center offers safe mode, disable AI/payments/new Offers, retry eligible failed jobs, integrity check, view backup evidence and configuration rollback. It has no “delete database” action.

## 9. Flutter screen and navigation contract

| Route/screen | Entry and primary actions | Data/access | Required states |
|---|---|---|---|
| Welcome | Sign in; explain demand-first flow. | Public. | Loading, success, auth failure, offline. |
| Telegram Login | OIDC/native handoff, consent scope. | Public → authenticated. | Starting, awaiting Telegram, expired, denied, retry. |
| Profile Setup/Profile | Edit own name/photo/optional phone; role context. | Self only. | Loading, empty fields, saved, stale version, error, offline. |
| Home/Search/Browse Needs | Search, filters, paginated cards, boost label. | Public Need projection. | Loading, empty, list, error/retry, offline cached label. |
| Create/Edit Need | Form, attachments, optional offer deadline; required public-distribution acknowledgment with exact preview and stop explanation. | Auth requester, OPEN for edit. | Draft, validating, uploading, saving, saved, permission/state conflict, offline draft. |
| Need Details/My Needs | Show Need/status/offer count; owner can edit/cancel/compare/complete/boost and inspect/stop external publication. | Public vs owner projection. | Loading, empty Offers, publication queued/posted/uncertain/removal pending, processing comparison, completed, error, offline. |
| Submit/Edit Offer/My Offers | Price/proposal/time/availability/attachments, withdraw. | Provider on other user's OPEN Need. | Draft, uploading, submitting, success, duplicate/deadline/state conflict, offline draft. |
| Offer Details | Owner views accepted Offer and messages; provider views own status. | Participant projection. | Loading, permission denial, accepted/rejected/withdrawn, error, offline. |
| Compare Confirmation | Show eligible count, four criteria, cap, advisory notice; above cap allow explicit selection and disclose excluded count. | Need owner. | Ready, zero Offers, over cap/selection, quota, processing, retry. |
| AI Comparison | Full owner result; provider own score/coverage and permitted count. | Role-specific API projection. | Queued, processing, failed/retry, completed, permission denied, offline last stored result. |
| Comparison History/Export | Version list; select stored result; request export. | Owner; provider own participation list. | Loading, empty, ready, export pending/failed/expired, offline. |
| Messages | One conversation per Offer. | Two participants only. | Loading, empty, sending, sent, failed/retry, offline draft. |
| Notifications | Paginated in-app list and read state. | Recipient only. | Loading, empty, unread, error/retry, offline last sync. |
| Boost/Payments | Package/price review, checkout handoff, verified status. | Need owner. | Awaiting payment, pending verification, confirmed/active, failed, review required, offline. |
| Rating | Post-completion 1..5 and optional review. | Completed parties only. | Eligible, submitted, already rated, permission denied, offline draft. |
| Report/Support | Report content, request ID for support. | Auth. | Form, submitted, validation error, offline draft. |

Navigation: Welcome → login → Home; Home tabs Browse, My Needs, My Offers, Notifications, Profile. Need Details leads to Submit Offer for another user's Need or Offer list/Compare/Boost for owner. Comparison History is reachable from Need Details. Messages is reachable only from an Offer. Deep links must resolve authorization afresh. Every network-dependent screen exposes loading, empty, success, error/retry, denied and offline states as applicable. Offline writes are drafts only; the app never displays an unverified payment, accepted Offer or AI result as final. Disable duplicate taps locally and enforce server idempotency regardless.

Accessibility: semantic labels and focus order, minimum practical touch targets, text scaling, contrast, screen-reader status updates and localized Amharic/English strings through translation keys. Errors include a human message and request_id; internal traces are absent. Upload progress and background job progress are honest states, not fake percentages.

## 10. Security, privacy and retention

Authentication: verified Telegram OIDC subject and server-issued app tokens, secure cookies for Admin, rotation/revocation, short expiry, replay protection, account status checks and audit. Use the current official Telegram protocol verification rules at implementation time. For Admin critical publishing, require a second factor and recent re-authentication; lost-factor recovery is a controlled, audited process, not a secret bypass.

Authorization: default deny; Policies on every route and job; ownership and participant checks in service; redacted serializers; Admin scope checks; private file delivery after authorization. CSRF protects cookie-authenticated Admin writes; bearer-token mobile APIs validate origin/token according to their mode. Use ORM/prepared parameters, length/type validation and safe output escaping. Apply HTTPS, secure headers, CORS allowlist, request size limits, action-based throttles, safe error handling and secret redaction. Webhook requests require provider signature or documented server-to-server verification, replay/event dedupe, merchant/reference/amount/currency matching, and no client-origin confirmation. A payment mismatch is REVIEW_REQUIRED and cannot activate a boost.

Files: allowlisted media/document MIME detected from file bytes, extension cross-check, size and count limits, random storage key, executable blocking, private/public separation, malware scanning or quarantine policy appropriate to host, safe disposition and participant download authorization. The original filename is display-only. Exports are private, time-limited and generated from stored results. Do not send private phone, address, files, messages, payment credentials or secrets to the AI provider. Classify Need public fields as PUBLIC, messages/contact as PRIVATE, payment details as SENSITIVE, credentials as SECRET.

Retention: temporary uploads and exports are cleaned by schedule according to published settings and hard minimums. Historical comparisons, payment events, ratings and audit records are archived under an explicit retention/legal policy; no routine hard delete breaks FK or evidence. User deletion/privacy requests require a documented review, purpose-based data minimization, anonymization where permitted and preservation of legally required transaction records. Admin operational exports log purpose, actor, filter, row count and expiry. The final jurisdiction-specific retention schedule is a deployment governance input; no invented legal period is asserted here.

## 11. Reliability, cPanel deployment and recovery

### 11.1 Jobs, concurrency and observability

Use Laravel's database queue and one-minute scheduler cron. The scheduler invokes bounded, short-lived queue workers under non-overlap control appropriate to the hosting account; do not rely on a permanent process unless the host explicitly supports one. Set job timeout shorter than database queue retry_after, keep external HTTP timeouts lower still, and test lease recovery by killing a worker. Outbox records and idempotent consumers prevent lost business events and duplicate effects. Process comparison, notifications, exports, boost expiry, payment reconciliation and cleanup separately with bounded quotas. A dead job is visible in Admin with attempts, safe error, next retry and a guarded retry action.

Health checks report DB, storage, queue lag, cron last-run, AI reachability, Telegram reachability, payment adapter, disk and last verified backup. External provider failure is DEGRADED, not a false zero result. Correlate request_id across API, job, outbox and audit. Do not expose credentials in logs. Alerts use available email/Admin notices; no Prometheus/Grafana/Kubernetes stack is required. Run scheduled integrity checks for orphaned rows, multiple accepted Offers, unmatched payments, missing files, incomplete comparison result counts, missing participant notifications and corrupt settings.

### 11.2 Deployment layout and environment

Host the Laravel application outside the public web root; point the domain/subdomain document root only at Laravel public/. If cPanel cannot set the document root safely, deployment is blocked until a tested equivalent layout is available. Use a compatible PHP runtime/extensions, Composer production dependencies, MySQL/MariaDB InnoDB with enforced FKs/CHECK behavior, TLS, writable storage and bootstrap/cache, private uploads, sufficient cron/CLI resources and outbound HTTPS to Telegram/AI/payment providers. Verify actual limits in the selected hosting account; never assume that a generic cPanel account supports queue throughput or long AI jobs.

Required environment variables include APP_ENV=production, APP_DEBUG=false, APP_KEY, APP_URL, DB_*, CACHE_STORE, QUEUE_CONNECTION=database, SESSION_*, Telegram OIDC client ID/secret/redirect, bot token for required distribution, AI provider key/model, payment provider credentials/webhook secret, private storage disk and backup target credentials. Set via protected environment or secret files outside public; never commit .env. Configure the selected payment webhook URL and Telegram allowed redirect URL in provider consoles. Bot posting rights in configured destinations are a launch prerequisite; phone scope remains optional explicit consent.

Deployment sequence: build/test in non-production; take verified external DB/file/config backup; put risky writes into maintenance/safe mode as policy; deploy versioned code; run preflight; apply additive/backward-compatible migrations; run config/route optimizations; restart/drain compatible workers; smoke test auth, Need/Offer, AI sandbox, payment sandbox, notification, Bot API send to the owned channel and an authorized public supergroup, Admin health and private file access; release write switches; record release ID and health evidence. Destructive schema removal is a later separate release after old code no longer depends on it. For code rollback, switch to the previous compatible release and revert feature/config publication; do not blindly reverse a destructive migration. Restore in an isolated environment first if data recovery is needed.

A one-minute scheduler entry is configured with the correct account PHP path and absolute app path to invoke artisan schedule:run; its stdout/stderr go to a protected, rotated log. The exact path is discovered on the target host, not copied from an example. Database queue migration and failed-job storage are installed. The process manager/cron is tested against provider timeout and host limits before live launch.

### 11.3 Backup and disaster recovery

External encrypted backups include DB, private attachments, settings versions, audit/outbox data and the deployment manifest/secret recovery procedure. Keep keys separate from backups. Validate file presence, nonzero size, checksum and retention, and periodically restore into an isolated environment, checking row counts, FK integrity, file availability and a representative payment/boost/comparison path. Initial measurable target: RPO ≤ 24h, RTO ≤ 8h; a timed restore drill must prove it. Payment events after the restored point are reconciled from provider evidence before boosts or ledger views are declared complete. Recovery levels: ordinary job retry; DB restore; full app/files restore; critical off-host recovery. Admin shows last backup age/status, last drill and whether targets were met. Safe mode and provider kill switches remain available during recovery.

## 12. Test and acceptance matrix

| Test ID | Scenario and expected proof | Layer |
|---|---|---|
| T01 | Provider creates an Offer for another user's OPEN Need; owner self-offer, duplicate and expired deadline are denied. | API, policy, DB |
| T02 | Two simultaneous acceptance requests for different Offers yield exactly one need_awards row, one accepted Offer and one IN_PROGRESS Need; direct duplicate insert and cross-Need award fail PK/composite FK; losing request gets 409. | Concurrency, DB |
| T03 | Stale If-Match cannot overwrite Need/Offer; version increments once. | API, DB |
| T04 | Offer edit/new Offer after comparison cannot change old snapshot or result; Compare Again makes N+1. | Comparison, DB |
| T05 | Same four criteria, weights and source vocabulary used for every included Offer; boost/arrival order absent. | AI fixture, schema |
| T06 | Unknown rating/budget/delivery facts are labeled, no invented provider fact or fake score appears. | AI adversarial |
| T07 | Malformed JSON, missing/extra Offer IDs, out-of-range scores, invalid evidence refs and prompt injection fail safely. | AI validation |
| T08 | AI timeout/retry retains snapshot; exhausted attempts mark FAILED with zero published results; successful retry completes once. | Jobs, API |
| T09 | Completion creates one result set, one event, all participant in-app notifications; retry causes no duplicate. | DB, outbox |
| T10 | Provider A cannot fetch provider B result, contact, attachment, message or export using guessed IDs. | Security |
| T11 | Forged client paid status, invalid webhook signature, wrong amount/currency/reference and duplicate callback cannot duplicate boost. | Payment |
| T12 | Verified pending callback arriving during payments OFF/safe mode is retained/reconciled and paid duration activates once after recovery. | Payment, recovery |
| T13 | Ratings require COMPLETED Need and correct party pair; duplicate and self-rating rejected; zero ratings display unknown. | API, DB |
| T14 | Feature OFF blocks UI entry, API write and job business action while preserving history. | Admin, API, Flutter |
| T15 | Admin critical publish requires role, recent re-auth, second factor, reason, version guard and audit; rollback makes a new version. | Admin, security |
| T16 | Private executable upload, MIME spoof, oversize, traversal and unauthorized download are denied. | File security |
| T17 | Signed Telegram login validates state/PKCE/nonce/issuer/audience/expiry; replay and cross-account handoff fail. | Auth |
| T18 | Queue crash and duplicate outbox delivery leave exactly one notification/payment business effect. | Reliability |
| T19 | Page limits, allowlisted sort, rate limits and AI cost caps hold under load. | Performance |
| T20 | Restore from external backup in isolated target meets measured RPO/RTO, integrity and representative core flow. | Operations |
| T21 | Code rollback after additive migration runs old compatible release; destructive change is gated. | Deployment |
| T22 | Flutter loading/empty/error/offline/permission states and Amharic/English accessibility are exercised on representative screens. | Mobile |
| T23 | Request ID joins API error, job, audit and Admin incident view without secret leakage. | Observability |
| T24 | Export PDF/XLSX/CSV/TXT matches stored version and does not call AI. | Export |
| T27 | Unknown public group or expired permission is rejected; channel lacks can_post_messages and group bot is muted, so both pause. | Telegram integration |
| T28 | Creation requires public-distribution acknowledgment; preview excludes phone, address, private attachment and provider details; deep link lands on current Need. | Privacy, Flutter |
| T29 | Duplicate events, 429 retry_after, permission loss and network timeout produce bounded queue effects; uncertain sends do not blindly repost. | Queue, Bot API sandbox |
| T30 | Cancellation/owner stop halts queued sends and attempts deletion; retained external forwards and failed deletion are reported accurately. | API, Admin |
| T31 | External distribution and boost do not change snapshot eligibility, criteria, scores or requester acceptance authority. | AI regression |
| T25 | Authenticated late payment success after FAILED/CANCELLED is recorded once as REVIEW_REQUIRED; no boost activates until audited reconciliation. | Payment, recovery |
| T26 | Offer edit at or after deadline is denied, while permitted PENDING withdrawal remains available. | API, state |

Release evidence must include automated results and manual integration proof for the actual Telegram identity, AI provider, selected payment sandbox/live path, cPanel cron/queue, external backup and restore. A passing local unit test is not evidence that those external integrations work in production.

## 13. Final traceability matrix

The matrix maps every numbered rule of the S2 “DO NOT BREAK” contract to a database artifact, enforcing service/API, user or Admin surface, and a test. A dash means the surface has no direct enforcement role, not that the rule is optional. The named test must pass before the row can be marked implemented.

| Rule | DB evidence | Backend / API enforcement | Flutter / Admin visibility | Test |
|---|---|---|---|---|
| C01 Demand comes first | needs FK from offers | POST Offer requires OPEN Need | Need → Submit Offer | T01 |
| C02 Providers submit Offers | offers.provider_id | Provider policy, POST /needs/{id}/offers | Submit Offer | T01 |
| C03 Requester final decision | need_awards, audit | POST /offers/{id}/accept owner only | Accept confirmation | T02 |
| C04 AI analyzes, never decides | comparison_results separate from acceptance | AI schema forbids award action | Advisory notice | T05, T07 |
| C05 Fixed snapshot | comparisons.need_snapshot, comparison_offers | Snapshot transaction/hash | Version detail | T04 |
| C06 Version per comparison | UNIQUE need_id/version_number | Need lock + allocator | History version | T04 |
| C07 Historical immutability | insert-only results/snapshots | No update route, guarded models | Read-only old result | T04 |
| C08 Equal result notification | outbox event + UNIQUE recipients | Atomic completion fan-out | Same comparison-ready event | T09 |
| C09 Private provider data protected | private attachments, field scopes | Redacted serializers/download policy | Own result only | T10 |
| C10 Server-verified payment | payments, payment_events | Signed callback and provider reconciliation | Pending vs confirmed/review | T11, T25 |
| C11 Idempotent effects | idempotency_keys, unique events | Replay request/callback returns prior effect | Duplicate tap protection | T11, T18, T25 |
| C12 Critical transactional changes | Need/Offer/Payment/outbox rows | Accept and confirmation transactions | Consistent status | T02, T11 |
| C13 No contradictory concurrent states | need_awards PK, version, unique keys | Row locks, If-Match, conflict 409 | Refresh on conflict | T02, T03 |
| C14 Server authorization | ownership FKs, role grants | Policies on API/jobs/files | Permission denied | T10 |
| C15 Settings cannot bypass security | typed settings and schemas | Hard code invariant floors; fail closed | Admin validation error | T14, T15 |
| C16 Critical Admin changes audited/reversible | setting_versions, audit_logs | Draft/validate/preview/publish/rollback | Impact preview/history | T15 |
| C17 Secrets separated | secret reference only | Protected environment/rotation | Masked Admin display | T15, T23 |
| C18 External restorable backups | backup manifest and audit evidence | Off-host backup, isolated restore | Last drill/status | T20 |
| C19 Failed jobs recoverable | jobs, failed_jobs, attempts | Lease, retry, outbox dedupe | Recovery jobs view | T08, T18 |
| C20 AI failure creates no fake result | comparison FAILED, zero result rows | Schema gate before completion | Honest failure/retry | T07, T08 |
| C21 Integrity can be checked | FKs, unique keys, hashes | Scheduled/on-demand scanner | Integrity report | T19, T20 |
| C22 Production rollback | release/migration manifest | Additive migrations and previous release | Admin release health | T21 |
| C23 No silent core mutation | audit, version fields, immutable snapshots | Controlled transition services | History/change notices | T03, T04 |
| C24 Errors hide secrets | safe audit metadata | Exception mapper/redaction | User request ID only | T23 |
| C25 cPanel target | DB queue tables, files | Cron, bounded workers, safe paths | Health/backup view | T20, T21 |
| C26 No unnecessary infrastructure | relational DB/queue | Monolith REST and simple search | Simple app navigation | Architecture review |
| C27 New feature proves product value | versioned release decision | Feature gate/impact test | Admin feature review | Change-control review |
| C28 Complexity needs justification | module ownership/register | ADR plus measurable evidence before new infra | Admin impact record | Architecture review |

Acceptance of this matrix requires an implementation link or migration/test ID for each populated cell, not merely a check mark in a design document. Any discovered contradiction is classified as GAP, UNKNOWN or REQUIRES EVIDENCE; unknown capability is not automatically missing. The change owner records evidence and resolution before declaring a rule complete.

## 13.1 Telegram distribution traceability extension

| Rule | DB evidence | Backend / API enforcement | Flutter / Admin visibility | Test |
|---|---|---|---|---|
| C29 Authorized destinations only | destinations permission and rights evidence | Check ACTIVE, rights and permission at queue and send | Admin destination review and pause | T27 |
| C30 Public Need consent/redaction | Need acknowledgment and immutable publication payload | Public serializer, moderation, no private fields | Requester preview/stop | T28 |
| C31 Honest send state and bounded retries | publications/events, unique version key | Outbox, per-chat pacing, retry_after, uncertain reconciliation | Owner status, Admin incident | T29 |
| C32 Stop and removal | publication tombstone and event | Recheck before send; request deletion after cancellation/owner stop | Stop action and removal status | T30 |
| C33 Neutral distribution | no scoring link to publication/boost | No destination metrics in AI eligibility or score | Comparison unchanged | T31 |

## 14. MVP boundary and delivery sequence

| Stage | Deliverable | Exit gate |
|---|---|---|
| Phase 1 — marketplace foundation | Telegram auth, user profiles, categories, Need create/browse/edit/cancel, Offer submit/edit/withdraw/accept/reject, basic messages, in-app notifications, minimal Admin moderation/settings/audit/health and security controls. | T01–T03, T10, T14–T17 and core mobile states pass. |
| Phase 2 — core differentiated MVP | Comparison snapshot/version/history, same criteria, validated AI, equal notification, requester full/provider own result, retries/cost guards, Admin AI controls and audit. | T04–T09, T18–T19; real provider integration and privacy proof. Public MVP claim requires Phase 1 + Phase 2 + the mandatory Telegram distribution launch gate. |
| Phase 3 — monetization and export | Configurable 1/3/7-day boost packages, one selected live local payment adapter, verified callbacks/reconciliation, paid boost lifecycle, PDF/XLSX/CSV/TXT stored-result export, external backups and restore drill. | T11–T12, T20–T21, T24; payment provider sandbox and live evidence. |
| Phase 4 — completion and operations | Completion ratings, broader Admin reports/search/export, controlled recovery and optional scheduled settings after explicit design/test. | T13, T15, T22–T23 and release operations evidence. |
| Required distribution launch gate — Phase 1/2 | Official owned channel plus at least one public partner supergroup with written administrator authorization and verified bot membership/posting permission; automatic approved Need posts, redaction, owner disclosure and Admin controls. | T27–T31 pass and real sends to both destination types are recorded before public launch; Telegram outages queue/retry without corrupting Need/Offer/comparison. |
| Future, evidence-gated | Wider authorized destination network, semantic search, provider recommendations, larger analytics, external object storage, alternative queue infrastructure. | Demonstrated usage/host bottleneck, impact and migration plan. |

Do not build commission, escrow, wallet, subscriptions, social feed, voice/video chat, blockchain, Kubernetes, microservices, Kafka, GraphQL, vector database, Elasticsearch, Redis dependency or complex map infrastructure as part of this baseline. A future feature requires measured product value and its own versioned architecture decision. The locked Need → Offers → equal AI comparison → requester decision flow remains intact.

## 15. Release and handoff checklist

The implementer hands over source, migration order, API schema, generated route list, Admin setting registry, prompt and criteria artifacts, test report, threat/permission tests, sample redacted logs, provider sandbox proof, cPanel deployment and rollback runbook, backup/restore drill evidence, and a completed traceability matrix with links to actual code/tests. The following release gates are mandatory:

1. Database migration on the selected MySQL/MariaDB host proves FK, CHECK/unique behavior and the accepted-Offer concurrency guard.
2. Telegram OIDC integration proves signature, issuer/audience/expiry/nonce/state/PKCE and single-use handoff on Android/iOS routes.
3. Selected AI provider passes output schema, no-invention/privacy, budget/timeout and failure tests with the pinned model/prompt/criteria.
4. Selected payment provider passes signature/verification, duplicate callback, mismatch, reconciliation and safe-mode tests with real provider sandbox evidence.
5. cPanel cron/database queue processes work within the host limits, recovers a killed worker and does not run overlapping unsafe tasks.
6. Private storage, authorized download and all four export formats pass security/content checks.
7. Backup is encrypted externally, restored in isolation, verified and timed against RPO/RTO; rollback is exercised with compatible migrations.
8. Admin critical change lifecycle, audit integrity, safe mode and feature dependencies pass.
9. Flutter route/state/accessibility/localization coverage and core flow regression pass.
10. Before public launch: verify an owned channel and at least one administrator-authorized public supergroup, actual bot membership/posting rights, requester public-distribution acknowledgment and redaction, queue pacing/uncertain reconciliation, cancellation/removal behavior, and Admin stop controls with T27–T31.
11. No source contract C01–C33 is marked MET without a specific implementation and test evidence reference.

## 16. Source and integration references

**User-provided authoritative baselines**

- S1: Demand-First Marketplace App — Complete System Design v4.0 (attached as Pasted text.txt, 2026-09-28).
- S2: FINAL BASELINE FREEZE (attached as Pasted markdown.md, 2026-09-28).
- S3: Final Hardened Baseline / quality layers (attached as Pasted markdown (2).md, 2026-09-28).

**Official integration references checked 2026-09-28**

- Telegram Bot API sendMessage/getChatMember, channel posting rights, ResponseParameters.retry_after: https://core.telegram.org/bots/api
- Telegram Bot FAQ broadcast limits: https://core.telegram.org/bots/faq
- Telegram Bot Platform Developer Terms, unsolicited messages: https://telegram.org/tos/bot-developers

- Telegram Login / OIDC, Authorization Code with PKCE, token validation: https://core.telegram.org/bots/telegram-login
- Laravel database queues, retries, worker options: https://laravel.com/docs/12.x/queues
- Laravel scheduler and one-minute cron: https://laravel.com/docs/12.x/scheduling

The implementer pins actual Laravel/PHP/MySQL/MariaDB and provider versions in a deployment manifest and verifies the relevant official provider documentation again before production integration. This design does not claim access to the user's payment account, Telegram bot configuration or cPanel host.

## 16.1 Authorized Telegram public distribution contract

**Purpose and boundary.** The required acquisition channel advertises a Need to Telegram users who have not joined the app. It is a public projection and deep link to the canonical Need, not a second marketplace. Need creation succeeds independently of external delivery. Telegram login and bot posting are separate credentials and services. Do not replace the Laravel monolith with Telethon/Pyrogram user-account automation; use the official HTTPS Bot API from bounded Laravel jobs. Public group/channel counts (including 5,000–10,000 or 1,000+) and “tens of thousands of views” are unverified hypotheses, not capacity or reach promises. An owned channel username is acquired/configured separately; example handles are not reserved facts.

**Eligibility and consent.** Public Need creation requires a clearly presented external-publication preview and affirmative acknowledgment; the server records its timestamp. The app does not silently post a private draft. Once published, eligible public Needs are automatically queued for the official channel and relevant authorized public supergroups; the requester can stop subsequent distribution and request removal of known posts. The public post contains an approved short title, category, coarse location if provided and consented, broad budget only if chosen, publication/expiry context, and a stable deep link to the public Need page or app route. Exclude identity/contact, exact address, private messages, files, Offers and AI results. Moderation/classification checks apply before queueing. Destination must be ACTIVE, compatible with category/location and consent scope, have recorded administrator authorization and currently adequate bot rights. Owned official channel requires channel administrator can_post_messages; partner channels do too, while partner supergroups require posting permission under group policy. Chat public visibility does not grant bot posting rights. Admin records permission and expiry; no automatic joining, harvesting or direct messages to members.

**Canonical workflow.** Need commit with distribution acknowledgment → moderation/public-preview approval → outbox event → destination matching and unique publication rows → queue worker rechecks Need OPEN/not archived/not stopped, recorded acknowledgment, destination authorization/rights and caps → sendMessage with the approved snapshot and safe deep link → record returned chat/message IDs and Telegram acceptance. A Need edit increments publication_version only for a materially changed public projection; existing Telegram messages can be edited where rights allow or removed and replaced under destination policy, with status/history retained. Cancellation, suspension, moderation removal or owner stop halts pending jobs and queues deletion of known posts; old forwards/screenshots may persist outside our control. External post must identify the app and avoid “verified provider” or AI claims. An external response opens the current Need in the app; Offer creation still requires verified provider authentication and normal state/deadline checks.

**Reliability and operations.** Launch with the official channel and at least one manually vetted public partner supergroup; add further groups only with recorded administrator approval. Per-chat and global token buckets use conservative configurable bounds, quiet hours and platform retry_after; apply exponential backoff with jitter for transient errors. Permission loss and bans pause the destination. A timeout after send may have delivered a post: mark UNCERTAIN, inspect known message evidence or require Admin reconciliation before reposting, because Telegram sendMessage has no business idempotency key. A 429 is not permission to evade a platform limit. Maintain a global kill switch, complaints/owner-stop monitoring, delivery ledger and bounded daily capacity. Measure only accepted sends, failed sends, deep-link opens and attributed app signups/Offers with privacy-safe tracking; do not equate group membership with unique impressions or reads. Admin can preview, pause, investigate and reconcile; every action is audited. Telegram outage never blocks core Need publication in the app.

**Source authority.** Official Telegram Bot API describes sendMessage, posting rights and retry_after; official Bot Developer Terms prohibit unsolicited spam. Before enabling any partner destination, obtain group administrator permission, have its administrator add/approve the bot as needed, and demonstrate actual membership and posting rights in that chat. The concrete legal/partner permission record is a release prerequisite, not inferred from a group's public status.

## 17. Baseline lock and change control

The product identity, demand-first flow, requester authority, equal versioned comparison, private provider boundary, zero commission and simple cPanel-friendly monolith remain locked. To alter them, create a dated architecture decision with product impact, migration strategy, threat/privacy assessment, backward compatibility, traceability update and regression evidence, then publish a new specification version. An AI prompt edit, Admin setting change or implementation convenience is never an implicit authorization to change these rules.


## 18. Canonical Flutter screen crosswalk — revision 1.4

This appendix expands the 16 grouped route families in §9 into **22 named mobile screens** for design and implementation. The groups in §9 remain the product/API contract; the 22 rows below are their presentation routes and do not add product capabilities. The 22-screen count excludes the app-startup/splash loading frame (a bootstrap state), optional three-step onboarding (not approved for MVP), and confirmation bottom sheets (overlays listed below). No OTP screen is part of Telegram OIDC.

### 18.1 Count and crosswalk

| FDS route family (§9) | Flutter screen IDs |
|---|---|
| Welcome | UI-01 Welcome |
| Telegram Login | UI-02 Telegram sign-in |
| Profile Setup/Profile | UI-03 Profile |
| Home/Search/Browse Needs | UI-04 Browse Needs |
| Create/Edit Need | UI-05 Create/Edit Need; UI-06 Public-post preview; UI-07 Need-created confirmation |
| Need Details/My Needs | UI-08 Need Details; UI-09 My Needs; UI-22 Telegram publication status/stop |
| Submit/Edit Offer/My Offers | UI-11 Submit/Edit Offer; UI-13 My Offers |
| Offer Details | UI-12 Offer Details; UI-10 Received Offers is the Need-owner list projection |
| Compare Confirmation | UI-14 Compare confirmation and explicit over-cap selection |
| AI Comparison | UI-15 AI comparison result |
| Comparison History/Export | UI-16 Comparison history/export |
| Messages | UI-17 Messages |
| Notifications | UI-18 Notifications |
| Boost/Payments | UI-19 Boost/Payments |
| Rating | UI-20 Rating |
| Report/Support | UI-21 Report/Support |

The original 22-entry concept list included Onboarding and omitted My Offers. Revision 1.4 removes Onboarding from the MVP count and adds My Offers because `GET /my/offers` is a canonical user flow. Onboarding may be proposed later as a separately approved UX choice. Received Offers is the requester’s view for one Need; My Offers is the provider’s own cross-Need list. They are different projections and must not be merged into one ambiguous role view.

### 18.2 Screen and state acceptance register

Every network-backed screen supports, where applicable: loading, content/success, empty, validation, recoverable error with retry, permission/state denial and offline. Inapplicable states are not shown as fake banners. Offline mutations remain local drafts and are never labeled submitted. Background work shows server-returned status, not invented progress.

| ID | Screen | Primary API / fields | Screen-specific acceptance states |
|---|---|---|---|
| UI-01 | Welcome | Public; no business read required. | Initial/loading, ready, sign-in handoff failure, offline. |
| UI-02 | Telegram sign-in | `POST /auth/telegram/start`; system-browser callback and `POST /auth/telegram/exchange`. | Ready, opening browser, awaiting callback, denied, expired, replay/invalid handoff, retry, offline. No OTP. |
| UI-03 | Profile | `GET /auth/me`; `PATCH /profile` with `If-Match`. Map `full_name`, optional `phone_number`, `profile_photo_url`, status and version; locale preference is local unless a server field is separately specified. | Loading, current profile, validation, saved, stale version, suspended, error, offline draft. |
| UI-04 | Browse Needs | `GET /categories`; paginated `GET /needs`. Map only public projection: `id`, `title`, category name, permitted `location_text`, budget/currency, created time, `offer_count`; boost badge is derived from active, unexpired boost. | Loading, content/pagination, no matches, invalid filters, error/retry, offline cached with freshness label. |
| UI-05 | Create/Edit Need | `POST /needs`; `PUT /needs/{id}` with `If-Match`. Fields per §5: title, description, category, optional coarse location/budget/quantity/deadlines and required `telegram_publication_acknowledged=true`; edit requires preview re-acknowledgment after material public-field change. | Local draft, field validation, attachment upload, preview required, saving, saved, stale version/state conflict, feature unavailable, offline draft. |
| UI-06 | Public-post preview | Uses exact proposed public projection before Need submission; no new endpoint assumed. | Preview ready, excluded-private-data explanation, acknowledgement unchecked/checked, validation blocked, changed preview invalidates earlier acknowledgement. |
| UI-07 | Need-created confirmation | Result of `POST /needs`; map returned Need ID, status and publication queue summary if supplied. | Confirmed created, publication queued/partial failure/uncertain where returned; never equate accepted send with views. |
| UI-08 | Need Details | `GET /needs/{id}`; public projection vs owner projection. Map status, version, permitted Need fields, offer count and owner actions. | Loading, public/owner view, no Offers, completed/cancelled, owner action confirmation, not found/denied, offline cached with timestamp. |
| UI-09 | My Needs | Paginated `GET /my/needs`; map owner-only status, counts, updated time. | Loading, list/filter, empty, pagination, error/retry, offline cached. |
| UI-10 | Received Offers | `GET /needs/{id}/offers`; requester only. Map Offer ID, provider projection, price/currency, proposal, delivery/availability, rating mean/count (unknown remains “No ratings yet”), status and version. | Loading, list, empty, comparison cap/selection entry, accepted/rejected states, no access, error/offline. |
| UI-11 | Submit/Edit Offer | `POST /needs/{id}/offers`; `PUT /offers/{id}` with version. Map `offered_price`, currency, proposal, optional delivery/availability/notes and attachment IDs. | Draft, validation, uploading, submitting, success, duplicate Offer, deadline reached, state/version conflict, suspended, offline draft. |
| UI-12 | Offer Details | `GET /offers/{id}`; participant-only `GET /offers/{id}/messages`; requester acceptance/rejection actions use canonical routes. | Loading, owner/provider redacted projection, pending/accepted/rejected/withdrawn, acceptance confirmation, permission denied, error/offline. |
| UI-13 | My Offers | Paginated `GET /my/offers`; owner’s Offer status across Needs, no competitor/private fields. | Loading, list/status filters, empty, stale/terminal state, error/retry, offline cached. |
| UI-14 | Compare confirmation | `GET /needs/{id}/offers` for eligible set; `POST /needs/{id}/comparisons` with all eligible or explicit `offer_ids[]` over cap. | Ready, no eligible Offers, within cap, over-cap explicit selection with included/excluded counts and disclosure, quota, already processing, retryable conflict. |
| UI-15 | AI comparison result | `GET /comparisons/{id}` and `/results`; role-specific projections. Map version/status, each criterion score/status/evidence refs/explanation, overall backend score, evidence coverage, missing information, risk notes and timestamp. | Queued, processing, completed, failed/retry (no score), requester full result, provider own result only, denied, offline last stored result. Requester decides; no “AI-selected winner” wording. |
| UI-16 | Comparison history/export | `GET /needs/{id}/comparisons`; `POST /comparisons/{id}/exports`; `GET /exports/{id}` and authorized download. | Loading, empty, completed versions, export queued/ready/failed/expired, retry as allowed, denied, offline. Export uses stored result; does not rerun AI. |
| UI-17 | Messages | `GET/POST /offers/{id}/messages`; participant only. | Loading, empty, sending, sent, validation/rate limit, retry, offline draft, denied. |
| UI-18 | Notifications | `GET /notifications`; `POST /notifications/{id}/read`. | Loading, unread/read, empty, marking-read, error/retry, offline last sync. A record is not proof a message was delivered/read externally. |
| UI-19 | Boost/Payments | `GET /boost-packages`; `POST /needs/{id}/boosts`; `GET /payments/{id}`. Amounts come from published package data only. | Loading, no packages/disabled, checkout handoff, pending verification, confirmed/active, failed, review required, expired, offline. Never show “paid” from client assertion. |
| UI-20 | Rating | `POST /needs/{id}/ratings`; completed parties only. | Eligible, form validation, submitted, already rated, Need not complete, denied, retry/offline draft. |
| UI-21 | Report/Support | `POST /reports`; map returned report reference/request ID. | Form, validation, submitting, submitted, rate-limited, failed/retry, offline draft. |
| UI-22 | Telegram publication status/stop | `GET /needs/{id}/telegram-publications`; `POST /needs/{id}/telegram-publication/stop`. | Per-destination QUEUED/SENDING/POSTED/RETRY/UNCERTAIN/FAILED/SKIPPED/REMOVAL_PENDING/REMOVED; owner stop confirmation; paused destination; removal failed/partial. Say “accepted by Telegram,” never “viewed.” Explain forwards/screenshots may persist. |

### 18.3 Confirmation overlays and navigation

Bottom sheets/dialogs are interactions, not additional full-screen routes: (1) accept Offer (requester only; explain other pending Offers become rejected); (2) reject Offer; (3) cancel Need; (4) confirm Need completion; (5) stop Telegram distribution and request removal of known posts; (6) over-cap explicit Offer selection. Every destructive/irreversible action shows the target, consequence, cancel path, and submits with server version and idempotency key. Acceptance confirmation must never be triggered by an AI rank.

Bottom navigation is Browse, My Needs, My Offers, Notifications, Profile. Create Need is a prominent action reachable from Browse and My Needs; the action placement is fixed by FGM-PDS remediation revision 1.1: in-flow full-width action after filters below 600dp, header-right action at 600dp and above; no floating action button. Deep links reopen the public Need, then re-check access. Messages are reached from a participant Offer. Splash/loading is app bootstrap, not a route. Three-step onboarding is excluded from MVP unless approved by a versioned UX decision.

### 18.4 Visual prototype and standard-product acceptance

The accompanying `ui-preview/index.html` provides all23 mobile screens and23 Admin surfaces in a labelled canonical screen selector, with dedicated responsive compositions, Amharic/English, fixed approved product-owner supplied official logo master (canonical source included), light/dark themes and screen-relevant state previews. Preview data is fictional, static and disconnected from Laravel. It is a review aid, not production Flutter, backend proof, final artwork or evidence that every real device has been tested.

Use WCAG 2.2 AA as the accessibility QA target for applicable interface content; verify text contrast (4.5:1 normal, 3:1 large), non-text contrast and focus visibility; do not convey state by color alone. Support platform text scaling, semantic labels/order, TalkBack/VoiceOver, keyboard/focus where applicable, reduced motion, 320dp narrow layouts and long Amharic strings. Use Flutter localization facilities with `am` and `en` ARB resources, plural/date/number/currency formatting, and test each language on Android and iOS. Conformance is a release test result, not a claim from this design document.

Required UI acceptance evidence: all23 mobile screen IDs and23 Admin IDs appear in the selector and `screen-manifest.json`; every screen has a defined role, source endpoint, displayed fields and applicable states; no action bypasses Laravel guards; screenshots are reviewed at narrow and common phone sizes in both languages; state snapshots include content, loading, empty, validation, error, denied/offline and relevant business-terminal cases; AI score math and privacy projections match the API; Telegram preview, stop, uncertain delivery and deletion caveat match §16.1.


## Locked evaluation/UX revision1.4
`AI_Evaluation_Contract.md` owns the refined comparison, projection, delivery and v2 unknown-scoring contract; `criteria-registry.json` owns exact weights/normalization. Retain immutable v1 history. Main Admin and payment invariants from1.3 remain unchanged.
