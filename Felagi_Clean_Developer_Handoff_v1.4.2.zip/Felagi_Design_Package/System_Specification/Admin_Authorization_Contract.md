# Admin Authorization Contract — canonical 1.3

Retained DFM authentication/session/CSRF/MFA/least-privilege rules apply. Backend returns capabilities filtered by actor and scope before search, rows, pagination, export or counts. Main Admin has governed authority, never direct SQL or source access. `admin.view.<area>` authorizes read; `admin.control.<control_id>` authorizes the exact mutation. Both route and resource scopes are checked server-side on every request. Deny by default. Main Admin cannot edit payment truth, bypass immutable audit or disclose secret plaintext.

Admin (delegated support) may receive scoped LOW/MEDIUM content, report, job and evidence-read capabilities. No monetization, provider/security configuration, Safe Mode, restore or critical control without Main Admin. Moderator retains assigned-report and urgent Telegram pause scope from DFM; no general control-registry mutation. A role name alone does not grant a capability. The preview role switch is illustrative only.

HIGH/CRITICAL publication requires fresh authenticated reauthentication within five minutes, reason and exact impact/version confirmation. CRITICAL requires second factor. If session/second factor is unavailable, deny publish while retaining draft. An approver cannot publish a changed payload under an older confirmation digest. High-risk self-role escalation and suspending the last active Main Admin are denied. Secret rotations require separate secret-write capability and never return plaintext in API, audit, logs, diff or draft persistence.

Bulk actions bind a frozen selection digest with count, IDs/scope, effect and actor permission at preview; recheck each item at execution. Show item-level succeeded/failed/unknown and retry only failed eligible IDs using original operation idempotency keys. No 'select all' silently means all database records. Export redacts private information according to existing DFM policy.

Permission audit includes actor, effective capabilities, target scope, request/correlation ID, reason, before/after versions, confirmation digest and timestamp. Failed denied attempts are security events. Secrets store reference/status only. Never log submitted plaintext.


## Canonical HTTP binding 1.4
Governed configuration lifecycle uses `/api/v1/admin/changes`: POST creates typed draft; GET `/{id}` reads; PATCH `/{id}` edits with If-Match; POST `/{id}/validate`, `/simulate`, `/preview`, `/publish`, `/apply`, `/verify`, `/rollback`; GET `/{id}/audit`. These are design API contracts, not proof of deployed endpoints. Legacy `/admin/settings/drafts/{id}/publish` and `/admin/settings/{key}/rollback` are migration aliases to this same service, not separate writes. Permission/risk/reauth/idempotency and lifecycle described above apply to every alias. Campaign-specific publication invokes the same authorization/impact/audit primitives; it does not bypass them.
