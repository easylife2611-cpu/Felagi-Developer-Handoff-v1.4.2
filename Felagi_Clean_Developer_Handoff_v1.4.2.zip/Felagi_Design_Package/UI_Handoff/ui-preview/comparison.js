/* Reference contract logic. No AI call, server authorization or live delivery. */
(function(root){'use strict';
const clone=x=>JSON.parse(JSON.stringify(x));
function freeze(x){if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;}
function eligibility(o,need,now){if(need.state!=='OPEN')return 'NEED_INELIGIBLE';if(!o.authorized)return 'UNAUTHORIZED';if(o.state!=='PENDING')return o.state;if(o.created_at>need.offer_deadline)return 'AFTER_DEADLINE';if(!o.required_fields_valid)return 'INSUFFICIENT_DATA';return 'INCLUDED';}
function gateSelection(ids,selected,cap){if(!Number.isInteger(cap)||cap<1)throw Error('CAP_UNKNOWN');if(!selected.length)throw Error('NO_ELIGIBLE');if(selected.length>cap)throw Error('OVER_CAP');if(new Set(selected).size!==selected.length||selected.some(x=>!ids.includes(x)))throw Error('INELIGIBLE');return selected;}
function validate(result,snapshot,criteria){
 if(Object.keys(result).some(k=>!Object.keys(snapshot).includes(k))||result.comparison_id!==snapshot.comparison_id||result.need_hash!==snapshot.need_hash||JSON.stringify(result.requirements)!==JSON.stringify(snapshot.requirements))throw Error('SNAPSHOT_OR_EXTRA_FIELD');
 if(result.version!==snapshot.version||result.criteria_version!==snapshot.criteria_version||result.prompt_version!==snapshot.prompt_version||result.model_id!==snapshot.model_id||result.evaluation_policy_version!==snapshot.evaluation_policy_version)throw Error('VERSION_MISMATCH');
 const ids=snapshot.offers.map(o=>o.offer_id);if(result.offers.length!==ids.length||new Set(result.offers.map(o=>o.offer_id)).size!==ids.length)throw Error('RESULT_CARDINALITY');
 const allowed=new Set(['offer_id','provider_id','requirement_match','criteria','strengths','weaknesses','missing','risks']);
 const out=clone(result);
 for(const o of out.offers){if(!ids.includes(o.offer_id)||Object.keys(o).some(k=>!allowed.has(k)))throw Error('PRIVATE_OR_EXTRA_FIELD');for(const field of ['strengths','weaknesses','missing','risks']){if(!Array.isArray(o[field])||o[field].some(k=>!['fixtureEvidence','fixtureTradeoff','noHistory','unknown'].includes(k)))throw Error('UNSUPPORTED_NARRATIVE');}if(!['MEETS','PARTIALLY_MEETS','DOES_NOT_MEET','UNKNOWN'].includes(o.requirement_match))throw Error('REQUIREMENT_MATCH');const source=snapshot.offers.find(x=>x.offer_id===o.offer_id);if(o.provider_id!==source.provider_id)throw Error('OWNER_MISMATCH');
  if(o.criteria.length!==criteria.criteria.length||new Set(o.criteria.map(c=>c.id)).size!==criteria.criteria.length)throw Error('CRITERIA');
  let numerator=0,denominator=0,count=0;
  for(const c of o.criteria){const canonical=criteria.criteria.find(x=>x.id===c.id);if(!canonical)throw Error('CRITERION');if(Object.keys(c).some(k=>!['id','score','status','evidence_refs','explanation_key'].includes(k)))throw Error('UNSUPPORTED_FIELD');
   if(c.status==='UNKNOWN'){if(c.score!==null||c.evidence_refs.length)throw Error('UNKNOWN_NOT_SCORE');continue;}
   if(!['OBSERVED','INFERRED'].includes(c.status)||!Number.isFinite(c.score)||c.score<1||c.score>10||!c.evidence_refs.length)throw Error('SCORE');
   const permitted=new Set(source.criteria.flatMap(x=>x.evidence_refs));if(c.evidence_refs.some(ref=>!permitted.has(ref)))throw Error('INVENTED_EVIDENCE');
   if(!['fixtureEvidence','noHistory'].includes(c.explanation_key))throw Error('UNSUPPORTED_CLAIM');
   numerator+=c.score*canonical.weight;denominator+=canonical.weight;count++;
  }
  if(!count)throw Error('INSUFFICIENT_DATA');o.overall=Math.round((numerator/denominator+Number.EPSILON)*100)/100;o.coverage=count/criteria.criteria.length;
 }
 out.close_result=out.offers.some((o,i)=>out.offers.slice(i+1).some(p=>Math.abs(o.overall-p.overall)<=criteria.near_tie_delta+1e-9));return out;
}
function project(result,actor){const base={comparison_id:result.comparison_id,version:result.version,criteria_version:result.criteria_version,generated_at:result.generated_at,status:result.status};if(actor.role==='requester'&&actor.authorized)return {...base,offers:clone(result.offers),requirements:clone(result.requirements),exclusions:clone(result.exclusions),close_result:result.close_result};if(actor.role==='provider'){const own=result.offers.filter(o=>o.provider_id===actor.id);if(!own.length)throw Error('DENIED');return {...base,offers:clone(own),included_offer_count:result.offers.length};}throw Error('DENIED');}
class Ledger{constructor(){this.byKey=new Map();this.events=new Map();}start(key,snapshot){if(this.byKey.has(key)){const r=this.byKey.get(key);if(JSON.stringify(r.snapshot)!==JSON.stringify(snapshot))throw Error('IDEMPOTENCY_CONFLICT');return r;}const record={snapshot:freeze(clone(snapshot)),status:'PENDING',attempts:0,result:null};this.byKey.set(key,record);return record;}retry(key){const r=this.byKey.get(key);if(r.status==='COMPLETED')throw Error('IMMUTABLE');r.attempts++;r.status='PROCESSING';return r;}complete(key,raw,criteria){const r=this.byKey.get(key);if(r.status==='COMPLETED')return r;try{r.result=freeze(validate(raw,r.snapshot,criteria));r.status='COMPLETED';}catch(e){r.status='FAILED';r.result=null;throw e;}const recipients=new Set(['requester',...r.snapshot.offers.map(o=>o.provider_id)]);for(const recipient of recipients){const id=r.snapshot.comparison_id+':'+r.snapshot.version+':'+recipient;if(!this.events.has(id))this.events.set(id,{version:r.snapshot.version,recipient,in_app:'CREATED',telegram:'QUEUED'});}return r;}fail(key,code){const r=this.byKey.get(key);if(r.status==='COMPLETED')throw Error('IMMUTABLE');r.status='FAILED';r.result=null;r.failure_code=code;return r;}delivery(id,status){if(!['QUEUED','SENDING','SENT','UNCERTAIN','FAILED','RETRY','SKIPPED'].includes(status))throw Error('DELIVERY_STATE');this.events.get(id).telegram=status;}}
const api={eligibility,gateSelection,validate,project,Ledger};if(typeof module!=='undefined')module.exports=api;root.FelagiComparison=api;
})(typeof window!=='undefined'?window:globalThis);
