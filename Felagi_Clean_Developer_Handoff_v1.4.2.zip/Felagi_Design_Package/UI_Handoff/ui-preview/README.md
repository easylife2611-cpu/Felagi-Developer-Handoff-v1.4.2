# Felagi interactive design preview

Open index.html directly. No network/API/account or build step is required. The screen selector includes all46 canonical screens. Choose Amharic/English, light/dark, role, screen business state and applicable runtime condition. Record state is a fixture control; Admin risk comes from the registry, never authorization in a real application. Navigate the five mobile destinations or23 Admin destinations. Forms validate, retain session drafts, show confirmation dialogs and demonstrate explicit sample outcomes. All fixed UI copy comes from generated ARB data.

Important fixture boundaries: sign-in does not authenticate; payment does not pay; Telegram does not send; Admin never mutates a live service. Publishing is explicitly simulated and requests a simulated reauthentication check for high-risk demonstrations. Role/risk controls are review tools; the server determines both in production. State selection is synthetic, not a success claim. Search uses sample data and reports simulated action. Export-ready has no actual backend file. Device navigation/back, verified provider responses and production encrypted drafts remain implementation tests.

The preview is a state/composition review aid, not a complete production application or replacement for screen contracts. Create/edit routing, server eligibility and backend field validation are governed by Design_Data and System_Specification. Template forms are creation fixtures; existing-record aliases and conflict rebasing are specified for implementation. Media queries implement1/2/3-column layouts, rail/sidebar and narrow table cards; the renderer/device matrix requires external evidence because Chromium installation was unavailable.

Data files are generated: edit Design_Data, Localization ARB or canonical token registry, then run Tools/generate_runtime.py. Do not hand-edit data.js/tokens.css or the manifest copy.


## Integrated 1.4 contract
Version1.4 adds comparison evidence/projections and fictional sponsored slots plus A023 eight-step text campaign wizard. Ads fixture checkbox is OFF initially and never writes real configuration. External destination/media catalogs are unavailable in this offline reference; publication never claims runtime verification. Scripts have no live payment, AI, Telegram, ads or analytics calls.
