/* Executable design reference, not server payment verification. No network or credentials. */
(function(root){
'use strict';
function required(p){if(!p||typeof p.enabled!=='boolean'||!Number.isSafeInteger(p.amount_minor)||p.amount_minor<0||p.currency!=='ETB')throw Error('POLICY_UNKNOWN');return p.enabled&&p.amount_minor>0;}
function validate(c){const errors=[];if(c.boost===true&&c.payments!==true)errors.push('BOOST_REQUIRES_PAYMENTS');if(c.offerUnlock===true&&c.offerFee>0&&c.payments!==true)errors.push('UNLOCK_REQUIRES_PAYMENTS');if(c.aiCompare===true&&c.aiProviderValid!==true)errors.push('AI_PROVIDER_REQUIRED');if(c.offerFee!==undefined&&(!Number.isSafeInteger(c.offerFee)||c.offerFee<0||c.offerFee>500000))errors.push('FEE_RANGE');if(c.offerCurrency!==undefined&&c.offerCurrency!=='ETB')errors.push('CURRENCY');return errors;}
class Submission {
 constructor(){this.records=new Map();this.charges=0;this.submissions=0;}
 start(key,draft,policy){if(this.records.has(key)){const old=this.records.get(key);if(JSON.stringify(old.draft)!==JSON.stringify(draft))throw Error('IDEMPOTENCY_CONFLICT');return old;}const paid=required(policy);const r={id:key,draft:JSON.parse(JSON.stringify(draft)),snapshot:{...policy},state:paid?'pending':'submitted',payment_verified:false,offer_id:paid?null:'offer-'+key};if(paid)this.charges++;else this.submissions++;this.records.set(key,r);return r;}
 clientSuccess(key){return this.records.get(key);}
 serverVerifiedFixture(key,eligible=true,interrupted=false){const r=this.records.get(key);if(!r)throw Error('UNKNOWN_SUBMISSION');r.payment_verified=true;if(['submitted','refund-pending'].includes(r.state))return r;if(!eligible){r.state='refund-pending';return r;}if(interrupted){r.state='submission-recovery';return r;}r.state='submitted';r.offer_id='offer-'+key;this.submissions++;return r;}
 resume(key,eligible=true){const r=this.records.get(key);if(!r)throw Error('UNKNOWN_SUBMISSION');if(['submitted','refund-pending'].includes(r.state))return r;if(!r.payment_verified)return r;return this.serverVerifiedFixture(key,eligible);}
}
const api={required,validate,Submission};if(typeof module!=='undefined')module.exports=api;root.FelagiPolicy=api;
})(typeof window!=='undefined'?window:globalThis);
