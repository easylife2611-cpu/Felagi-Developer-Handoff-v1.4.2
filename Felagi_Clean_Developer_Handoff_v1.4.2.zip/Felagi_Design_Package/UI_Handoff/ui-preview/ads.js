/* Reference policy only: no network, tracking, billing or production authorization. */
'use strict';
(function(root,factory){const api=factory();if(typeof module==='object')module.exports=api;else root.FelagiAds=api;})(typeof window!=='undefined'?window:globalThis,()=>{
function destination(type,value,hosts=[]){
 if(type==='INTERNAL')return typeof value==='string'&&(/^\/browse$/.test(value)||/^\/needs\/[A-Za-z0-9_-]+$/.test(value));
 if(type!=='EXTERNAL'||typeof value!=='string')return false;
 try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&hosts.includes(u.hostname)&&!u.hash;}catch{return false;}
}
function creative(value,limits){
 if(!value||!['CARD','BANNER','COMPACT'].includes(value.format))return false;
 if(Object.keys(value).some(k=>!['format','locales','media'].includes(k)))return false;
 for(const lang of limits.locales){const c=value.locales?.[lang];if(!c)return false;for(const [key,max]of [['title',limits.title_max],['body',limits.body_max],['cta',limits.cta_max]])if(typeof c[key]!=='string'||!c[key].trim()||Array.from(c[key]).length>max||/[<>]/.test(c[key]))return false;}
 if(value.media){const m=value.media;if(!limits.mime.includes(m.mime)||!Number.isInteger(m.bytes)||m.bytes<=0||m.bytes>limits.max_bytes||m.animated!==false)return false;if(![m.width,m.height].every(n=>Number.isInteger(n)&&n>=limits.min_dimension&&n<=limits.max_dimension))return false;const ratio={CARD:16/9,BANNER:3,COMPACT:1}[value.format];if(Math.abs(m.width/m.height-ratio)>.02)return false;for(const l of limits.locales)if(typeof m.alt?.[l]!=='string'||!m.alt[l].trim()||Array.from(m.alt[l]).length>limits.alt_max)return false;}
 return true;
}
function eligible({policy,placement,campaign,context,counts,now}){
 if(policy?.master_enabled!==true||placement?.enabled!==true)return 'DISABLED';
 if(!campaign)return 'EMPTY';
 if(!counts||!context||!Number.isFinite(now))return 'FAILED';
 const start=Date.parse(campaign.start_at),end=Date.parse(campaign.end_at);
 if(!Number.isFinite(start)||!Number.isFinite(end)||start>=end)return 'FAILED';
 if(now>=end)return 'EXPIRED';
 if(now<start||campaign.status!=='ACTIVE'||campaign.approved!==true||campaign.advertiser_status!=='ACTIVE'||campaign.creative_valid!==true||campaign.destination_valid!==true)return 'NOT_ELIGIBLE';
 if(placement.screen_id!==context.screen_id||placement.view_mode!==context.view_mode||!campaign.placement_ids.includes(placement.placement_id)||!placement.allowed_creative_types.includes(campaign.creative_type))return 'NOT_ELIGIBLE';
 if(Object.keys(campaign.targeting??{}).some(k=>!['category','broad_region','language'].includes(k)))return 'NOT_ELIGIBLE';
 for(const [key,values]of Object.entries(campaign.targeting??{}))if(!Array.isArray(values)||!values.includes(context[key]))return 'NOT_ELIGIBLE';
 const f=policy.frequency;
 for(const [key,limit]of [['session',f.max_per_session],['day',f.max_per_day],['campaign',f.max_campaign_per_session],['placement',f.max_placement_per_session],['page',f.page_max]]){if(!Number.isInteger(counts[key])||counts[key]<0)return 'FAILED';if(counts[key]>=limit)return 'FREQUENCY_CAPPED';}
 return 'READY';
}
function insert(organic,ad,separation=5){if(!Number.isInteger(separation)||separation<4||separation>20)throw Error('Invalid separation');const out=organic.slice();if(ad&&organic.length>=separation)out.splice(separation,0,ad);return out;}
class Events{
 constructor(){this.records=new Map();}
 record(event){if(!event?.event_id||!event.delivery_id||!['IMPRESSION','CLICK'].includes(event.type))return false;if(event.type==='IMPRESSION'&&!(event.ratio>=.5&&event.continuous_ms>=1000&&event.foreground===true))return false;if(event.type==='CLICK'&&event.explicit!==true)return false;const key=event.delivery_id+':'+event.type;if(this.records.has(key)||[...this.records.values()].some(x=>x.event_id===event.event_id))return false;this.records.set(key,Object.freeze({...event}));return true;}
 ctr(){const all=[...this.records.values()],impressions=all.filter(x=>x.type==='IMPRESSION').length;return impressions?all.filter(x=>x.type==='CLICK'&&this.records.has(x.delivery_id+':IMPRESSION')).length/impressions:null;}
}
function publish(history,draft,{authorized,expectedVersion,reason}){if(!authorized||!reason?.trim()||expectedVersion!==(history.at(-1)?.version??0))throw Error('Unauthorized or conflict');const next=JSON.parse(JSON.stringify({...draft,version:expectedVersion+1,reason,status:'PUBLISHED',runtime_status:'REQUIRES_EVIDENCE'}));return [...history,next];}
return {destination,creative,eligible,insert,Events,publish};
});
