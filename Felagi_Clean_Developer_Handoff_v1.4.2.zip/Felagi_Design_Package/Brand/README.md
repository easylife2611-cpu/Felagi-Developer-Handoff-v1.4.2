# Felagi Official Brand Master — v1.4.1

`official-master-logo.png` is the canonical product-owner supplied master used for normal product surfaces.
`official-master-logo-glow.png` is the supplied glow/dark presentation variant.

Rules:
- Do not redraw, simplify, recolor or approximate the mark.
- Raster use is authoritative when vectorization changes geometry, gradients or proportions.
- SVG compatibility files embed the exact supplied raster artwork and are not redrawn vectors.
- All production derivatives must visually match the canonical master.
